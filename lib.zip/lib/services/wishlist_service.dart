import 'api_service.dart';
import 'package:flutter/foundation.dart';

class WishlistService extends ChangeNotifier {
  WishlistService._internal();
  static final WishlistService instance = WishlistService._internal();

  List<Map<String, dynamic>> _items = [];
  bool _isLoading = false;
  bool _isSynced = false;

  List<Map<String, dynamic>> get items => List.unmodifiable(_items);
  bool get isLoading => _isLoading;
  bool get isSynced => _isSynced;

  // Sync wishlist from server
  Future<void> syncFromServer() async {
    if (_isLoading) return;
    
    _isLoading = true;
    notifyListeners();

    try {
      final response = await ApiService.get('/wishlist');
      if (response['success'] == true) {
        final wishlistData = response['data']?['wishlist'] ?? [];
        _items = List<Map<String, dynamic>>.from(wishlistData);
        _isSynced = true;
      } else {
        // If sync fails, keep existing items
        print('Wishlist sync returned success: false');
      }
    } catch (e) {
      print('Error syncing wishlist: $e');
      // Don't clear items on error - keep local cache
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Add product to wishlist (cloud + local)
  Future<bool> add(Map<String, dynamic> product) async {
    try {
      final productId = product['_id']?.toString();
      if (productId == null) return false;

      // Optimistically update UI
      if (!_items.any((p) => p['_id']?.toString() == productId)) {
        _items.add(Map<String, dynamic>.from(product));
        notifyListeners();
      }

      // Add to server
      try {
        final response = await ApiService.post('/wishlist', {
          'productId': productId,
        });

        if (response['success'] == true) {
          return true;
        } else {
          // Remove from local if server failed
          _items.removeWhere((p) => p['_id']?.toString() == productId);
          notifyListeners();
          return false;
        }
      } catch (e) {
        // If network error, keep local but log
        print('Error adding to wishlist (network): $e');
        // Keep optimistic update - will sync later
        return true;
      }
    } catch (e) {
      print('Error adding to wishlist: $e');
      return false;
    }
  }

  // Remove product from wishlist (cloud + local)
  Future<bool> remove(Map<String, dynamic> product) async {
    try {
      final productId = product['_id']?.toString();
      if (productId == null) return false;

      // Optimistically remove from UI
      final wasPresent = _items.any((p) => p['_id']?.toString() == productId);
      if (wasPresent) {
        _items.removeWhere((p) => p['_id']?.toString() == productId);
        notifyListeners();
      }

      // Remove from server
      try {
        final response = await ApiService.delete('/wishlist/$productId');
        if (response['success'] == true || response['success'] == null) {
          return true;
        } else {
          // Re-add if server failed
          if (wasPresent && !_items.any((p) => p['_id']?.toString() == productId)) {
            _items.add(Map<String, dynamic>.from(product));
            notifyListeners();
          }
          return false;
        }
      } catch (e) {
        // If network error, keep removed locally but log
        print('Error removing from wishlist (network): $e');
        // Keep optimistic removal - will sync later
        return true;
      }
    } catch (e) {
      print('Error removing from wishlist: $e');
      return false;
    }
  }

  // Toggle wishlist status
  Future<void> toggle(Map<String, dynamic> product) async {
    if (isWished(product)) {
      await remove(product);
    } else {
      await add(product);
    }
  }

  // Check if product is in wishlist
  bool isWished(Map<String, dynamic> product) {
    final productId = product['_id']?.toString();
    if (productId == null) return false;
    return _items.any((p) => p['_id']?.toString() == productId);
  }

  // Clear local wishlist
  void clear() {
    _items.clear();
    _isSynced = false;
    notifyListeners();
  }
}


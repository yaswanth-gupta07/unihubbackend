import 'api_service.dart';
import 'storage_service.dart';
import 'user_service.dart';
import 'wishlist_service.dart' as wishlist;
import 'auth_session_manager.dart';

class AuthService {
  // Send OTP to email
  static Future<Map<String, dynamic>> sendOtp(String email) async {
    final response = await ApiService.post(
      '/auth/send-otp',
      {'email': email},
      includeAuth: false,
    );
    return response;
  }

  // Verify OTP and login
  static Future<Map<String, dynamic>> verifyOtp(String email, String otp) async {
    final response = await ApiService.post(
      '/auth/verify-otp',
      {'email': email, 'otp': otp},
      includeAuth: false,
    );
    
    if (response['success'] == true && response['data'] != null) {
      final accessToken = response['data']['accessToken'] ?? response['data']['token'];
      final refreshToken = response['data']['refreshToken'];
      final user = response['data']['user'];
      
      // Save both tokens securely
      if (refreshToken != null) {
        await StorageService.saveTokens(accessToken, refreshToken);
      } else {
        // Fallback for backward compatibility
        await StorageService.saveToken(accessToken);
      }
      
      // Save user data
      await StorageService.saveUserData(user);
      
      return {
        'success': true,
        'token': accessToken, // For backward compatibility
        'accessToken': accessToken,
        'refreshToken': refreshToken,
        'user': user,
      };
    }
    
    return response;
  }

  // Refresh access token
  static Future<Map<String, dynamic>> refreshAccessToken() async {
    try {
      final refreshToken = await StorageService.getRefreshToken();
      
      if (refreshToken == null) {
        throw Exception('No refresh token available');
      }
      
      final response = await ApiService.post(
        '/auth/refresh-token',
        {'refreshToken': refreshToken},
        includeAuth: false,
      );
      
      if (response['success'] == true && response['data'] != null) {
        final accessToken = response['data']['accessToken'];
        final user = response['data']['user'];
        
        // Update access token (refresh token remains the same)
        await StorageService.saveAccessToken(accessToken);
        
        // Update user data if provided
        if (user != null) {
          await StorageService.saveUserData(user);
        }
        
        return {
          'success': true,
          'accessToken': accessToken,
          'user': user,
        };
      }
      
      return response;
    } catch (e) {
      // If refresh fails, clear tokens and logout
      await StorageService.deleteToken();
      rethrow;
    }
  }

  // Logout
  static Future<void> logout() async {
    try {
      // Get refresh token before clearing
      final refreshToken = await StorageService.getRefreshToken();
      
      // Clear local data FIRST (prioritize local cleanup for faster logout)
      // Clear cache
      await UserService.clearCache();
      
      // Clear wishlist state
      try {
        wishlist.WishlistService.instance.clear();
      } catch (e) {
        // Wishlist service might not be available, continue with logout
        print('Warning: Could not clear wishlist: $e');
      }
      
      // Clear all tokens and user data
      await StorageService.deleteToken();
      // Also clear all data using clearAll to ensure everything is removed
      await StorageService.clearAll();
      
      // Reset session manager
      AuthSessionManager().reset();
      
      // Call backend logout endpoint AFTER clearing local data (non-blocking)
      // This way the UI can proceed immediately even if backend is slow
      if (refreshToken != null && refreshToken.isNotEmpty) {
        // Fire and forget - don't wait for backend response
        ApiService.post(
          '/auth/logout',
          {'refreshToken': refreshToken},
          includeAuth: false, // Logout doesn't require auth (allows logout with expired tokens)
        ).timeout(
          const Duration(seconds: 2),
          onTimeout: () {
            print('Backend logout timeout - local data already cleared');
            return <String, dynamic>{'success': false, 'message': 'Timeout'};
          },
        ).catchError((e) {
          // Continue even if backend call fails - local data is already cleared
          print('Warning: Backend logout failed: $e');
          return <String, dynamic>{'success': false, 'message': 'Error'};
        });
      }
    } catch (e) {
      // Even if there's an error, try to clear tokens
      try {
        await StorageService.deleteToken();
        await StorageService.clearAll();
        AuthSessionManager().reset();
      } catch (clearError) {
        print('Error clearing storage: $clearError');
      }
      print('Error during logout: $e');
    }
  }

  // Check if user is logged in
  static Future<bool> isLoggedIn() async {
    return await StorageService.isLoggedIn();
  }
}


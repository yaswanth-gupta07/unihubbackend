import 'api_service.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ProductService {
  // Get my products (returns active and sold groups)
  static Future<Map<String, dynamic>> getMyProducts() async {
    final response = await ApiService.get('/products/my');
    return response['data'] ?? {'active': [], 'sold': []};
  }

  // Get product by ID
  static Future<Map<String, dynamic>> getProductById(String productId) async {
    final response = await ApiService.get('/products/$productId');
    return response['data']['product'];
  }

  // Create a new product
  static Future<Map<String, dynamic>> createProduct({
    required String title,
    required double price,
    required String category,
    required String description,
    required String condition, // New | Good | Used
    List<String>? images,
  }) async {
    final response = await ApiService.post(
      '/products',
      {
        'title': title,
        'price': price,
        'category': category,
        'description': description,
        'condition': condition,
        'images': images ?? [],
      },
    );
    return response['data']['product'];
  }

  // Update product (Edit)
  static Future<Map<String, dynamic>> updateProduct({
    required String productId,
    String? title,
    String? description,
    double? price,
    String? category,
    String? condition,
    List<String>? images,
  }) async {
    final body = <String, dynamic>{};
    if (title != null) body['title'] = title;
    if (description != null) body['description'] = description;
    if (price != null) body['price'] = price;
    if (category != null) body['category'] = category;
    if (condition != null) body['condition'] = condition;
    if (images != null) body['images'] = images;

    final response = await ApiService.put('/products/$productId', body);
    return response['data']['product'];
  }

  // Get products with filters and pagination
  static Future<Map<String, dynamic>> getProducts({
    String? category,
    String? search,
    int page = 1,
    int limit = 20,
  }) async {
    String endpoint = '/products';
    final queryParams = <String>[];
    if (category != null && category.isNotEmpty) {
      queryParams.add('category=${Uri.encodeComponent(category)}');
    }
    if (search != null && search.isNotEmpty) {
      queryParams.add('search=${Uri.encodeComponent(search)}');
    }
    queryParams.add('page=$page');
    queryParams.add('limit=$limit');
    
    if (queryParams.isNotEmpty) {
      endpoint += '?${queryParams.join('&')}';
    }
    
    final response = await ApiService.get(endpoint);
    return {
      'products': response['data']['products'] ?? [],
      'total': response['data']['total'] ?? 0,
      'page': response['data']['page'] ?? page,
      'limit': response['data']['limit'] ?? limit,
      'totalPages': response['data']['totalPages'] ?? 1,
    };
  }

  // Reserve a product
  static Future<Map<String, dynamic>> reserveProduct(String productId) async {
    final response = await ApiService.put('/products/$productId/reserve', {});
    return response['data']['product'];
  }

  // Mark product as sold
  static Future<Map<String, dynamic>> markProductSold(String productId) async {
    final response = await ApiService.put('/products/$productId/sold', {});
    return response['data']['product'];
  }

  // Show interest in product (sends email to seller)
  static Future<void> showInterest(String productId, String message, {String? phone}) async {
    await ApiService.post(
      '/products/$productId/interest',
      {
        'message': message,
        if (phone != null) 'phone': phone,
      },
    );
  }
}


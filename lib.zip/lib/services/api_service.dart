import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image_picker/image_picker.dart';
import 'storage_service.dart';
import 'auth_service.dart';

class ApiService {
  static const bool isProd = true;

  static const String _prodUrl =
      "https://unihubbackend-h7lp.onrender.com/api";

  static const String _androidUrl =
      "http://10.0.2.2:5000/api";

  static const String _localhostUrl =
      "http://localhost:5000/api";

  static String get baseUrl {
    if (isProd) return _prodUrl;
    return _androidUrl;
  }

  // Get headers with authentication
  static Future<Map<String, String>> getHeaders({bool includeAuth = true}) async {
    final headers = {
      'Content-Type': 'application/json',
    };

    if (includeAuth) {
      final token = await StorageService.getAccessToken();
      if (token != null) {
        headers['Authorization'] = 'Bearer $token';
      }
    }

    return headers;
  }

  // Get appropriate timeout for endpoint
  static Duration _getTimeoutForEndpoint(String endpoint) {
    // Operations that might send emails or take longer
    if (endpoint.contains('/applications') || 
        endpoint.contains('/jobs') ||
        endpoint.contains('/reviews') ||
        endpoint.contains('/interest')) {
      return const Duration(seconds: 45); // Longer timeout for email operations
    }
    return const Duration(seconds: 30); // Default timeout
  }

  // Handle user-friendly error messages
  static String _getUserFriendlyError(dynamic error, String? serverMessage) {
    final errorStr = error.toString().toLowerCase();
    
    // Network errors
    if (errorStr.contains('socketexception') || errorStr.contains('failed host lookup')) {
      return 'No internet connection. Please check your network and try again.';
    }
    
    if (errorStr.contains('timeout') || errorStr.contains('connection timeout')) {
      return 'Connection timeout. Please check your internet connection and try again.';
    }
    
    if (errorStr.contains('format') || errorStr.contains('invalid')) {
      return 'Invalid response from server. Please try again.';
    }
    
    // Server errors
    if (serverMessage != null && serverMessage.isNotEmpty) {
      // Remove technical details from server messages
      String cleanMessage = serverMessage;
      
      // Remove URLs
      cleanMessage = cleanMessage.replaceAll(RegExp(r'https?://[^\s]+'), '');
      cleanMessage = cleanMessage.replaceAll(RegExp(r'Server:.*'), '');
      cleanMessage = cleanMessage.replaceAll(RegExp(r'Server URL:.*'), '');
      
      // Remove stack traces
      cleanMessage = cleanMessage.split('\n').first.trim();
      
      return cleanMessage;
    }
    
    // Generic error
    return 'Something went wrong. Please try again.';
  }

  // Handle 401 errors by refreshing token
  static Future<bool> _handleUnauthorized() async {
    try {
      final refreshToken = await StorageService.getRefreshToken();
      if (refreshToken == null || refreshToken.isEmpty) {
        return false;
      }
      
      final result = await AuthService.refreshAccessToken();
      return result['success'] == true;
    } catch (e) {
      return false;
    }
  }

  // Generic GET request
  static Future<Map<String, dynamic>> get(String endpoint, {bool includeAuth = true}) async {
    try {
      final headers = await getHeaders(includeAuth: includeAuth);
      final url = '$baseUrl$endpoint';

      print('API Request: GET $url'); // Debug log

      final response = await http.get(
        Uri.parse(url),
        headers: headers,
      ).timeout(
        const Duration(seconds: 30),
        onTimeout: () {
          if (isProd) {
            throw Exception('Connection timeout. Please check your internet connection and try again.');
          } else {
            throw Exception('Connection timeout. Please check:\n1. Server is running\n2. Set _customIpAddress in api_service.dart to your computer IP\n3. Phone and computer on same WiFi');
          }
        },
      );

      if (response.body.isEmpty) {
        throw Exception('Empty response from server');
      }

      final data = json.decode(response.body);

      if (response.statusCode >= 200 && response.statusCode < 300) {
        return data;
      } else {
        throw Exception(data['message'] ?? 'Request failed');
      }
    } on SocketException catch (e) {
      if (isProd) {
        throw Exception('Cannot connect to server. Please check your internet connection.\n\nServer: $baseUrl\n\nError: ${e.message}');
      } else {
        throw Exception('Cannot connect to server at $baseUrl\n\nFor physical devices:\n1. Set _customIpAddress in api_service.dart to your computer IP\n2. Ensure phone and computer are on same WiFi\n3. Check server is running on port 5000\n\nError: ${e.message}');
      }
    } on FormatException {
      throw Exception('Invalid server response. Please try again.');
    } catch (e) {
      if (e.toString().contains('timeout')) {
        rethrow;
      }
      throw Exception('Network error: ${e.toString()}\n\nServer URL: $baseUrl');
    }
  }

  // Generic POST request
  static Future<Map<String, dynamic>> post(String endpoint, Map<String, dynamic> body, {bool includeAuth = true, Duration? timeout}) async {
    try {
      final headers = await getHeaders(includeAuth: includeAuth);
      final url = '$baseUrl$endpoint';

      print('API Request: POST $url'); // Debug log

      // Use longer timeout for operations that might send emails (applications, jobs, etc.)
      final requestTimeout = timeout ?? _getTimeoutForEndpoint(endpoint);

      final response = await http.post(
        Uri.parse(url),
        headers: headers,
        body: json.encode(body),
      ).timeout(
        requestTimeout,
        onTimeout: () {
          throw Exception('Connection timeout. Please check your internet connection and try again.');
        },
      );

      if (response.body.isEmpty) {
        throw Exception('Empty response from server');
      }

      final data = json.decode(response.body);

      // Handle 401 Unauthorized - try to refresh token
      if (response.statusCode == 401 && includeAuth) {
        final refreshed = await _handleUnauthorized();
        if (refreshed) {
          // Retry the request with new token
          final retryHeaders = await getHeaders(includeAuth: includeAuth);
          final retryResponse = await http.post(
            Uri.parse(url),
            headers: retryHeaders,
            body: json.encode(body),
          ).timeout(
            const Duration(seconds: 15),
            onTimeout: () {
              throw Exception('Connection timeout. Please check your internet connection and try again.');
            },
          );
          
          if (retryResponse.statusCode >= 200 && retryResponse.statusCode < 300) {
            return json.decode(retryResponse.body);
          }
        }
        // If refresh failed, throw user-friendly error
        throw Exception(_getUserFriendlyError('unauthorized', 'Your session has expired. Please login again.'));
      }

      if (response.statusCode >= 200 && response.statusCode < 300) {
        return data;
      } else {
        final errorMessage = data['message'] ?? 'Request failed';
        throw Exception(_getUserFriendlyError('server_error', errorMessage));
      }
    } on SocketException catch (e) {
      throw Exception(_getUserFriendlyError(e, null));
    } on FormatException {
      throw Exception(_getUserFriendlyError('format_error', null));
    } catch (e) {
      if (e is Exception) {
        rethrow;
      }
      throw Exception(_getUserFriendlyError(e, null));
    }
  }

  // Generic PUT request
  static Future<Map<String, dynamic>> put(String endpoint, Map<String, dynamic> body, {bool includeAuth = true, Duration? timeout}) async {
    try {
      final headers = await getHeaders(includeAuth: includeAuth);
      final url = '$baseUrl$endpoint';

      print('API Request: PUT $url'); // Debug log

      // Use longer timeout for operations that might send emails
      final requestTimeout = timeout ?? _getTimeoutForEndpoint(endpoint);

      final response = await http.put(
        Uri.parse(url),
        headers: headers,
        body: json.encode(body),
      ).timeout(
        requestTimeout,
        onTimeout: () {
          throw Exception('Connection timeout. Please check your internet connection and try again.');
        },
      );

      if (response.body.isEmpty) {
        throw Exception('Empty response from server');
      }

      final data = json.decode(response.body);

      // Handle 401 Unauthorized - try to refresh token
      if (response.statusCode == 401 && includeAuth) {
        final refreshed = await _handleUnauthorized();
        if (refreshed) {
          // Retry the request with new token
          final retryHeaders = await getHeaders(includeAuth: includeAuth);
          final retryResponse = await http.put(
            Uri.parse(url),
            headers: retryHeaders,
            body: json.encode(body),
          ).timeout(
            const Duration(seconds: 30),
            onTimeout: () {
              throw Exception('Connection timeout. Please check your internet connection and try again.');
            },
          );
          
          if (retryResponse.statusCode >= 200 && retryResponse.statusCode < 300) {
            return json.decode(retryResponse.body);
          }
        }
        // If refresh failed, throw user-friendly error
        throw Exception(_getUserFriendlyError('unauthorized', 'Your session has expired. Please login again.'));
      }

      if (response.statusCode >= 200 && response.statusCode < 300) {
        return data;
      } else {
        final errorMessage = data['message'] ?? 'Request failed';
        throw Exception(_getUserFriendlyError('server_error', errorMessage));
      }
    } on SocketException catch (e) {
      throw Exception(_getUserFriendlyError(e, null));
    } on FormatException {
      throw Exception(_getUserFriendlyError('format_error', null));
    } catch (e) {
      if (e is Exception) {
        rethrow;
      }
      throw Exception(_getUserFriendlyError(e, null));
    }
  }

  // Generic DELETE request
  static Future<Map<String, dynamic>> delete(String endpoint, {bool includeAuth = true}) async {
    try {
      final headers = await getHeaders(includeAuth: includeAuth);
      final url = '$baseUrl$endpoint';

      print('API Request: DELETE $url'); // Debug log

      final response = await http.delete(
        Uri.parse(url),
        headers: headers,
      ).timeout(
        const Duration(seconds: 30),
        onTimeout: () {
          if (isProd) {
            throw Exception('Connection timeout. Please check your internet connection and try again.');
          } else {
            throw Exception('Connection timeout. Please check:\n1. Server is running\n2. Set _customIpAddress in api_service.dart to your computer IP\n3. Phone and computer on same WiFi');
          }
        },
      );

      if (response.body.isEmpty) {
        // DELETE requests might return empty body on success
        if (response.statusCode >= 200 && response.statusCode < 300) {
          return {'success': true};
        }
        throw Exception('Empty response from server');
      }

      final data = json.decode(response.body);

      // Handle 401 Unauthorized - try to refresh token
      if (response.statusCode == 401 && includeAuth) {
        final refreshed = await _handleUnauthorized();
        if (refreshed) {
          // Retry the request with new token
          final retryHeaders = await getHeaders(includeAuth: includeAuth);
          final retryResponse = await http.delete(
            Uri.parse(url),
            headers: retryHeaders,
          ).timeout(
            const Duration(seconds: 30),
            onTimeout: () {
              throw Exception('Connection timeout. Please check your internet connection and try again.');
            },
          );
          
          if (retryResponse.statusCode >= 200 && retryResponse.statusCode < 300) {
            if (retryResponse.body.isEmpty) {
              return {'success': true};
            }
            return json.decode(retryResponse.body);
          }
        }
        // If refresh failed, throw user-friendly error
        throw Exception(_getUserFriendlyError('unauthorized', 'Your session has expired. Please login again.'));
      }

      if (response.statusCode >= 200 && response.statusCode < 300) {
        return data;
      } else {
        final errorMessage = data['message'] ?? 'Request failed';
        throw Exception(_getUserFriendlyError('server_error', errorMessage));
      }
    } on SocketException catch (e) {
      throw Exception(_getUserFriendlyError(e, null));
    } on FormatException {
      throw Exception(_getUserFriendlyError('format_error', null));
    } catch (e) {
      if (e is Exception) {
        rethrow;
      }
      throw Exception(_getUserFriendlyError(e, null));
    }
  }

  // Upload images (multipart form data)
  static Future<List<String>> uploadImages(List<String> imagePaths) async {
    try {
      final token = await StorageService.getAccessToken();
      final List<String> imageUrls = [];
      final url = '$baseUrl/upload/image';

      for (String imagePath in imagePaths) {
        try {
          final file = File(imagePath);
          if (!await file.exists()) {
            print('Image file not found: $imagePath');
            continue;
          }

          final request = http.MultipartRequest(
            'POST',
            Uri.parse(url),
          );

          if (token != null) {
            request.headers['Authorization'] = 'Bearer $token';
          }

          // Determine MIME type from file extension
          final extension = imagePath.toLowerCase().split('.').last;
          MediaType? contentType;
          switch (extension) {
            case 'jpg':
            case 'jpeg':
              contentType = MediaType('image', 'jpeg');
              break;
            case 'png':
              contentType = MediaType('image', 'png');
              break;
            case 'webp':
              contentType = MediaType('image', 'webp');
              break;
            case 'gif':
              contentType = MediaType('image', 'gif');
              break;
            default:
              contentType = MediaType('image', 'jpeg'); // Default fallback
          }

          request.files.add(
            await http.MultipartFile.fromPath(
              'image',
              imagePath,
              contentType: contentType,
            ),
          );

          final streamedResponse = await request.send().timeout(
            const Duration(seconds: 60),
            onTimeout: () {
              throw Exception('Image upload timeout');
            },
          );

          final response = await http.Response.fromStream(streamedResponse);

          if (response.body.isEmpty) {
            print('Empty response for image upload');
            continue;
          }

          final data = json.decode(response.body);

          print('Image upload response for $imagePath: ${response.statusCode}');
          print('Response body: $data');

          if (response.statusCode >= 200 && response.statusCode < 300) {
            final imageUrl = data['data']?['url'] ?? data['url'] ?? '';
            print('Extracted image URL: $imageUrl');
            if (imageUrl.isNotEmpty) {
              imageUrls.add(imageUrl);
              print('Successfully added image URL to list. Total URLs: ${imageUrls.length}');
            } else {
              print('WARNING: Image URL is empty!');
            }
          } else {
            print('Image upload failed: ${data['message'] ?? 'Unknown error'}');
          }
        } catch (e) {
          print('Error uploading image $imagePath: $e');
          // Continue with next image
          continue;
        }
      }

      return imageUrls;
    } on SocketException {
      throw Exception('No internet connection. Please check your network.');
    } catch (e) {
      print('Error in uploadImages: $e');
      // Return empty list if all uploads fail
      return [];
    }
  }

  // Upload images for web (using XFile with bytes)
  static Future<List<String>> uploadImagesWeb(List<XFile> imageFiles) async {
    try {
      final token = await StorageService.getAccessToken();
      final List<String> imageUrls = [];
      final url = '$baseUrl/upload/image';

      for (XFile imageFile in imageFiles) {
        try {
          final request = http.MultipartRequest(
            'POST',
            Uri.parse(url),
          );

          if (token != null) {
            request.headers['Authorization'] = 'Bearer $token';
          }

          // For web, read bytes from XFile
          final bytes = await imageFile.readAsBytes();

          // Determine MIME type from file extension
          final extension = imageFile.name.toLowerCase().split('.').last;
          MediaType? contentType;
          switch (extension) {
            case 'jpg':
            case 'jpeg':
              contentType = MediaType('image', 'jpeg');
              break;
            case 'png':
              contentType = MediaType('image', 'png');
              break;
            case 'webp':
              contentType = MediaType('image', 'webp');
              break;
            case 'gif':
              contentType = MediaType('image', 'gif');
              break;
            default:
              contentType = MediaType('image', 'jpeg'); // Default fallback
          }

          final multipartFile = http.MultipartFile.fromBytes(
            'image',
            bytes,
            filename: imageFile.name,
            contentType: contentType,
          );

          request.files.add(multipartFile);

          final streamedResponse = await request.send().timeout(
            const Duration(seconds: 60),
            onTimeout: () {
              throw Exception('Image upload timeout');
            },
          );

          final response = await http.Response.fromStream(streamedResponse);

          if (response.body.isEmpty) {
            print('Empty response for image upload');
            continue;
          }

          final data = json.decode(response.body);

          print('Image upload response for ${imageFile.name}: ${response.statusCode}');
          print('Response body: $data');

          if (response.statusCode >= 200 && response.statusCode < 300) {
            final imageUrl = data['data']?['url'] ?? data['url'] ?? '';
            print('Extracted image URL: $imageUrl');
            if (imageUrl.isNotEmpty) {
              imageUrls.add(imageUrl);
              print('Successfully added image URL to list. Total URLs: ${imageUrls.length}');
            } else {
              print('WARNING: Image URL is empty!');
            }
          } else {
            print('Image upload failed: ${data['message'] ?? 'Unknown error'}');
          }
        } catch (e) {
          print('Error uploading image ${imageFile.name}: $e');
          // Continue with next image
          continue;
        }
      }

      return imageUrls;
    } on SocketException {
      throw Exception('No internet connection. Please check your network.');
    } catch (e) {
      print('Error in uploadImagesWeb: $e');
      // Return empty list if all uploads fail
      return [];
    }
  }
}


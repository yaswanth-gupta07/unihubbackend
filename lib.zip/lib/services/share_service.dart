import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ShareService {
  /// Share job details via WhatsApp
  static Future<bool> shareViaWhatsApp({
    required String jobTitle,
    required String jobDescription,
    required String budget,
    required String category,
    String? jobId,
  }) async {
    try {
      final message = _buildJobShareMessage(
        jobTitle: jobTitle,
        jobDescription: jobDescription,
        budget: budget,
        category: category,
        jobId: jobId,
      );

      // WhatsApp URL scheme
      final whatsappUrl = 'whatsapp://send?text=${Uri.encodeComponent(message)}';
      
      if (await canLaunchUrl(Uri.parse(whatsappUrl))) {
        return await launchUrl(
          Uri.parse(whatsappUrl),
          mode: LaunchMode.externalApplication,
        );
      } else {
        // Fallback to web WhatsApp if app not installed
        final webWhatsappUrl = 'https://wa.me/?text=${Uri.encodeComponent(message)}';
        return await launchUrl(
          Uri.parse(webWhatsappUrl),
          mode: LaunchMode.externalApplication,
        );
      }
    } catch (e) {
      print('Error sharing via WhatsApp: $e');
      return false;
    }
  }

  /// Share job details via Telegram
  static Future<bool> shareViaTelegram({
    required String jobTitle,
    required String jobDescription,
    required String budget,
    required String category,
    String? jobId,
  }) async {
    try {
      final message = _buildJobShareMessage(
        jobTitle: jobTitle,
        jobDescription: jobDescription,
        budget: budget,
        category: category,
        jobId: jobId,
      );

      // Telegram URL scheme
      final telegramUrl = 'https://t.me/share/url?url=${Uri.encodeComponent('https://unihub.app/job/${jobId ?? ''}')}&text=${Uri.encodeComponent(message)}';
      
      return await launchUrl(
        Uri.parse(telegramUrl),
        mode: LaunchMode.externalApplication,
      );
    } catch (e) {
      print('Error sharing via Telegram: $e');
      return false;
    }
  }

  /// Share job details via system share sheet
  static Future<bool> shareViaSystem({
    required String jobTitle,
    required String jobDescription,
    required String budget,
    required String category,
    String? jobId,
  }) async {
    try {
      final message = _buildJobShareMessage(
        jobTitle: jobTitle,
        jobDescription: jobDescription,
        budget: budget,
        category: category,
        jobId: jobId,
      );

      // Use url_launcher's share functionality
      final shareUrl = 'mailto:?subject=${Uri.encodeComponent('Check out this job on UniHub')}&body=${Uri.encodeComponent(message)}';
      
      return await launchUrl(
        Uri.parse(shareUrl),
        mode: LaunchMode.externalApplication,
      );
    } catch (e) {
      print('Error sharing via system: $e');
      return false;
    }
  }

  /// Build formatted share message
  static String _buildJobShareMessage({
    required String jobTitle,
    required String jobDescription,
    required String budget,
    required String category,
    String? jobId,
  }) {
    final buffer = StringBuffer();
    buffer.writeln('🚀 *$jobTitle*');
    buffer.writeln('');
    buffer.writeln('💰 Budget: ₹$budget');
    buffer.writeln('📂 Category: $category');
    buffer.writeln('');
    buffer.writeln('📝 Description:');
    buffer.writeln(jobDescription.length > 200 
        ? '${jobDescription.substring(0, 200)}...' 
        : jobDescription);
    buffer.writeln('');
    buffer.writeln('👉 Apply on UniHub - Your University Freelancing Platform');
    if (jobId != null) {
      buffer.writeln('🔗 https://unihub.app/job/$jobId');
    }
    buffer.writeln('');
    buffer.writeln('Download UniHub app to find more opportunities!');
    
    return buffer.toString();
  }

  /// Share via any platform (shows platform selection)
  static Future<void> showShareOptions({
    required BuildContext context,
    required String jobTitle,
    required String jobDescription,
    required String budget,
    required String category,
    String? jobId,
  }) async {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _ShareOptionsSheet(
        jobTitle: jobTitle,
        jobDescription: jobDescription,
        budget: budget,
        category: category,
        jobId: jobId,
      ),
    );
  }
}

/// Share options bottom sheet widget
class _ShareOptionsSheet extends StatelessWidget {
  final String jobTitle;
  final String jobDescription;
  final String budget;
  final String category;
  final String? jobId;

  const _ShareOptionsSheet({
    required this.jobTitle,
    required this.jobDescription,
    required this.budget,
    required this.category,
    this.jobId,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            margin: const EdgeInsets.only(bottom: 20),
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const Text(
            'Share Job',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _ShareOption(
                icon: Icons.chat,
                label: 'WhatsApp',
                color: const Color(0xFF25D366),
                onTap: () async {
                  Navigator.pop(context);
                  final success = await ShareService.shareViaWhatsApp(
                    jobTitle: jobTitle,
                    jobDescription: jobDescription,
                    budget: budget,
                    category: category,
                    jobId: jobId,
                  );
                  if (!success && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Could not open WhatsApp'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                },
              ),
              _ShareOption(
                icon: Icons.send,
                label: 'Telegram',
                color: const Color(0xFF0088CC),
                onTap: () async {
                  Navigator.pop(context);
                  final success = await ShareService.shareViaTelegram(
                    jobTitle: jobTitle,
                    jobDescription: jobDescription,
                    budget: budget,
                    category: category,
                    jobId: jobId,
                  );
                  if (!success && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Could not open Telegram'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                },
              ),
              _ShareOption(
                icon: Icons.more_horiz,
                label: 'More',
                color: Colors.grey.shade700,
                onTap: () async {
                  Navigator.pop(context);
                  final success = await ShareService.shareViaSystem(
                    jobTitle: jobTitle,
                    jobDescription: jobDescription,
                    budget: budget,
                    category: category,
                    jobId: jobId,
                  );
                  if (!success && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Could not open share options'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                },
              ),
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

class _ShareOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ShareOption({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: Colors.grey.shade700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}


import 'package:flutter/material.dart';
import 'auth_service.dart';
import 'storage_service.dart';
import 'user_service.dart';

/// Manages user authentication session and auto-login
class AuthSessionManager {
  static final AuthSessionManager _instance = AuthSessionManager._internal();
  factory AuthSessionManager() => _instance;
  AuthSessionManager._internal();

  bool _isRestoringSession = false;
  bool _isSessionRestored = false;

  /// Check if session is currently being restored
  bool get isRestoringSession => _isRestoringSession;

  /// Check if session has been restored
  bool get isSessionRestored => _isSessionRestored;

  /// Restore user session on app startup
  /// Returns true if session was successfully restored, false otherwise
  Future<bool> restoreSession() async {
    if (_isRestoringSession || _isSessionRestored) {
      return _isSessionRestored;
    }

    _isRestoringSession = true;

    try {
      // Check if user has tokens
      final accessToken = await StorageService.getAccessToken();
      final refreshToken = await StorageService.getRefreshToken();

      if (accessToken == null || accessToken.isEmpty) {
        // No access token, check if we have refresh token
        if (refreshToken != null && refreshToken.isNotEmpty) {
          // Try to refresh access token
          try {
            final result = await AuthService.refreshAccessToken();
            if (result['success'] == true) {
              _isSessionRestored = true;
              _isRestoringSession = false;
              return true;
            }
          } catch (e) {
            // Refresh failed, clear tokens
            await AuthService.logout();
            _isSessionRestored = false;
            _isRestoringSession = false;
            return false;
          }
        }
        _isSessionRestored = false;
        _isRestoringSession = false;
        return false;
      }

      // We have access token, verify it's still valid by fetching user profile
      try {
        final user = await UserService.getProfile();
        if (user != null && user['_id'] != null) {
          _isSessionRestored = true;
          _isRestoringSession = false;
          return true;
        }
      } catch (e) {
        // Access token might be expired, try refresh
        if (refreshToken != null && refreshToken.isNotEmpty) {
          try {
            final result = await AuthService.refreshAccessToken();
            if (result['success'] == true) {
              _isSessionRestored = true;
              _isRestoringSession = false;
              return true;
            }
          } catch (e) {
            // Refresh failed, clear tokens
            await AuthService.logout();
            _isSessionRestored = false;
            _isRestoringSession = false;
            return false;
          }
        } else {
          // No refresh token, clear session
          await AuthService.logout();
          _isSessionRestored = false;
          _isRestoringSession = false;
          return false;
        }
      }

      _isSessionRestored = false;
      _isRestoringSession = false;
      return false;
    } catch (e) {
      // Any error during session restore, clear tokens
      await AuthService.logout();
      _isSessionRestored = false;
      _isRestoringSession = false;
      return false;
    }
  }

  /// Check if user is logged in (synchronous check)
  Future<bool> isLoggedIn() async {
    return await StorageService.isLoggedIn();
  }

  /// Reset session state (useful after logout)
  void reset() {
    _isRestoringSession = false;
    _isSessionRestored = false;
  }
}


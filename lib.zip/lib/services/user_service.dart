import 'api_service.dart';
import 'cache_service.dart';

class UserService {
  // Get current user profile (with caching)
  static Future<Map<String, dynamic>> getProfile({bool useCache = true}) async {
    // Try cache first
    if (useCache) {
      final cached = await CacheService.getCachedUserProfile();
      if (cached != null) {
        // Return cached data immediately, then refresh in background
        _refreshProfileInBackground();
        return cached;
      }
    }
    
    // Fetch fresh data
    final response = await ApiService.get('/users/me');
    final user = response['data']['user'];
    
    // Cache the result
    await CacheService.cacheUserProfile(user);
    
    return user;
  }

  // Refresh profile in background
  static Future<void> _refreshProfileInBackground() async {
    try {
      final response = await ApiService.get('/users/me');
      final user = response['data']['user'];
      await CacheService.cacheUserProfile(user);
    } catch (e) {
      // Silently fail - cache will be used
    }
  }

  // Update user profile
  // CAMPUS-ONLY RULE: university is optional - only sent during initial setup
  // After initial setup, university becomes locked and cannot be changed
  static Future<Map<String, dynamic>> updateProfile({
    required String name,
    String? university, // Optional - only for initial setup
    required List<String> skills,
    required String about,
    String? yearOfStudy,
    String? profession,
    String? profileImage,
  }) async {
    final Map<String, dynamic> body = {
      'name': name,
      'skills': skills,
      'about': about,
    };
    
    // Only include university if provided (initial setup)
    if (university != null && university.isNotEmpty) {
      body['university'] = university;
    }
    
    // Add optional fields - always send if provided (even if empty, so backend can clear them)
    if (yearOfStudy != null) {
      body['yearOfStudy'] = yearOfStudy.isNotEmpty ? yearOfStudy : null;
    }
    if (profession != null) {
      body['profession'] = profession.isNotEmpty ? profession : null;
    }
    if (profileImage != null) {
      body['profileImage'] = profileImage.isNotEmpty ? profileImage : null;
    }
    
    final response = await ApiService.put('/users/me', body);
    final user = response['data']['user'];
    
    // Update cache
    await CacheService.cacheUserProfile(user);
    
    return user;
  }

  // Clear cache (e.g., on logout)
  static Future<void> clearCache() async {
    await CacheService.clearCache();
  }
}


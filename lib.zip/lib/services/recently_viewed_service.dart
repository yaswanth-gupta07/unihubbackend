import 'api_service.dart';
import 'package:flutter/foundation.dart';

class RecentlyViewedService extends ChangeNotifier {
  RecentlyViewedService._internal();
  static final RecentlyViewedService instance = RecentlyViewedService._internal();

  List<Map<String, dynamic>> _items = [];
  bool _isLoading = false;
  bool _isSynced = false;

  List<Map<String, dynamic>> get items => List.unmodifiable(_items);
  bool get isLoading => _isLoading;
  bool get isSynced => _isSynced;

  // Sync recently viewed from server
  Future<void> syncFromServer() async {
    if (_isLoading) return;
    
    _isLoading = true;
    notifyListeners();

    try {
      final response = await ApiService.get('/recently-viewed?limit=20');
      if (response['success'] == true) {
        _items = List<Map<String, dynamic>>.from(
          response['data']['products'] ?? []
        );
        _isSynced = true;
      }
    } catch (e) {
      print('Error syncing recently viewed: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Track product view
  Future<void> trackView(Map<String, dynamic> product) async {
    try {
      final productId = product['_id']?.toString();
      if (productId == null) return;

      // Track on server
      await ApiService.post('/recently-viewed', {
        'productId': productId,
      });

      // Update local list - move to front if exists, else add
      _items.removeWhere((p) => p['_id']?.toString() == productId);
      _items.insert(0, Map<String, dynamic>.from(product));
      
      // Keep only last 20 items
      if (_items.length > 20) {
        _items = _items.sublist(0, 20);
      }
      
      notifyListeners();
    } catch (e) {
      print('Error tracking view: $e');
    }
  }

  // Clear recently viewed
  void clear() {
    _items.clear();
    _isSynced = false;
    notifyListeners();
  }
}


import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class CacheService {
  static const _storage = FlutterSecureStorage();
  static const Duration _defaultCacheDuration = Duration(minutes: 5);

  // Cache user profile (cache for 10 minutes)
  static Future<void> cacheUserProfile(Map<String, dynamic> profile) async {
    try {
      await _storage.write(
        key: 'cached_user_profile',
        value: json.encode({
          'data': profile,
          'timestamp': DateTime.now().millisecondsSinceEpoch,
        }),
      );
    } catch (e) {
      print('Error caching user profile: $e');
    }
  }

  static Future<Map<String, dynamic>?> getCachedUserProfile() async {
    try {
      final cached = await _storage.read(key: 'cached_user_profile');
      if (cached != null) {
        final decoded = json.decode(cached);
        final timestamp = decoded['timestamp'] as int;
        final age = DateTime.now().millisecondsSinceEpoch - timestamp;
        
        // Cache valid for 10 minutes
        if (age < 10 * 60 * 1000) {
          return decoded['data'] as Map<String, dynamic>;
        }
      }
    } catch (e) {
      print('Error reading cached user profile: $e');
    }
    return null;
  }

  // Cache products feed (cache for 2 minutes)
  static Future<void> cacheProductsFeed(List<dynamic> products, {String? search, String? category}) async {
    try {
      final cacheKey = 'cached_products_${category ?? 'all'}_${search ?? ''}';
      await _storage.write(
        key: cacheKey,
        value: json.encode({
          'data': products,
          'timestamp': DateTime.now().millisecondsSinceEpoch,
        }),
      );
    } catch (e) {
      print('Error caching products: $e');
    }
  }

  static Future<List<dynamic>?> getCachedProductsFeed({String? search, String? category}) async {
    try {
      final cacheKey = 'cached_products_${category ?? 'all'}_${search ?? ''}';
      final cached = await _storage.read(key: cacheKey);
      if (cached != null) {
        final decoded = json.decode(cached);
        final timestamp = decoded['timestamp'] as int;
        final age = DateTime.now().millisecondsSinceEpoch - timestamp;
        
        // Cache valid for 2 minutes
        if (age < 2 * 60 * 1000) {
          return List<dynamic>.from(decoded['data']);
        }
      }
    } catch (e) {
      print('Error reading cached products: $e');
    }
    return null;
  }

  // Cache jobs feed (cache for 2 minutes)
  static Future<void> cacheJobsFeed(List<dynamic> jobs) async {
    try {
      await _storage.write(
        key: 'cached_jobs_feed',
        value: json.encode({
          'data': jobs,
          'timestamp': DateTime.now().millisecondsSinceEpoch,
        }),
      );
    } catch (e) {
      print('Error caching jobs: $e');
    }
  }

  static Future<List<dynamic>?> getCachedJobsFeed() async {
    try {
      final cached = await _storage.read(key: 'cached_jobs_feed');
      if (cached != null) {
        final decoded = json.decode(cached);
        final timestamp = decoded['timestamp'] as int;
        final age = DateTime.now().millisecondsSinceEpoch - timestamp;
        
        // Cache valid for 2 minutes
        if (age < 2 * 60 * 1000) {
          return List<dynamic>.from(decoded['data']);
        }
      }
    } catch (e) {
      print('Error reading cached jobs: $e');
    }
    return null;
  }

  // Clear cache
  static Future<void> clearCache() async {
    try {
      await _storage.delete(key: 'cached_user_profile');
      // Note: Products and jobs cache will expire naturally
    } catch (e) {
      print('Error clearing cache: $e');
    }
  }
}


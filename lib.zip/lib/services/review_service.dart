import 'api_service.dart';

class ReviewService {
  // Create a review for a freelancer
  static Future<Map<String, dynamic>> createReview({
    required String jobId,
    required int rating,
    String? comment,
  }) async {
    final response = await ApiService.post(
      '/reviews',
      {
        'jobId': jobId,
        'rating': rating,
        if (comment != null && comment.isNotEmpty) 'comment': comment,
      },
    );
    
    // Handle response structure - check if data.review exists, otherwise return the full response
    if (response['data'] != null && response['data']['review'] != null) {
      return response['data']['review'];
    } else if (response['data'] != null) {
      return response['data'];
    } else {
      return response;
    }
  }

  // Get reviews for a freelancer
  static Future<Map<String, dynamic>> getFreelancerReviews(String freelancerId) async {
    final response = await ApiService.get('/reviews/freelancer/$freelancerId');
    return response['data'];
  }

  // Get review for a specific job
  static Future<Map<String, dynamic>?> getJobReview(String jobId) async {
    try {
      final response = await ApiService.get('/reviews/job/$jobId');
      return response['data']['review'];
    } catch (e) {
      // Review doesn't exist yet
      return null;
    }
  }
}


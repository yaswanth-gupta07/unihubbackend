import 'api_service.dart';

class JobService {
  // Get job feed (for freelancers) with pagination
  // Optional filters: search, category, experienceLevel, minBudget, maxBudget
  static Future<Map<String, dynamic>> getJobs({
    String? search,
    String? category,
    String? experienceLevel,
    double? minBudget,
    double? maxBudget,
    int page = 1,
    int limit = 20,
  }) async {
    final Map<String, String> queryParams = {};
    
    if (search != null && search.isNotEmpty) {
      queryParams['search'] = search;
    }
    if (category != null && category.isNotEmpty) {
      queryParams['category'] = category;
    }
    if (experienceLevel != null && experienceLevel.isNotEmpty) {
      queryParams['experienceLevel'] = experienceLevel;
    }
    if (minBudget != null) {
      queryParams['minBudget'] = minBudget.toString();
    }
    if (maxBudget != null) {
      queryParams['maxBudget'] = maxBudget.toString();
    }
    queryParams['page'] = page.toString();
    queryParams['limit'] = limit.toString();

    String queryString = '';
    if (queryParams.isNotEmpty) {
      queryString = '?' + queryParams.entries
          .map((e) => '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}')
          .join('&');
    }

    final response = await ApiService.get('/jobs$queryString');
    return {
      'jobs': response['data']['jobs'] ?? [],
      'total': response['data']['total'] ?? 0,
      'page': response['data']['page'] ?? page,
      'limit': response['data']['limit'] ?? limit,
      'totalPages': response['data']['totalPages'] ?? 1,
    };
  }

  // Get my jobs (for clients) with pagination
  static Future<Map<String, dynamic>> getMyJobs({int page = 1, int limit = 20}) async {
    final response = await ApiService.get('/jobs/my?page=$page&limit=$limit');
    return {
      'jobs': response['data']['jobs'] ?? [],
      'total': response['data']['total'] ?? 0,
      'page': response['data']['page'] ?? page,
      'limit': response['data']['limit'] ?? limit,
      'totalPages': response['data']['totalPages'] ?? 1,
    };
  }

  // Get assigned jobs (for freelancers)
  static Future<List<dynamic>> getAssignedJobs() async {
    final response = await ApiService.get('/jobs/assigned');
    return response['data']['jobs'] ?? [];
  }

  // Get job by ID
  static Future<Map<String, dynamic>> getJobById(String jobId) async {
    final response = await ApiService.get('/jobs/$jobId');
    return response['data']['job'];
  }

  // Create a new job
  static Future<Map<String, dynamic>> createJob({
    required String title,
    required String category,
    required String description,
    required double budget,
    required DateTime deadline,
    required String experienceLevel,
    List<String>? skillsRequired,
  }) async {
    try {
      final response = await ApiService.post(
        '/jobs',
        {
          'title': title,
          'category': category,
          'description': description,
          'budget': budget,
          'deadline': deadline.toIso8601String(),
          'experienceLevel': experienceLevel,
          'skillsRequired': skillsRequired ?? [],
        },
        timeout: const Duration(seconds: 45), // Longer timeout for email operations
      );
      
      // Check if response indicates success
      if (response['success'] == true && response['data'] != null) {
        return response['data']['job'];
      } else {
        throw Exception(response['message'] ?? 'Failed to post job');
      }
    } catch (e) {
      // Re-throw with better error message
      final errorMsg = e.toString();
      if (errorMsg.contains('timeout')) {
        // For timeouts, provide helpful message
        throw Exception('Request is taking longer than expected. Please check if your job was posted successfully.');
      }
      rethrow;
    }
  }

  // Start job (assign freelancer)
  static Future<Map<String, dynamic>> startJob(String jobId, String freelancerId) async {
    final response = await ApiService.put(
      '/jobs/$jobId/start',
      {'freelancerId': freelancerId},
    );
    return response['data']['job'];
  }

  // Mark job as completed (client)
  static Future<Map<String, dynamic>> completeJob(String jobId) async {
    final response = await ApiService.put('/jobs/$jobId/complete', {});
    return response['data']['job'];
  }

  // Submit work (freelancer marks work as complete)
  static Future<Map<String, dynamic>> submitWork(String jobId) async {
    final response = await ApiService.put('/jobs/$jobId/submit-work', {});
    return response['data']['job'];
  }

  // Confirm job completion (freelancer - closes job after client approval)
  static Future<Map<String, dynamic>> confirmJob(String jobId) async {
    final response = await ApiService.put('/jobs/$jobId/confirm', {});
    return response['data']['job'];
  }
}


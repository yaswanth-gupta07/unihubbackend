import 'api_service.dart';
import 'package:flutter/foundation.dart';

class PreferencesService extends ChangeNotifier {
  PreferencesService._internal();
  static final PreferencesService instance = PreferencesService._internal();

  Map<String, dynamic> _preferences = {};
  bool _isLoading = false;
  bool _isSynced = false;

  Map<String, dynamic> get preferences => Map.unmodifiable(_preferences);
  bool get isLoading => _isLoading;
  bool get isSynced => _isSynced;

  // Get preferences from server
  Future<void> syncFromServer() async {
    if (_isLoading) return;
    
    _isLoading = true;
    notifyListeners();

    try {
      final response = await ApiService.get('/preferences');
      if (response['success'] == true) {
        _preferences = Map<String, dynamic>.from(
          response['data']['preferences'] ?? {}
        );
        _isSynced = true;
      }
    } catch (e) {
      print('Error syncing preferences: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Update preferences
  Future<bool> updatePreferences(Map<String, dynamic> updates) async {
    try {
      final response = await ApiService.put('/preferences', updates);
      
      if (response['success'] == true) {
        _preferences = Map<String, dynamic>.from(
          response['data']['preferences'] ?? {}
        );
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print('Error updating preferences: $e');
      return false;
    }
  }

  // Get last selected category
  String? get lastSelectedCategory => _preferences['lastSelectedCategory'];

  // Get price range
  Map<String, dynamic>? get priceRange => _preferences['priceRange'];

  // Get condition preference
  List<String> get conditionPreference {
    final pref = _preferences['conditionPreference'];
    if (pref is List) {
      return List<String>.from(pref);
    }
    return [];
  }

  // Get last search query
  String? get lastSearchQuery => _preferences['lastSearchQuery'];

  // Set last selected category
  Future<void> setLastSelectedCategory(String? category) async {
    await updatePreferences({'lastSelectedCategory': category});
  }

  // Set price range
  Future<void> setPriceRange({double? min, double? max}) async {
    await updatePreferences({
      'priceRange': {
        'min': min,
        'max': max,
      },
    });
  }

  // Set condition preference
  Future<void> setConditionPreference(List<String> conditions) async {
    await updatePreferences({'conditionPreference': conditions});
  }

  // Set last search query
  Future<void> setLastSearchQuery(String? query) async {
    await updatePreferences({'lastSearchQuery': query});
  }
}


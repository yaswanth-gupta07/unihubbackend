import 'api_service.dart';

class ApplicationService {
  // Apply for a job
  static Future<Map<String, dynamic>> createApplication({
    required String jobId,
    required String message,
    String? coverLetter,
    String? phone,
    double? budget,
    String? pricingType,
    int? deliveryDays,
    List<String>? skills,
    String? portfolioLink,
    bool? agreementAccepted,
  }) async {
    try {
      final response = await ApiService.post(
        '/applications',
        {
          'jobId': jobId,
          'message': message,
          if (coverLetter != null) 'coverLetter': coverLetter,
          if (phone != null) 'phone': phone,
          if (budget != null) 'budget': budget,
          if (pricingType != null) 'pricingType': pricingType,
          if (deliveryDays != null) 'deliveryDays': deliveryDays,
          if (skills != null) 'skills': skills,
          if (portfolioLink != null) 'portfolioLink': portfolioLink,
          if (agreementAccepted != null) 'agreementAccepted': agreementAccepted,
        },
        timeout: const Duration(seconds: 45), // Longer timeout for email operations
      );
      
      // Check if response indicates success
      if (response['success'] == true && response['data'] != null) {
        return response['data']['application'];
      } else {
        throw Exception(response['message'] ?? 'Failed to submit proposal');
      }
    } catch (e) {
      // Re-throw with better error message
      final errorMsg = e.toString();
      if (errorMsg.contains('timeout')) {
        // For timeouts, check if the application was actually created
        // This is a best-effort check - in a real app, you might want to verify server-side
        throw Exception('Request is taking longer than expected. Please check if your proposal was submitted successfully.');
      }
      rethrow;
    }
  }

  // Get freelancer applications (applications they submitted)
  static Future<List<dynamic>> getFreelancerApplications() async {
    final response = await ApiService.get('/applications/freelancer');
    return response['data']['applications'] ?? [];
  }

  // Get client applications (applications for their jobs)
  static Future<List<dynamic>> getClientApplications() async {
    final response = await ApiService.get('/applications/client');
    return response['data']['applications'] ?? [];
  }

  // Delete/decline an application
  static Future<void> deleteApplication(String applicationId) async {
    await ApiService.delete('/applications/$applicationId');
  }
}


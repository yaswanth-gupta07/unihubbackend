import 'package:flutter/material.dart';

class TermsAndPrivacyScreen extends StatelessWidget {
  const TermsAndPrivacyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: const Text(
          'Terms & Conditions',
          style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 18,
          ),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Container(
          constraints: const BoxConstraints(maxWidth: 800),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title
              const Text(
                'Terms & Conditions',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1A1A1A),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Last updated: ${_getLastUpdatedDate()}',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey.shade600,
                ),
              ),
              const SizedBox(height: 32),

              // Platform Role Disclaimer
              _buildSection(
                title: '1. Platform Role',
                content:
                    'UniHub is a connection-only platform that facilitates interactions between students for freelancing services and marketplace listings. UniHub does not handle payments, mediate disputes, or guarantee the quality of work or items listed.',
              ),

              // Freelancing Section
              _buildSection(
                title: '2. Freelancing Services (UniLancer)',
                content:
                    'UniHub connects freelancers with clients seeking services. We do not verify the qualifications, skills, or work quality of freelancers. All agreements, payments, and work quality are the sole responsibility of the freelancer and client. UniHub is not responsible for any disputes, incomplete work, or payment issues between users.',
              ),

              // UniMarket Section
              _buildSection(
                title: '3. Marketplace (UniMarket)',
                content:
                    'UniMarket is a discovery platform where users can list items for sale. UniHub does not own, verify, or guarantee any items listed. All transactions, item conditions, and exchanges are the responsibility of the buyer and seller. We do not handle payments or mediate disputes related to marketplace transactions.',
              ),

              // No Payments / No Liability
              _buildSection(
                title: '4. No Payment Processing',
                content:
                    'UniHub does not process, handle, or facilitate any payments between users. All payment arrangements must be made directly between users. UniHub is not liable for any payment disputes, fraud, or financial issues arising from transactions between users.',
              ),

              // Prohibited Activities
              _buildSection(
                title: '5. Prohibited Activities',
                content:
                    'Users are prohibited from:\n\n'
                    '• Posting fraudulent, misleading, or illegal content\n'
                    '• Harassing, bullying, or engaging in discriminatory behavior\n'
                    '• Violating intellectual property rights\n'
                    '• Spamming or sending unsolicited messages\n'
                    '• Creating fake accounts or impersonating others\n'
                    '• Using the platform for any illegal activities\n'
                    '• Sharing personal contact information to circumvent platform features',
              ),

              // Account Suspension & Termination
              _buildSection(
                title: '6. Account Suspension & Termination',
                content:
                    'UniHub reserves the right to suspend or terminate accounts that violate these terms or engage in prohibited activities. Users may be permanently banned for serious violations. We are not obligated to provide refunds or compensation for suspended or terminated accounts.',
              ),

              // Privacy Policy
              _buildSection(
                title: '7. Privacy Policy',
                content:
                    'Data We Collect:\n\n'
                    '• Email address (for authentication via OTP)\n'
                    '• Profile information you provide (name, university, skills, bio)\n'
                    '• Messages and communications within the platform\n'
                    '• Listing information for marketplace items\n'
                    '• Usage data to improve platform functionality\n\n'
                    'Data We Do NOT Collect:\n\n'
                    '• Payment information or financial details\n'
                    '• Location data beyond what you choose to share\n'
                    '• Biometric data\n'
                    '• Information from third-party services without your consent\n\n'
                    'Your data is used solely to provide platform services and improve user experience. We do not sell your personal information to third parties.',
              ),

              // User Responsibilities
              _buildSection(
                title: '8. User Responsibilities',
                content:
                    'Users are responsible for:\n\n'
                    '• Maintaining the security of their account\n'
                    '• Verifying the identity and credentials of other users\n'
                    '• Ensuring all transactions comply with applicable laws\n'
                    '• Resolving disputes directly with other users\n'
                    '• Reporting suspicious or prohibited activities to UniHub',
              ),

              // Limitation of Liability
              _buildSection(
                title: '9. Limitation of Liability',
                content:
                    'UniHub provides the platform "as is" without warranties. We are not liable for:\n\n'
                    '• Any loss or damage from using the platform\n'
                    '• Disputes between users\n'
                    '• Work quality or service outcomes\n'
                    '• Marketplace transaction issues\n'
                    '• Unauthorized access to accounts\n'
                    '• Platform downtime or technical issues',
              ),

              // Changes to Terms
              _buildSection(
                title: '10. Changes to Terms',
                content:
                    'UniHub may update these terms from time to time. Continued use of the platform after changes constitutes acceptance of the updated terms. Users will be notified of significant changes through the app.',
              ),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required String content}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1A1A1A),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            content,
            style: TextStyle(
              fontSize: 15,
              height: 1.6,
              color: Colors.grey.shade800,
            ),
          ),
        ],
      ),
    );
  }

  String _getLastUpdatedDate() {
    final now = DateTime.now();
    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    return '${months[now.month - 1]} ${now.day}, ${now.year}';
  }
}


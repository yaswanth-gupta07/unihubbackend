import 'package:flutter/material.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'services/user_service.dart';

class MarketSelectionPage extends StatefulWidget {
  const MarketSelectionPage({Key? key}) : super(key: key);

  @override
  State<MarketSelectionPage> createState() => _MarketSelectionPageState();
}

class _MarketSelectionPageState extends State<MarketSelectionPage> {
  String userName = "User";
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadUserName();
  }

  Future<void> _loadUserName() async {
    try {
      final userData = await UserService.getProfile();
      setState(() {
        userName = userData['name'] ?? 'User';
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        userName = 'User';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: const Color(0xFFF7F7FB),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Logo + Header
              Row(
                children: const [
                  Icon(Icons.school_rounded, color: Color(0xFF6A1B9A), size: 34),
                  SizedBox(width: 8),
                  Text(
                    "UniHub",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF6A1B9A),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Welcome + Typing User Name
              _isLoading
                  ? const SizedBox(
                      height: 40,
                      child: Center(child: CircularProgressIndicator()),
                    )
                  : Row(
                      children: [
                        AnimatedTextKit(
                          repeatForever: false,
                          isRepeatingAnimation: false,
                          animatedTexts: [
                            TypewriterAnimatedText(
                              "Welcome $userName 👋",
                              textStyle: const TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87,
                              ),
                              speed: Duration(milliseconds: 150),
                            ),
                          ],
                        ),
                      ],
                    ),

              const SizedBox(height: 8),
              const Text(
                "Choose your marketplace to get started",
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black54,
                ),
              ),
              const SizedBox(height: 40),

              // Options
              Expanded(
                child: ListView(
                  children: [
                    _buildOptionCard(
                      context,
                      title: "UniLancer",
                      description: "Find skilled freelancers for your projects",
                      icon: Icons.work_outline,
                      gradientColors: const [
                        Color(0xFF8E24AA),
                        Color(0xFF6A1B9A),
                      ],
                      onTap: () => Navigator.pushNamed(context, '/unilancer'),
                      tagColor: const Color(0xFFAB47BC),
                    ),
                    const SizedBox(height: 25),
                    _buildOptionCard(
                      context,
                      title: "UniMarket",
                      description: "Buy & sell second-hand items on campus",
                      icon: Icons.storefront_outlined,
                      gradientColors: const [
                        Color(0xFF42A5F5),
                        Color(0xFF1E88E5),
                      ],
                      onTap: () => Navigator.pushNamed(context, '/unimarket'),
                      tagColor: const Color(0xFF64B5F6),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOptionCard(
      BuildContext context, {
        required String title,
        required String description,
        required IconData icon,
        required List<Color> gradientColors,
        required Color tagColor,
        required VoidCallback onTap,
      }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 150,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradientColors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: gradientColors.last.withOpacity(0.3),
              blurRadius: 12,
              offset: const Offset(2, 6),
            ),
          ],
        ),
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.25),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(icon, size: 40, color: Colors.white),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      title.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    description,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                      height: 1.3,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios,
                color: Colors.white70, size: 22),
          ],
        ),
      ),
    );
  }
}

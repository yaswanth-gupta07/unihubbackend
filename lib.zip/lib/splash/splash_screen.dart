import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../onboarding/onboarding_screen.dart';
import '../auth/signin_screen.dart';
import '../MarketSelection.dart';
import '../services/auth_session_manager.dart';
import '../services/storage_service.dart';

class SplashScreen extends StatefulWidget {
  static const route = '/splash';
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat();

    _checkSessionAndNavigate();
  }

  Future<void> _checkSessionAndNavigate() async {
    // Wait for splash animation (minimum 1.5 seconds)
    await Future.delayed(const Duration(milliseconds: 1500));

    if (!mounted) return;

    try {
      // Try to restore session
      final sessionManager = AuthSessionManager();
      final sessionRestored = await sessionManager.restoreSession();

      if (!mounted) return;

      if (sessionRestored) {
        // Session restored, check if profile is complete
        final userData = await StorageService.getUserData();
        final isProfileComplete = userData?['profileComplete'] == true;

        if (isProfileComplete) {
          // Navigate to market selection (main app)
          Navigator.pushReplacementNamed(context, '/home');
        } else {
          // Profile incomplete, go to profile setup
          Navigator.pushReplacementNamed(context, OnboardingScreen.route);
        }
      } else {
        // No valid session, go to login
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const SigninPage()),
        );
      }
    } catch (e) {
      // Error during session restore, go to login
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const SigninPage()),
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  LinearGradient get _bg => const LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color.fromRGBO(97, 0, 248, 1.0),
      Color.fromRGBO(150, 60, 255, 1.0),
      Color.fromRGBO(207, 107, 246, 1.0)
    ],
    stops: [0.0, 0.5, 1.0],
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(gradient: _bg),
        width: double.infinity,
        height: double.infinity,
        child: SafeArea(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 75, vertical: 20),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(40),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 18,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.school_outlined,
                    color: Colors.white,
                    size: 36,
                  ),
                ),
                const SizedBox(height: 28),
                const Text(
                  'UniHub',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 36,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Connect. Create. Collaborate.\nWhere students hire and get hired.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white70,
                    height: 1.4,
                    fontSize: 14.5,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 28),
                _WaveDots(controller: _controller),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _WaveDots extends StatelessWidget {
  const _WaveDots({required this.controller});
  final AnimationController controller;

  @override
  Widget build(BuildContext context) {
    const amplitude = 6.0;
    const size = 8.0;
    const gap = 12.0;

    Widget dot(double phase) {
      return AnimatedBuilder(
        animation: controller,
        builder: (_, __) {
          final t = controller.value * 2 * math.pi;
          final dy = math.sin(t + phase) * amplitude;
          return Transform.translate(
            offset: Offset(0, dy),
            child: Container(
              width: size,
              height: size,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
            ),
          );
        },
      );
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        dot(0),
        const SizedBox(width: gap),
        dot(0.8),
        const SizedBox(width: gap),
        dot(1.6),
      ],
    );
  }
}

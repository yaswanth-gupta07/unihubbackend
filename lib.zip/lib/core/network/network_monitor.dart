import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';

/// Global network monitor that tracks internet connectivity
/// 
/// This class provides:
/// - Real-time connectivity status via stream
/// - Manual connectivity check
/// - Automatic recovery detection
class NetworkMonitor {
  static final NetworkMonitor _instance = NetworkMonitor._internal();
  factory NetworkMonitor() => _instance;
  NetworkMonitor._internal();

  final Connectivity _connectivity = Connectivity();
  final InternetConnectionChecker _connectionChecker = InternetConnectionChecker();
  
  // Stream controller for broadcasting connectivity status
  final _connectivityController = StreamController<bool>.broadcast();
  
  // Current connectivity status
  bool _isConnected = true;
  StreamSubscription<ConnectivityResult>? _connectivitySubscription;
  Timer? _periodicCheckTimer;

  /// Stream that emits true when online, false when offline
  Stream<bool> get connectivityStream => _connectivityController.stream;

  /// Current connectivity status
  bool get isConnected => _isConnected;

  /// Initialize the network monitor
  /// Call this in main() or app initialization
  Future<void> initialize() async {
    // Check initial connectivity
    await checkNow();
    
    // Listen to connectivity changes
    _connectivitySubscription = _connectivity.onConnectivityChanged.listen(
      _onConnectivityChanged,
      onError: (error) {
        print('NetworkMonitor connectivity error: $error');
        _updateStatus(false);
      },
    );

    // Periodic check every 5 seconds to catch edge cases
    _periodicCheckTimer = Timer.periodic(
      const Duration(seconds: 5),
      (_) => checkNow(),
    );
  }

  /// Handle connectivity change events
  Future<void> _onConnectivityChanged(ConnectivityResult result) async {
    // If no connectivity at all, immediately mark as offline
    if (result == ConnectivityResult.none) {
      _updateStatus(false);
      return;
    }

    // If we have some connectivity, verify actual internet access
    await checkNow();
  }

  /// Manually check internet connectivity
  /// Returns true if connected, false otherwise
  Future<bool> checkNow() async {
    try {
      // First check if we have any network interface
      final connectivityResult = await _connectivity.checkConnectivity();
      
      if (connectivityResult == ConnectivityResult.none) {
        _updateStatus(false);
        return false;
      }

      // Then verify actual internet access
      final hasInternet = await _connectionChecker.hasConnection;
      _updateStatus(hasInternet);
      return hasInternet;
    } catch (e) {
      print('NetworkMonitor checkNow error: $e');
      _updateStatus(false);
      return false;
    }
  }

  /// Update connectivity status and notify listeners
  void _updateStatus(bool connected) {
    if (_isConnected != connected) {
      _isConnected = connected;
      _connectivityController.add(_isConnected);
      print('NetworkMonitor: Status changed to ${connected ? "ONLINE" : "OFFLINE"}');
    }
  }

  /// Dispose resources
  void dispose() {
    _connectivitySubscription?.cancel();
    _periodicCheckTimer?.cancel();
    _connectivityController.close();
  }
}


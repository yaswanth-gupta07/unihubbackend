import 'package:flutter/material.dart';
import 'dart:async';
import '../network/network_monitor.dart';
import '../../ui/screens/no_internet_screen.dart';

/// Network Guard Widget
/// 
/// Wraps screens and automatically shows NoInternetScreen when offline.
/// When online, shows the original child widget.
/// 
/// Usage:
/// ```dart
/// NetworkGuard(
///   child: YourScreen(),
/// )
/// ```
class NetworkGuard extends StatefulWidget {
  final Widget child;
  final bool showOfflineScreen; // Allow disabling for specific screens if needed

  const NetworkGuard({
    super.key,
    required this.child,
    this.showOfflineScreen = true,
  });

  @override
  State<NetworkGuard> createState() => _NetworkGuardState();
}

class _NetworkGuardState extends State<NetworkGuard> {
  final NetworkMonitor _networkMonitor = NetworkMonitor();
  StreamSubscription<bool>? _connectivitySubscription;
  bool _isOnline = true;
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    // Check initial status
    _isOnline = await _networkMonitor.checkNow();
    
    if (mounted) {
      setState(() {
        _isInitialized = true;
      });
    }

    // Listen for connectivity changes
    _connectivitySubscription = _networkMonitor.connectivityStream.listen(
      (isConnected) {
        if (mounted) {
          setState(() {
            _isOnline = isConnected;
          });
          
          // If connection restored, optionally refresh the child
          if (isConnected) {
            // Trigger rebuild of child if it has a refresh mechanism
            // This is handled by the child widget itself
          }
        }
      },
    );
  }

  void _handleRetry() {
    // Force a connectivity check
    _networkMonitor.checkNow();
  }

  @override
  void dispose() {
    _connectivitySubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Show loading while initializing
    if (!_isInitialized) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    // If offline and should show offline screen
    if (!_isOnline && widget.showOfflineScreen) {
      return NoInternetScreen(
        onRetry: _handleRetry,
        child: widget.child,
      );
    }

    // Online - show original child
    return widget.child;
  }
}


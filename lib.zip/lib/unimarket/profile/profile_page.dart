import 'package:flutter/material.dart';
import '../../core/widgets/network_guard.dart';
import '../main.dart';
import '../../auth/signin_screen.dart';
import '../../services/product_service.dart';
import '../../services/user_service.dart';
import '../../services/auth_service.dart';
import 'edit_product_page.dart';

class EditListingPage extends StatefulWidget {
  final Map<String, dynamic> listing;

  const EditListingPage({Key? key, required this.listing}) : super(key: key);

  @override
  State<EditListingPage> createState() => _EditListingPageState();
}

class _EditListingPageState extends State<EditListingPage> {
  late TextEditingController _titleController;
  late TextEditingController _priceController;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.listing['title']?.toString() ?? '');
    _priceController = TextEditingController(text: widget.listing['price']?.toString().replaceAll(RegExp('[^0-9\\.]'), '') ?? '');
  }

  @override
  void dispose() {
    _titleController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final String rawPrice = _priceController.text.trim();
    final String formattedPrice = rawPrice.isEmpty ? '' : '\u20B9$rawPrice';

    final updated = Map<String, dynamic>.from(widget.listing)
      ..update('title', (_) => _titleController.text.trim(), ifAbsent: () => _titleController.text.trim())
      ..update('price', (_) => formattedPrice, ifAbsent: () => formattedPrice);

    Navigator.pop(context, updated);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Listing'),
        centerTitle: true,
        actions: [
          TextButton(
            onPressed: _save,
            child: const Text('Save', style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold)),
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Title', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87)),
              const SizedBox(height: 8),
              TextFormField(
                controller: _titleController,
                decoration: InputDecoration(
                  hintText: 'Enter title',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Title required' : null,
              ),
              const SizedBox(height: 16),
              const Text('Price', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87)),
              const SizedBox(height: 8),
              TextFormField(
                controller: _priceController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  prefixText: '₹ ',
                  hintText: '0.00',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Price required' : null,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Map<String, dynamic>? userData;
  List<dynamic> listings = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      // Load user profile and products in parallel for better performance
      final results = await Future.wait([
        UserService.getProfile(useCache: true),
        ProductService.getMyProducts(),
      ]);
      
      final user = results[0] as Map<String, dynamic>;
      final response = results[1] as Map<String, dynamic>;
      
      // Response now has active and sold groups
      final activeProducts = response['active'] ?? [];
      final soldProducts = response['sold'] ?? [];
      
      setState(() {
        userData = user;
        listings = [
          ...activeProducts.map((p) => {
            '_id': p['_id'],
            'title': p['title'],
            'price': '₹${p['price']?.toString() ?? '0'}',
            'status': 'Active',
            'image': (p['images'] != null && (p['images'] as List).isNotEmpty)
                ? p['images'][0]
                : '',
            'interestedBuyers': p['interestedBuyers'] ?? [],
            'fullProduct': p, // Store full product for editing
          }),
          ...soldProducts.map((p) => {
            '_id': p['_id'],
            'title': p['title'],
            'price': '₹${p['price']?.toString() ?? '0'}',
            'status': 'Sold',
            'image': (p['images'] != null && (p['images'] as List).isNotEmpty)
                ? p['images'][0]
                : '',
            'interestedBuyers': p['interestedBuyers'] ?? [],
            'fullProduct': p,
          }),
        ];
        _isLoading = false;
        _error = null;
      });
    } catch (e) {
      setState(() {
        // Provide user-friendly error message
        final errorMsg = e.toString();
        if (errorMsg.contains('timeout') || errorMsg.contains('Connection')) {
          _error = 'Connection timeout. Please check your internet connection.';
        } else if (errorMsg.contains('SocketException')) {
          _error = 'No internet connection. Please check your network.';
        } else {
          _error = 'Failed to load profile. Please try again.';
        }
        _isLoading = false;
      });
    }
  }

  Future<void> _deleteListing(String id) async {
    try {
      await ProductService.markProductSold(id);
      _loadData(); // Reload to refresh the list
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Product marked as sold'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _editListing(Map<String, dynamic> listing) async {
    // Navigate to edit page
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditProductPage(product: listing['fullProduct'] ?? listing),
      ),
    );
    
    if (result == true) {
      // Reload data after editing
      _loadData();
    }
  }

  void _showInterestedBuyers(Map<String, dynamic> listing) {
    final buyers = listing['interestedBuyers'] as List? ?? [];
    
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        expand: false,
        builder: (context, scrollController) => Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: Colors.grey.shade300),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Interested Buyers',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
            Expanded(
              child: buyers.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.person_outline, size: 64, color: Colors.grey[400]),
                          const SizedBox(height: 16),
                          Text(
                            'No interested buyers yet',
                            style: TextStyle(color: Colors.grey[600], fontSize: 16),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      controller: scrollController,
                      padding: const EdgeInsets.all(16),
                      itemCount: buyers.length,
                      itemBuilder: (context, index) {
                        final buyer = buyers[index];
                        return Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          child: ListTile(
                            contentPadding: const EdgeInsets.all(16),
                            title: Text(
                              buyer['buyerName'] ?? 'Unknown',
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 8),
                                Text('Email: ${buyer['buyerEmail'] ?? 'N/A'}'),
                                if (buyer['phone'] != null && buyer['phone'].toString().isNotEmpty)
                                  Text('Phone: ${buyer['phone']}'),
                                const SizedBox(height: 8),
                                Text(
                                  'Message:',
                                  style: TextStyle(fontWeight: FontWeight.w500, color: Colors.grey[700]),
                                ),
                                const SizedBox(height: 4),
                                Text(buyer['message'] ?? 'No message'),
                                const SizedBox(height: 8),
                                Text(
                                  'Applied: ${_formatDate(buyer['createdAt'])}',
                                  style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDate(dynamic date) {
    if (date == null) return 'Unknown';
    try {
      final dateTime = DateTime.parse(date.toString());
      return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
    } catch (e) {
      return 'Unknown';
    }
  }

  Future<void> _signOut(BuildContext context) async {
    if (!mounted) return;
    
    // Show loading indicator
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(child: CircularProgressIndicator()),
    );
    
    try {
      // Clear all data with timeout to prevent hanging
      await AuthService.logout().timeout(
        const Duration(seconds: 3),
        onTimeout: () {
          // If logout times out, continue anyway - local data will be cleared
          print('Logout timeout - continuing with local cleanup');
        },
      );
    } catch (e) {
      // Continue even if logout fails - we'll clear local data anyway
      print('Logout error: $e');
    }
    
    if (!mounted) return;
    
    // Close loading dialog immediately
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }
    
    // Small delay to ensure dialog is dismissed before navigation
    await Future.delayed(const Duration(milliseconds: 100));
    
    if (!mounted) return;
    
    // Navigate to sign in page
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const SigninPage()),
      (route) => false,
    );
  }

  void _showSignOutConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Sign Out'),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
            child: const Text('Cancel'),
            onPressed: () => Navigator.of(context).pop(),
          ),
          TextButton(
            child: const Text('Sign Out', style: TextStyle(color: Colors.red)),
            onPressed: () {
              Navigator.of(context).pop();
              _signOut(context);
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return NetworkGuard(
      child: Builder(
        builder: (context) {
          if (_isLoading) {
            return Scaffold(
              appBar: AppBar(
                title: const Text('Profile'),
                centerTitle: true,
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
                elevation: 0,
              ),
              body: const Center(child: CircularProgressIndicator()),
            );
          }

          if (_error != null) {
            return Scaffold(
              appBar: AppBar(
                title: const Text('Profile'),
                centerTitle: true,
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
                elevation: 0,
              ),
              body: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Error: $_error'),
                    ElevatedButton(
                      onPressed: _loadData,
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            );
          }

          final activeListings = listings.where((item) => item['status'] != 'Sold').toList();
          final soldListings = listings.where((item) => item['status'] == 'Sold').toList();
          final userName = userData?['name'] ?? 'Unknown User';
          final userEmail = userData?['email'] ?? '';

          return WillPopScope(
      onWillPop: () async {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const MainScreen()),
              (route) => false,
        );
        return false;
      },
      child: Scaffold(
      appBar: AppBar(
        title: const Text(
          'My Profile',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            letterSpacing: 0.5,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: Colors.grey.withOpacity(0.2),
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const MainScreen()),
                  (route) => false,
            );
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // User info - Enhanced Profile Section
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    spreadRadius: 2,
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.blue.withOpacity(0.2),
                          spreadRadius: 2,
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: CircleAvatar(
                      radius: 35,
                      backgroundColor: Colors.blue[50],
                      child: Text(
                        userName.isNotEmpty ? userName[0].toUpperCase() : 'U',
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue[700],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 18),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          userName,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 24,
                            letterSpacing: 0.5,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Icon(Icons.email_outlined, size: 16, color: Colors.grey[600]),
                            const SizedBox(width: 6),
                            Flexible(
                              child: Text(
                                userEmail,
                                style: TextStyle(
                                  color: Colors.grey[600],
                                  fontSize: 15,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            // Active section - Enhanced Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.green[50],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.shopping_bag_outlined, color: Colors.green[700], size: 20),
                ),
                const SizedBox(width: 10),
                const Text(
                  'Active Listings',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    letterSpacing: 0.3,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            ...activeListings.map((listing) => _buildListingCard(listing, false)).toList(),
            const SizedBox(height: 28),
            // Sold section - Enhanced Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.check_circle_outline, color: Colors.grey[700], size: 20),
                ),
                const SizedBox(width: 10),
                const Text(
                  'Sold Items',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    letterSpacing: 0.3,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            ...soldListings.map((listing) => _buildListingCard(listing, true)).toList(),
            
            // Sign Out Button - Enhanced (at the very bottom)
            const SizedBox(height: 40),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.red.withOpacity(0.2),
                    spreadRadius: 1,
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    elevation: 0,
                  ),
                  icon: const Icon(Icons.logout, color: Colors.white, size: 20),
                  label: const Text(
                    'Sign Out',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 0.5,
                    ),
                  ),
                  onPressed: () => _showSignOutConfirmation(context),
                ),
              ),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
          ),
        );
      },
      ),
    );
  }

  Widget _buildListingCard(Map<String, dynamic> listing, bool isSold) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: Colors.grey.withOpacity(0.1), width: 1),
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 1,
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: listing['image'] != null && listing['image'].toString().isNotEmpty
                      ? Image.network(
                          listing['image'],
                          width: 70,
                          height: 70,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              width: 70,
                              height: 70,
                              color: Colors.grey[300],
                              child: const Icon(Icons.image_not_supported, color: Colors.grey),
                            );
                          },
                        )
                      : Container(
                          width: 70,
                          height: 70,
                          color: Colors.grey[300],
                          child: const Icon(Icons.image_not_supported, color: Colors.grey),
                        ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: isSold ? Colors.grey[400] : Colors.green[500],
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        listing['status'],
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      listing['title'],
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                        color: Colors.black87,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      listing['price'],
                      style: TextStyle(
                        color: Colors.blue[700],
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
            if (!isSold)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.people_outline, color: Colors.blue, size: 23),
                    onPressed: () => _showInterestedBuyers(listing),
                    tooltip: 'Interested Buyers',
                  ),
                  IconButton(
                    icon: const Icon(Icons.edit, color: Colors.grey, size: 23),
                    onPressed: () => _editListing(listing),
                    tooltip: 'Edit',
                  ),
                  IconButton(
                    icon: const Icon(Icons.check_circle_outline, color: Colors.green, size: 23),
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: const Text('Mark as Sold'),
                          content: const Text('Are you sure you want to mark this product as sold?'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text('Cancel'),
                            ),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green,
                                foregroundColor: Colors.white,
                              ),
                              onPressed: () {
                                Navigator.pop(context);
                                _deleteListing(listing['_id']);
                              },
                              child: const Text('Mark as Sold'),
                            ),
                          ],
                        ),
                      );
                    },
                    tooltip: 'Mark as Sold',
                  ),
                ],
              )
          ],
        ),
      ),
      ),
    );
  }
}

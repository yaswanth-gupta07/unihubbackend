// wishlist_page.dart

import 'package:flutter/material.dart';
import '../../core/widgets/network_guard.dart';
import 'wishlist_service.dart';
import '../main.dart';
import '../ItemDetails_page.dart';

class WishlistPage extends StatefulWidget {
  const WishlistPage({Key? key}) : super(key: key);

  @override
  State<WishlistPage> createState() => _WishlistPageState();
}

class _WishlistPageState extends State<WishlistPage> {
  bool _isSyncing = false;

  @override
  void initState() {
    super.initState();
    WishlistService.instance.addListener(_onWishlistChanged);
    // Sync wishlist when page opens
    _syncWishlist();
  }

  @override
  void dispose() {
    WishlistService.instance.removeListener(_onWishlistChanged);
    super.dispose();
  }

  void _onWishlistChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _syncWishlist() async {
    setState(() {
      _isSyncing = true;
    });
    try {
      await WishlistService.instance.syncFromServer();
    } catch (e) {
      // Silently fail - wishlist will show cached items
      print('Wishlist sync error: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isSyncing = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = WishlistService.instance.items;
    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const MainScreen()),
              (route) => false,
        );
        return false;
      },
      child: Scaffold(
      appBar: AppBar(
        title: const Text('Wishlist'),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const MainScreen()),
                  (route) => false,
            );
          },
        ),
      ),
      body: _isSyncing
          ? const Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        child: items.isEmpty
            ? const Center(child: Text('No items in wishlist'))
            : ListView.separated(
          itemCount: items.length,
          separatorBuilder: (context, _) => const SizedBox(height: 14),
          itemBuilder: (context, idx) {
            final item = items[idx];
            return InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ItemDetailsPage(product: item),
                  ),
                );
              },
              child: Card(
                margin: EdgeInsets.zero,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: 1.5,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      // Text content
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 4),
                            Text(
                              item['name'] ?? item['title'] ?? '',
                              style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              item['price']?.toString() ?? '',
                              style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.indigo),
                            ),
                            const SizedBox(height: 14),
                            SizedBox(
                              height: 34,
                              child: ElevatedButton.icon(
                                onPressed: () {
                                  WishlistService.instance.remove(item);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.blue[600],
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(7),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 14, vertical: 0),
                                  elevation: 0,
                                ),
                                icon: const Icon(Icons.bookmark_remove_outlined),
                                label: const Text('Unsave', style: TextStyle(fontSize: 14)),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Image
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: () {
                          final dynamic images = item['images'];
                          final String? firstLocal = (images is List && images.isNotEmpty)
                              ? images.first.toString()
                              : item['image']?.toString();
                          if ((firstLocal ?? '').startsWith('http')) {
                            return Image.network(
                              firstLocal!,
                              width: 70,
                              height: 70,
                              fit: BoxFit.cover,
                              loadingBuilder: (context, child, loadingProgress) {
                                if (loadingProgress == null) return child;
                                return const Center(child: CircularProgressIndicator(strokeWidth: 2));
                              },
                              errorBuilder: (context, error, stackTrace) {
                                return const Icon(Icons.image_not_supported, size: 35, color: Colors.grey);
                              },
                              cacheWidth: 140,
                              cacheHeight: 140,
                            );
                          }
                          return Image.asset(
                            firstLocal ?? '',
                            width: 70,
                            height: 70,
                            fit: BoxFit.cover,
                          );
                        }(),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
      ),
    );
  }
}

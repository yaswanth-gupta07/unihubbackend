// DEPRECATED: This file is kept for backward compatibility
// Please use lib/services/wishlist_service.dart for cloud-synced wishlist
// This wrapper delegates to the new cloud service

import 'package:flutter/foundation.dart';
import '../../../services/wishlist_service.dart' as cloud;

class WishlistService extends ChangeNotifier {
  WishlistService._internal();
  static final WishlistService instance = WishlistService._internal();

  // Delegate to cloud wishlist service
  List<Map<String, dynamic>> get items => cloud.WishlistService.instance.items;

  bool isWished(Map<String, dynamic> product) {
    return cloud.WishlistService.instance.isWished(product);
  }

  Future<void> add(Map<String, dynamic> product) async {
    await cloud.WishlistService.instance.add(product);
    notifyListeners();
  }

  Future<void> remove(Map<String, dynamic> product) async {
    await cloud.WishlistService.instance.remove(product);
    notifyListeners();
  }

  Future<void> toggle(Map<String, dynamic> product) async {
    await cloud.WishlistService.instance.toggle(product);
    notifyListeners();
  }

  // Sync wishlist from server
  Future<void> syncFromServer() async {
    await cloud.WishlistService.instance.syncFromServer();
    notifyListeners();
  }

  // Listen to cloud service changes
  void _onCloudWishlistChanged() {
    notifyListeners();
  }

  void init() {
    cloud.WishlistService.instance.addListener(_onCloudWishlistChanged);
  }

  void dispose() {
    cloud.WishlistService.instance.removeListener(_onCloudWishlistChanged);
    super.dispose();
  }
}



import 'dart:io';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import '../main.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../../services/product_service.dart';
import '../../services/api_service.dart';
import 'package:http/http.dart' as http;

// Web support - using image_picker which supports web in newer versions


class PostPage extends StatefulWidget {
  const PostPage({super.key});

  @override
  State<PostPage> createState() => _PostPageState();
}

// Enum to manage the state of the condition buttons
enum Condition { New, Good, Used }

class _PostPageState extends State<PostPage> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();

  final ImagePicker _picker = ImagePicker();
  List<XFile> _imageFiles = [];
  List<Uint8List> _imageBytes = []; // For web display
  bool _isSubmitting = false;

  String _selectedCategory = 'Electronics';
  Condition _selectedCondition = Condition.Good;

  final List<String> _categories = [
    'Electronics', 'Books & Study', 'Room Essentials', 'Fashion',
    'Transport', 'Sports & Fitness', 'Kitchen', 'Miscellaneous'
  ];

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  /// Handles image selection from the gallery - supports both web and mobile
  Future<void> _pickImages() async {
    try {
      // Try to use image_picker (works on both web and mobile in newer versions)
      final List<XFile> selectedImages = await _picker.pickMultiImage();
      if (selectedImages.isNotEmpty) {
        final newFiles = <XFile>[];
        final newBytes = <Uint8List>[];
        
        // Read bytes for web display
        for (var file in selectedImages) {
          try {
            final bytes = await file.readAsBytes();
            newBytes.add(bytes);
            newFiles.add(file);
          } catch (e) {
            // If readAsBytes fails, still add the file (for mobile)
            newFiles.add(file);
          }
        }
        
        if (mounted) {
          setState(() {
            _imageFiles.addAll(newFiles);
            if (kIsWeb && newBytes.length == newFiles.length) {
              _imageBytes.addAll(newBytes);
            } else if (!kIsWeb) {
              // For mobile, read bytes when needed for display
              _imageBytes.clear(); // Will be populated on demand
            }
            
            if (_imageFiles.length > 5) {
              _imageFiles = _imageFiles.sublist(0, 5);
              if (_imageBytes.length > 5) {
                _imageBytes = _imageBytes.sublist(0, 5);
              }
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('You can only upload a maximum of 5 photos.'),
                  backgroundColor: Colors.orange,
                ),
              );
            }
          });
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error selecting images: $e\n\nNote: On web browsers, image picker may require user interaction.'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    }
  }

  /// Validates the form and submits the new item.
  Future<void> _submitPost() async {
    FocusScope.of(context).unfocus();

    if (!_formKey.currentState!.validate()) return;

    // Image is optional - allow posting without images
    // if (_imageFiles.isEmpty) {
    //   ScaffoldMessenger.of(context).showSnackBar(
    //     const SnackBar(
    //       content: Text('Please add at least one image'),
    //       backgroundColor: Colors.orange,
    //     ),
    //   );
    //   return;
    // }

    setState(() => _isSubmitting = true);
    
    // Show loading dialog
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(),
      ),
    );

    try {
      // Upload images first
      List<String> imageUrls = [];
      if (_imageFiles.isNotEmpty) {
        if (kIsWeb) {
          // For web, upload using bytes
          imageUrls = await ApiService.uploadImagesWeb(_imageFiles);
        } else {
          // For mobile, upload using file paths
          final imagePaths = _imageFiles.map((file) => file.path).toList();
          imageUrls = await ApiService.uploadImages(imagePaths);
        }
      }
      
      // Create product with uploaded image URLs
      final product = await ProductService.createProduct(
        title: _titleController.text.trim(),
        price: double.tryParse(_priceController.text) ?? 0.0,
        category: _selectedCategory,
        description: _descriptionController.text.trim(),
        condition: _selectedCondition.name, // New, Good, or Used
        images: imageUrls,
      );

      if (!mounted) return;
      
      // Close loading dialog
      Navigator.of(context).pop();

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Item posted successfully!'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );

      // Reset the form
      _formKey.currentState!.reset();
      _titleController.clear();
      _descriptionController.clear();
      _priceController.clear();
      setState(() {
        _imageFiles = [];
        _imageBytes = [];
        _selectedCategory = 'Electronics';
        _selectedCondition = Condition.Good;
        _isSubmitting = false;
      });

      // Navigate back to home page immediately
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const MainScreen()),
        (route) => false,
      );
    } catch (e) {
      if (!mounted) return;
      
      // Close loading dialog if open
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop();
      }
      
      setState(() => _isSubmitting = false);
      
      // Provide user-friendly error message
      final errorMsg = e.toString();
      String displayMsg = 'Failed to post item. Please try again.';
      if (errorMsg.contains('timeout') || errorMsg.contains('Connection')) {
        displayMsg = 'Connection timeout. Please check your internet connection and try again.';
      } else if (errorMsg.contains('SocketException')) {
        displayMsg = 'No internet connection. Please check your network.';
      }
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(displayMsg),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 4),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const MainScreen()),
              (route) => false,
        );
        return false;
      },
      child: Scaffold(
      appBar: AppBar(
        title: const Text('Post New Item', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const MainScreen()),
                  (route) => false,
            );
          },
        ),
        backgroundColor: Colors.grey[50],
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildImagePicker(),
              const SizedBox(height: 24),
              _buildTextField(label: 'Title', hint: 'e.g., Gently Used Macbook Air', controller: _titleController),
              const SizedBox(height: 16),
              _buildTextField(label: 'Description', hint: 'Describe your item in detail...', controller: _descriptionController, maxLines: 4),
              const SizedBox(height: 16),

              // ✅ This LayoutBuilder makes the Category/Price section responsive.
              LayoutBuilder(
                builder: (context, constraints) {
                  if (constraints.maxWidth < 450) {
                    // Use a Column on narrow screens
                    return Column(
                      children: [
                        _buildCategoryDropdown(),
                        const SizedBox(height: 20),
                        _buildPriceField(),
                      ],
                    );
                  } else {
                    // Use a Row on wider screens
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(child: _buildCategoryDropdown()),
                        const SizedBox(width: 16),
                        Expanded(child: _buildPriceField()),
                      ],
                    );
                  }
                },
              ),
              const SizedBox(height: 16),
              _buildConditionSelector(),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: _isSubmitting ? null : _submitPost,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[700],
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  elevation: 2,
                ),
                child: _isSubmitting
                    ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3))
                    : const Text('Post', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
      ),
    );
  }

  // --- Helper Widgets ---

  Widget _buildImagePicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Images', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87)),
        const SizedBox(height: 8),
        InkWell(
          onTap: _pickImages,
          child: Container(
            height: 150,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.grey[200],
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.grey[300]!),
            ),
            child: _imageFiles.isEmpty
                ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.camera_alt_outlined, size: 40, color: Colors.grey[700]),
                const SizedBox(height: 8),
                const Text('Upload Images', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black87)),
                const SizedBox(height: 4),
                Text('Add up to 5 photos', style: TextStyle(color: Colors.grey[600])),
              ],
            )
                : GridView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: _imageFiles.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              itemBuilder: (context, index) {
                // Display image - works for both web and mobile
                if (kIsWeb) {
                  // For web, use FutureBuilder to load image bytes
                  if (index < _imageBytes.length) {
                    return ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.memory(
                        _imageBytes[index],
                        fit: BoxFit.cover,
                      ),
                    );
                  } else {
                    // Load image bytes asynchronously
                    return FutureBuilder<Uint8List>(
                      future: _imageFiles[index].readAsBytes(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          // Cache the bytes
                          if (index >= _imageBytes.length) {
                            _imageBytes.add(snapshot.data!);
                          } else {
                            _imageBytes[index] = snapshot.data!;
                          }
                          return ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.memory(
                              snapshot.data!,
                              fit: BoxFit.cover,
                            ),
                          );
                        } else if (snapshot.hasError) {
                          return Container(
                            color: Colors.grey[300],
                            child: const Icon(Icons.image_not_supported),
                          );
                        } else {
                          return Container(
                            color: Colors.grey[300],
                            child: const Center(
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          );
                        }
                      },
                    );
                  }
                } else {
                  // Mobile - use file path
                  return ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.file(
                      File(_imageFiles[index].path),
                      fit: BoxFit.cover,
                    ),
                  );
                }
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTextField({
    required String label,
    required String hint,
    required TextEditingController controller,
    int maxLines = 1,
    IconData? icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87)),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: hint,
            suffixIcon: icon != null ? Icon(icon, color: Colors.grey) : null,
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.grey)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.grey.shade300)),
            errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.red, width: 1.5)),
            focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.red, width: 2)),
          ),
          validator: (value) {
            if (label == 'Title' && (value == null || value.isEmpty)) {
              return 'Please enter a title.';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildCategoryDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Category', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _selectedCategory,
          items: _categories.map((String category) => DropdownMenuItem<String>(value: category, child: Text(category))).toList(),
          onChanged: (newValue) => setState(() => _selectedCategory = newValue!),
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.grey)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.grey.shade300)),
          ),
        ),
      ],
    );
  }

  Widget _buildPriceField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Price', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87)),
        const SizedBox(height: 8),
        TextFormField(
          controller: _priceController,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}'))],
          decoration: InputDecoration(
            prefixText: '₹ ',
            hintText: '0.00',
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.grey)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.grey.shade300)),
            errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.red, width: 1.5)),
            focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.red, width: 2)),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter a price.';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildConditionSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Condition', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87)),
        const SizedBox(height: 8),
        Row(
          children: [
            _buildConditionButton(Condition.New, 'New'),
            const SizedBox(width: 12),
            _buildConditionButton(Condition.Good, 'Good'),
            const SizedBox(width: 12),
            _buildConditionButton(Condition.Used, 'Used'),
          ],
        ),
      ],
    );
  }

  Widget _buildConditionButton(Condition condition, String text) {
    final bool isSelected = _selectedCondition == condition;
    return Expanded(
      child: OutlinedButton(
        onPressed: () => setState(() => _selectedCondition = condition),
        style: OutlinedButton.styleFrom(
          backgroundColor: isSelected ? Colors.blue[700] : Colors.white,
          foregroundColor: isSelected ? Colors.white : Colors.black54,
          side: BorderSide(
            color: isSelected ? Colors.blue[700]! : Colors.grey.shade300,
            width: 1.5,
          ),
          padding: const EdgeInsets.symmetric(vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
        child: Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
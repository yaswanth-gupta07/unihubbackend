import 'package:flutter/material.dart';
import 'ItemDetails_page.dart';
import 'wishlist/wishlist_page.dart';
import 'wishlist/wishlist_service.dart';
import '../services/product_service.dart';

class CategoryDetailsPage extends StatefulWidget {
  final Map<String, dynamic> category;

  const CategoryDetailsPage({
    Key? key,
    required this.category,
  }) : super(key: key);

  @override
  State<CategoryDetailsPage> createState() => _CategoryDetailsPageState();
}

class _CategoryDetailsPageState extends State<CategoryDetailsPage> {
  List<Map<String, dynamic>> products = [];
  bool _isLoading = true;
  String? _error;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadCategoryProducts();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadCategoryProducts({String? search}) async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final categoryLabel = widget.category['label'] as String;
      final result = await ProductService.getProducts(
        category: categoryLabel,
        search: search,
        page: 1,
        limit: 100, // Get all products for category page
      );
      
      final fetchedProducts = result['products'] as List<dynamic>;
      
      setState(() {
        products = fetchedProducts.map((p) => <String, dynamic>{
          '_id': p['_id'],
          'name': p['title'] ?? '',
          'title': p['title'] ?? '',
          'price': '₹${p['price']?.toString() ?? '0'}',
          'description': p['description'] ?? '',
          'image': (p['images'] != null && (p['images'] as List).isNotEmpty)
              ? p['images'][0]
              : '',
          'images': p['images'] ?? [],
          'category': p['category'] ?? '',
          'condition': p['condition'] ?? '',
          'status': p['status'] ?? 'AVAILABLE',
          'sellerId': p['sellerId'],
        }).toList();
        _isLoading = false;
        _error = null;
      });
    } catch (e) {
      setState(() {
        // Provide user-friendly error message
        final errorMsg = e.toString();
        if (errorMsg.contains('timeout') || errorMsg.contains('Connection')) {
          _error = 'Connection timeout. Please check your internet connection.';
        } else if (errorMsg.contains('SocketException')) {
          _error = 'No internet connection. Please check your network.';
        } else {
          _error = 'Failed to load products. Please try again.';
        }
        _isLoading = false;
      });
    }
  }

  void _onSearchChanged(String value) {
    Future.delayed(const Duration(milliseconds: 500), () {
      if (_searchController.text == value) {
        _loadCategoryProducts(search: value.isEmpty ? null : value);
      }
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.category['label']),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Search field
          Padding(
            padding: const EdgeInsets.all(14.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search in ${widget.category['label']}',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _loadCategoryProducts();
                        },
                      )
                    : null,
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
              onChanged: _onSearchChanged,
            ),
          ),

          // Products grid
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _error != null
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('Error: $_error', style: const TextStyle(color: Colors.red)),
                            const SizedBox(height: 16),
                            ElevatedButton(
                              onPressed: () => _loadCategoryProducts(),
                              child: const Text('Retry'),
                            ),
                          ],
                        ),
                      )
                    : products.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.inbox_outlined, size: 64, color: Colors.grey[400]),
                                const SizedBox(height: 16),
                                Text(
                                  'No products in ${widget.category['label']}',
                                  style: TextStyle(color: Colors.grey[600], fontSize: 16),
                                ),
                              ],
                            ),
                          )
                        : Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: GridView.builder(
                              itemCount: products.length,
                              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                mainAxisSpacing: 16,
                                crossAxisSpacing: 16,
                                childAspectRatio: 0.78,
                              ),
                              itemBuilder: (context, idx) {
                                final prod = products[idx];
                                final isSold = prod['status'] == 'SOLD';
                                
                                return GestureDetector(
                                  behavior: HitTestBehavior.opaque,
                                  onTap: isSold ? null : () {
                                    final productId = prod['_id'];
                                    print('Product tapped: $productId'); // Debug
                                    
                                    if (productId == null || productId.toString().isEmpty) {
                                      if (mounted) {
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          const SnackBar(
                                            content: Text('Invalid product data'),
                                            backgroundColor: Colors.red,
                                          ),
                                        );
                                      }
                                      return;
                                    }
                                    
                                    try {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => ItemDetailsPage(
                                            product: prod,
                                            seller: prod['sellerId'],
                                          ),
                                        ),
                                      ).then((_) {
                                        // Refresh wishlist state when returning
                                        if (mounted) setState(() {});
                                      });
                                    } catch (e, stackTrace) {
                                      print('Navigation error: $e'); // Debug
                                      print('Stack trace: $stackTrace'); // Debug
                                      if (mounted) {
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          SnackBar(
                                            content: Text('Error opening product: $e'),
                                            backgroundColor: Colors.red,
                                            duration: const Duration(seconds: 3),
                                          ),
                                        );
                                      }
                                    }
                                  },
                                  child: Card(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    elevation: 1.5,
                                    child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Expanded(
                                        child: Stack(
                                          children: [
                                            Container(
                                              width: double.infinity,
                                              color: Colors.grey[200],
                                              child: prod['image'] != null && prod['image'].toString().isNotEmpty
                                                  ? (prod['image'].toString().startsWith('http')
                                                      ? Image.network(
                                                          prod['image'],
                                                          fit: BoxFit.cover,
                                                          loadingBuilder: (context, child, loadingProgress) {
                                                            if (loadingProgress == null) return child;
                                                            return Center(
                                                              child: CircularProgressIndicator(
                                                                value: loadingProgress.expectedTotalBytes != null
                                                                    ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                                                                    : null,
                                                              ),
                                                            );
                                                          },
                                                          errorBuilder: (context, error, stackTrace) {
                                                            return const Icon(Icons.image_not_supported, size: 50, color: Colors.grey);
                                                          },
                                                          cacheWidth: 300,
                                                          cacheHeight: 300,
                                                        )
                                                      : Image.asset(prod['image'], fit: BoxFit.cover))
                                                  : const Icon(Icons.image_not_supported, size: 50),
                                            ),
                                            // Sold overlay
                                            if (prod['status'] == 'SOLD')
                                              Container(
                                                width: double.infinity,
                                                color: Colors.black.withOpacity(0.6),
                                                child: Center(
                                                  child: Container(
                                                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                                    decoration: BoxDecoration(
                                                      color: Colors.red,
                                                      borderRadius: BorderRadius.circular(20),
                                                    ),
                                                    child: const Text(
                                                      'SOLD OUT',
                                                      style: TextStyle(
                                                        color: Colors.white,
                                                        fontWeight: FontWeight.bold,
                                                        fontSize: 16,
                                                        letterSpacing: 1.2,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                        child: Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                prod['name'] ?? prod['title'] ?? 'Untitled',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 15,
                                                  color: prod['status'] == 'SOLD' ? Colors.grey[600] : Colors.black,
                                                  decoration: prod['status'] == 'SOLD' ? TextDecoration.lineThrough : null,
                                                ),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                            if (prod['status'] == 'SOLD')
                                              Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                decoration: BoxDecoration(
                                                  color: Colors.red.shade100,
                                                  borderRadius: BorderRadius.circular(8),
                                                  border: Border.all(color: Colors.red.shade300),
                                                ),
                                                child: Text(
                                                  'SOLD',
                                                  style: TextStyle(
                                                    color: Colors.red.shade700,
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(horizontal: 10),
                                        child: Row(
                                          children: [
                                            Text(
                                              prod['price'] ?? '₹0',
                                              style: TextStyle(
                                                color: isSold ? Colors.grey[600] : Colors.indigo,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14,
                                                decoration: isSold ? TextDecoration.lineThrough : null,
                                              ),
                                            ),
                                            const Spacer(),
                                            GestureDetector(
                                              onTap: () {
                                                setState(() {});
                                                WishlistService.instance.toggle(prod);
                                              },
                                              child: Padding(
                                                padding: const EdgeInsets.all(8.0),
                                                child: Icon(
                                                  WishlistService.instance.isWished(prod)
                                                      ? Icons.favorite
                                                      : Icons.favorite_border,
                                                  color: WishlistService.instance.isWished(prod) ? Colors.red : Colors.grey,
                                                  size: 20,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(height: 5),
                                    ],
                                  ),
                                ),
                              );
                              },
                            ),
                          ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'wishlist/wishlist_service.dart';
import '../services/product_service.dart';
import '../../core/widgets/network_guard.dart';

class ItemDetailsPage extends StatefulWidget {
  final Map<String, dynamic> product;
  final Map<String, dynamic>? seller;

  const ItemDetailsPage({
    Key? key,
    required this.product,
    this.seller,
  }) : super(key: key);

  @override
  State<ItemDetailsPage> createState() => _ItemDetailsPageState();
}

class _ItemDetailsPageState extends State<ItemDetailsPage> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    WishlistService.instance.addListener(_onWishlistChanged);
  }

  @override
  void dispose() {
    WishlistService.instance.removeListener(_onWishlistChanged);
    super.dispose();
  }

  void _onWishlistChanged() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final product = widget.product;
    final seller = widget.seller;
    final sellerInfo = seller != null && seller is Map
        ? {
            'name': seller['name'] ?? 'Unknown Seller',
            'university': seller['university'] ?? 'Unknown University',
            'image': seller['image'] ?? '',
          }
        : {
            'name': 'Unknown Seller',
            'university': 'Unknown University',
            'image': '',
        };

    // ✅ Ensure product has multiple images
    final List<String> productImages = List<String>.from(
      product['images'] != null && (product['images'] as List).isNotEmpty
          ? product['images']
          : (product['image'] != null && product['image'].toString().isNotEmpty
              ? [product['image']]
              : []),
    );

    return NetworkGuard(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
        title: const Text(
          'Item Details',
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
          // Product photos (swipeable gallery)
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.45,
            child: PageView.builder(
              itemCount: productImages.length,
              onPageChanged: (index) {
                setState(() {
                  _currentIndex = index;
                });
              },
              itemBuilder: (context, index) {
                final imageUrl = productImages[index];
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: imageUrl.startsWith('http')
                      ? Image.network(
                          imageUrl,
                          fit: BoxFit.contain,
                          loadingBuilder: (context, child, loadingProgress) {
                            if (loadingProgress == null) return child;
                            return Center(
                              child: CircularProgressIndicator(
                                value: loadingProgress.expectedTotalBytes != null
                                    ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                                    : null,
                              ),
                            );
                          },
                          errorBuilder: (context, error, stackTrace) {
                            return const Icon(Icons.image_not_supported, size: 50, color: Colors.grey);
                          },
                          cacheWidth: 800, // Optimize memory for detail view
                          cacheHeight: 800,
                        )
                      : Image.asset(imageUrl, fit: BoxFit.contain),
                );
              },
            ),
          ),

          // Indicators
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              productImages.length,
                  (index) => Container(
                margin: const EdgeInsets.all(4),
                width: _currentIndex == index ? 12 : 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color:
                  _currentIndex == index ? Colors.blue : Colors.grey[400],
                ),
              ),
            ),
          ),

          // Item name
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 6),
            child: Text(
              product['name'] ?? product['title'] ?? 'Untitled',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          // Description
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              product['description'] ?? 'No description available.',
              style: const TextStyle(
                fontSize: 14,
                color: Colors.black87,
                height: 1.4,
              ),
            ),
          ),

          // Price
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            child: Row(
              children: [
                Text(
                  product['price']?.toString().startsWith('₹') == true 
                      ? product['price'] 
                      : '₹${product['price'] ?? 0}',
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '(Negotiable)',
                  style: TextStyle(
                    fontSize: 15,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
          // Condition Badge
          if (product['condition'] != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.blue.shade200),
                ),
                child: Text(
                  'Condition: ${product['condition']}',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Colors.blue.shade700,
                  ),
                ),
              ),
            ),

          const SizedBox(height: 10),

          // Seller Info Section
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: const Text(
              'Seller Information',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          ListTile(
            leading: CircleAvatar(
              radius: 24,
              backgroundColor: Colors.grey[300],
              child: sellerInfo['image'] != null && sellerInfo['image'].toString().isNotEmpty
                  ? ClipOval(
                      child: Image.network(
                        sellerInfo['image'],
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return const Icon(Icons.person, color: Colors.grey);
                        },
                      ),
                    )
                  : const Icon(Icons.person, color: Colors.grey),
            ),
            title: Text(
              sellerInfo['name'],
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text(
              sellerInfo['university'],
              style: const TextStyle(color: Colors.black54, fontSize: 13),
            ),
          ),

          const SizedBox(height: 20),

          // Bottom buttons
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
            child: Row(
              children: [
                Expanded(
                  flex: 3,
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      // Show interest dialog
                      final messageController = TextEditingController();
                      final phoneController = TextEditingController();
                      
                      final result = await showDialog<bool>(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: const Text('Show Interest'),
                          content: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              TextField(
                                controller: messageController,
                                decoration: const InputDecoration(
                                  labelText: 'Message',
                                  hintText: 'Tell the seller about your interest...',
                                ),
                                maxLines: 3,
                              ),
                              const SizedBox(height: 16),
                              TextField(
                                controller: phoneController,
                                decoration: const InputDecoration(
                                  labelText: 'Phone (optional)',
                                  hintText: 'Your contact number',
                                ),
                                keyboardType: TextInputType.phone,
                              ),
                            ],
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context, false),
                              child: const Text('Cancel'),
                            ),
                            ElevatedButton(
                              onPressed: () => Navigator.pop(context, true),
                              child: const Text('Send'),
                            ),
                          ],
                        ),
                      );

                      if (result == true) {
                        if (messageController.text.trim().isEmpty) {
                          if (!mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Please enter a message'),
                              backgroundColor: Colors.orange,
                            ),
                          );
                          return;
                        }
                        
                        try {
                          // Show loading
                          if (!mounted) return;
                          showDialog(
                            context: context,
                            barrierDismissible: false,
                            builder: (context) => const Center(
                              child: CircularProgressIndicator(),
                            ),
                          );
                          
                          // Call API - backend now returns immediately after saving to DB
                          // Email is sent in background, so this should be fast
                          await ProductService.showInterest(
                            product['_id'] ?? '',
                            messageController.text.trim(),
                            phone: phoneController.text.trim().isNotEmpty ? phoneController.text.trim() : null,
                          );
                          
                          if (!mounted) return;
                          Navigator.pop(context); // Close loading dialog
                          
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('✅ Interest sent! Seller will contact you soon.'),
                              backgroundColor: Colors.green,
                              duration: Duration(seconds: 3),
                            ),
                          );
                        } catch (e) {
                          if (!mounted) return;
                          
                          // Close loading dialog if open
                          if (Navigator.of(context).canPop()) {
                            Navigator.pop(context);
                          }
                          
                          // Check if it's a timeout but message might have been sent
                          final errorMsg = e.toString();
                          if (errorMsg.contains('processing') || errorMsg.contains('saved')) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('✅ Interest sent! Seller will be notified.'),
                                backgroundColor: Colors.green,
                                duration: Duration(seconds: 3),
                              ),
                            );
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('❌ Error: ${errorMsg.contains("timeout") ? "Connection timeout. Your interest may have been saved. Please check your internet connection." : errorMsg}'),
                                backgroundColor: Colors.red,
                                duration: const Duration(seconds: 4),
                              ),
                            );
                          }
                        }
                      }
                      
                      messageController.dispose();
                      phoneController.dispose();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    icon: const Icon(Icons.chat_bubble_outline),
                    label: const Text(
                      'Contact Seller',
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 1,
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: Colors.grey.shade400),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    onPressed: () {
                      WishlistService.instance.toggle(product);
                    },
                    child: Icon(
                      WishlistService.instance.isWished(product)
                          ? Icons.favorite
                          : Icons.favorite_border,
                      size: 26,
                      color: WishlistService.instance.isWished(product)
                          ? Colors.red
                          : Colors.black87,
                    ),
                  ),
                ),
              ],
            ),
          ),
          ],
        ),
      ),
      ),
    );
  }
}

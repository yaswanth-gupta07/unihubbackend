import 'package:flutter/material.dart';
import 'ItemDetails_page.dart';
import 'CategoryDetails_Page.dart';
import 'wishlist/wishlist_page.dart';
import 'wishlist/wishlist_service.dart';
import '../services/product_service.dart';
import '../services/user_service.dart';
import '../services/wishlist_service.dart' as cloud;
import '../services/cache_service.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String? _userUniversity;
  final List<Map<String, dynamic>> allCategories = const [
    {
      'icon': Icons.menu_book,
      'label': 'Books & Study',
      'description': 'Textbooks, guides, notes, stationery',
    },
    {
      'icon': Icons.headphones,
      'label': 'Electronics',
      'description': 'Phones, laptops, headphones, calculators, chargers',
    },
    {
      'icon': Icons.chair,
      'label': 'Room Essentials',
      'description': 'Furniture, beds, mattresses, buckets, storage, lamps',
    },
    {
      'icon': Icons.checkroom,
      'label': 'Fashion',
      'description': 'T-shirts, jackets, shoes, bags, college merch',
    },
    {
      'icon': Icons.directions_bike,
      'label': 'Transport',
      'description': 'Cycles, scooters, skateboards, helmets',
    },
    {
      'icon': Icons.sports_baseball,
      'label': 'Sports & Fitness',
      'description': 'Bats, balls, rackets, gym equipment, yoga mats',
    },
    {
      'icon': Icons.kitchen,
      'label': 'Kitchen & Cooking',
      'description': 'Mini-fridges, microwaves, utensils, snacks',
    },
    {
      'icon': Icons.local_activity,
      'label': 'Tickets & Events',
      'description': 'Concert tickets, sports passes, event entries',
    },
    {
      'icon': Icons.health_and_safety_outlined,
      'label': 'Health & Care',
      'description': 'First-aid kits, toiletries, supplements',
    },
    {
      'icon': Icons.more_horiz,
      'label': 'Miscellaneous',
      'description': 'Instruments, art supplies, anything else',
    },
  ];

  List<dynamic> products = [];
  bool _isLoading = true;
  String? _error;
  final TextEditingController _searchController = TextEditingController();
  
  // Prevent duplicate API calls by storing Future
  Future<void>? _productsFuture;
  int _currentPage = 1;
  bool _hasMore = true;
  bool _isLoadingMore = false;

  @override
  void initState() {
    super.initState();
    // Load cached data instantly, then refresh in background
    _loadCachedProducts();
    // Load data sequentially to reduce lag
    _loadUserUniversity().then((_) {
      _loadProducts(isRefresh: true);
    });
    // Initialize wishlist sync in background (non-blocking)
    _initializeWishlist();
  }

  Future<void> _initializeWishlist() async {
    // Delay wishlist sync to avoid blocking initial load
    await Future.delayed(const Duration(milliseconds: 500));
    try {
      // Sync wishlist from server in background (use cloud service directly)
      await cloud.WishlistService.instance.syncFromServer();
    } catch (e) {
      // Silently fail - wishlist will work offline
      print('Wishlist sync error: $e');
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadUserUniversity() async {
    try {
      // Use cache for faster initial load
      final userData = await UserService.getProfile(useCache: true);
      if (mounted) {
        setState(() {
          _userUniversity = userData['university'];
        });
      }
    } catch (e) {
      // Ignore error, university will be null
    }
  }

  Future<void> _loadCachedProducts() async {
    try {
      final cached = await CacheService.getCachedProductsFeed(
        search: _searchController.text.isEmpty ? null : _searchController.text,
      );
      if (cached != null && mounted) {
        setState(() {
          products = cached;
          _isLoading = false;
        });
        // Refresh in background
        _loadProducts(isRefresh: true);
      }
    } catch (e) {
      // Ignore cache errors
    }
  }

  Future<void> _loadProducts({String? search, bool isRefresh = false}) async {
    // Prevent duplicate calls - reuse existing future if still loading
    if (_productsFuture != null && !isRefresh) {
      return;
    }

    if (isRefresh) {
      _currentPage = 1;
      _hasMore = true;
      setState(() {
        _isLoading = true;
        _error = null;
      });
    } else {
      if (!_hasMore || _isLoadingMore) return;
      setState(() {
        _isLoadingMore = true;
      });
    }

    _productsFuture = _fetchProducts(search: search, isRefresh: isRefresh);
    await _productsFuture;
    _productsFuture = null;
  }

  Future<void> _fetchProducts({String? search, bool isRefresh = false}) async {
    try {
      final searchQuery = search ?? (_searchController.text.isEmpty ? null : _searchController.text);
      
      final result = await ProductService.getProducts(
        search: searchQuery,
        page: _currentPage,
        limit: 20,
      );
      
      final fetchedProducts = result['products'] as List<dynamic>;
      final totalPages = result['totalPages'] as int;
      
      // Cache first page for instant load next time
      if (isRefresh || _currentPage == 1) {
        await CacheService.cacheProductsFeed(
          fetchedProducts,
          search: searchQuery,
        );
      }
      
      if (mounted) {
        setState(() {
          if (isRefresh || _currentPage == 1) {
            products = fetchedProducts;
          } else {
            products.addAll(fetchedProducts);
          }
          _currentPage++;
          _hasMore = _currentPage <= totalPages;
          _isLoading = false;
          _isLoadingMore = false;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          // Provide user-friendly error message
          final errorMsg = e.toString();
          if (errorMsg.contains('timeout') || errorMsg.contains('Connection')) {
            _error = 'Connection timeout. Please check your internet connection.';
          } else if (errorMsg.contains('SocketException')) {
            _error = 'No internet connection. Please check your network.';
          } else {
            _error = 'Failed to load products. Please try again.';
          }
          _isLoading = false;
          _isLoadingMore = false;
        });
      }
    }
  }

  void _loadMoreProducts() {
    if (!_isLoadingMore && _hasMore) {
      _loadProducts();
    }
  }

  void _onSearchChanged(String value) {
    // Debounce search - reload after user stops typing
    Future.delayed(const Duration(milliseconds: 500), () {
      if (_searchController.text == value && mounted) {
        _loadProducts(search: value.isEmpty ? null : value, isRefresh: true);
      }
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () => _loadProducts(search: _searchController.text.isEmpty ? null : _searchController.text, isRefresh: true),
          child: ListView(
            children: [
            // TopBar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  const Icon(Icons.storefront, size: 32, color: Colors.indigo),
                  const SizedBox(width: 8),
                  const Text(
                    'UniMarket',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.favorite_border, size: 28, color: Colors.indigo),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const WishlistPage(),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),

            // University filter indicator
            if (_userUniversity != null) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.indigo.shade50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.indigo.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.school, size: 18, color: Colors.indigo.shade700),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          "Showing products from $_userUniversity",
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.indigo.shade700,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
            // Search Bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Search items...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _searchController.text.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.clear),
                          onPressed: () {
                            _searchController.clear();
                            _loadProducts();
                          },
                        )
                      : null,
                  filled: true,
                  fillColor: Colors.grey[200],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: EdgeInsets.zero,
                ),
                onChanged: _onSearchChanged,
              ),
            ),
            const SizedBox(height: 16),

            // Categories Title
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Categories',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 10),

            // Categories Section
            SizedBox(
              height: 210,
              child: GridView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: allCategories.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 18,
                  crossAxisSpacing: 10,
                  childAspectRatio: 1.15,
                ),
                itemBuilder: (context, index) {
                  final cat = allCategories[index];
                  return GestureDetector(
                    onTap: () {
                      // Navigate to category details page
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => CategoryDetailsPage(
                            category: cat,
                          ),
                        ),
                      );
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          radius: 30,
                          backgroundColor: Colors.indigo.withOpacity(0.1),
                          child: Icon(
                            cat['icon'] as IconData,
                            color: Colors.indigo,
                            size: 28,
                          ),
                        ),
                        const SizedBox(height: 8),
                        SizedBox(
                          width: 85,
                          child: Text(
                            cat['label'] as String,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 10),

            // Products Title
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Recent Listings',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  if (_isLoading)
                    const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                ],
              ),
            ),

            // Product Grid with heart icon beside price
            _isLoading
                ? const Padding(
                    padding: EdgeInsets.all(32.0),
                    child: Center(child: CircularProgressIndicator()),
                  )
                : _error != null
                    ? Padding(
                        padding: const EdgeInsets.all(32.0),
                        child: Column(
                          children: [
                            Text('Error: $_error', style: const TextStyle(color: Colors.red)),
                            const SizedBox(height: 16),
                            ElevatedButton(
                              onPressed: () => _loadProducts(search: _searchController.text.isEmpty ? null : _searchController.text, isRefresh: true),
                              child: const Text('Retry'),
                            ),
                          ],
                        ),
                      )
                    : products.isEmpty
                        ? const Padding(
                            padding: EdgeInsets.all(32.0),
                            child: Center(child: Text('No products available')),
                          )
                        : Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                GridView.builder(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemCount: products.length,
                                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 2,
                                    mainAxisSpacing: 16,
                                    crossAxisSpacing: 16,
                                    childAspectRatio: 0.82,
                                  ),
                                  itemBuilder: (context, idx) {
                                final prod = products[idx];
                                final productMap = {
                                  '_id': prod['_id'],
                                  'name': prod['title'] ?? '',
                                  'price': '₹${prod['price']?.toString() ?? '0'}',
                                  'description': prod['description'] ?? '',
                                  'image': (prod['images'] != null && (prod['images'] as List).isNotEmpty)
                                      ? prod['images'][0]
                                      : '',
                                  'images': prod['images'] ?? [],
                                  'category': prod['category'] ?? '',
                                  'condition': prod['condition'] ?? '',
                                  'status': prod['status'] ?? 'AVAILABLE',
                                  'sellerId': prod['sellerId'],
                                };
                                final isWished = WishlistService.instance.isWished(productMap);
                                final isSold = productMap['status'] == 'SOLD';
                                
                                return GestureDetector(
                                  behavior: HitTestBehavior.opaque,
                                  onTap: isSold ? null : () {
                                    final productId = productMap['_id'];
                                    print('Product tapped: $productId'); // Debug
                                    
                                    if (productId == null || productId.toString().isEmpty) {
                                      if (mounted) {
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          const SnackBar(
                                            content: Text('Invalid product data'),
                                            backgroundColor: Colors.red,
                                          ),
                                        );
                                      }
                                      return;
                                    }
                                    
                                    try {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => ItemDetailsPage(
                                            product: productMap,
                                            seller: prod['sellerId'],
                                          ),
                                        ),
                                      ).then((_) {
                                        // Refresh wishlist state when returning
                                        if (mounted) setState(() {});
                                      });
                                    } catch (e, stackTrace) {
                                      print('Navigation error: $e'); // Debug
                                      print('Stack trace: $stackTrace'); // Debug
                                      if (mounted) {
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          SnackBar(
                                            content: Text('Error opening product: $e'),
                                            backgroundColor: Colors.red,
                                            duration: const Duration(seconds: 3),
                                          ),
                                        );
                                      }
                                    }
                                  },
                                  child: Card(
                                    elevation: 2,
                                    clipBehavior: Clip.antiAlias,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Stack(
                                            children: [
                                              Container(
                                                width: double.infinity,
                                                color: Colors.grey[200],
                                                child: productMap['image'] != null && productMap['image'].toString().isNotEmpty
                                                    ? (productMap['image'].toString().startsWith('http')
                                                        ? Image.network(
                                                            productMap['image'],
                                                            fit: BoxFit.cover,
                                                            loadingBuilder: (context, child, loadingProgress) {
                                                              if (loadingProgress == null) return child;
                                                              return Center(
                                                                child: CircularProgressIndicator(
                                                                  value: loadingProgress.expectedTotalBytes != null
                                                                      ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                                                                      : null,
                                                                ),
                                                              );
                                                            },
                                                            errorBuilder: (context, error, stackTrace) {
                                                              return const Icon(Icons.image_not_supported, size: 50, color: Colors.grey);
                                                            },
                                                            cacheWidth: 300, // Optimize memory usage
                                                            cacheHeight: 300,
                                                          )
                                                        : Image.asset(
                                                            productMap['image'],
                                                            fit: BoxFit.cover,
                                                            errorBuilder: (context, error, stackTrace) {
                                                              return const Icon(Icons.image_not_supported, size: 50, color: Colors.grey);
                                                            },
                                                          ))
                                                    : const Icon(Icons.image_not_supported, size: 50, color: Colors.grey),
                                              ),
                                              // Sold overlay
                                              if (productMap['status'] == 'SOLD')
                                                Container(
                                                  width: double.infinity,
                                                  color: Colors.black.withOpacity(0.6),
                                                  child: Center(
                                                    child: Container(
                                                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                                      decoration: BoxDecoration(
                                                        color: Colors.red,
                                                        borderRadius: BorderRadius.circular(20),
                                                      ),
                                                      child: const Text(
                                                        'SOLD OUT',
                                                        style: TextStyle(
                                                          color: Colors.white,
                                                          fontWeight: FontWeight.bold,
                                                          fontSize: 16,
                                                          letterSpacing: 1.2,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                child: Text(
                                                  productMap['name'],
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 16,
                                                    color: productMap['status'] == 'SOLD' ? Colors.grey[600] : Colors.black,
                                                    decoration: productMap['status'] == 'SOLD' ? TextDecoration.lineThrough : null,
                                                  ),
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                ),
                                              ),
                                              if (productMap['status'] == 'SOLD')
                                                Container(
                                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                  decoration: BoxDecoration(
                                                    color: Colors.red.shade100,
                                                    borderRadius: BorderRadius.circular(8),
                                                    border: Border.all(color: Colors.red.shade300),
                                                  ),
                                                  child: Text(
                                                    'SOLD',
                                                    style: TextStyle(
                                                      color: Colors.red.shade700,
                                                      fontSize: 10,
                                                      fontWeight: FontWeight.bold,
                                                    ),
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
                                          child: Row(
                                            children: [
                                              Text(
                                                productMap['price'],
                                                style: TextStyle(
                                                  color: isSold ? Colors.grey[600] : Colors.indigo,
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 14,
                                                  decoration: isSold ? TextDecoration.lineThrough : null,
                                                ),
                                              ),
                                              const Spacer(),
                                              GestureDetector(
                                                onTap: () {
                                                  // Optimistic UI update - update immediately, sync in background
                                                  final wasWished = WishlistService.instance.isWished(productMap);
                                                  if (mounted) {
                                                    setState(() {}); // Trigger rebuild for icon change
                                                  }
                                                  WishlistService.instance.toggle(productMap).then((_) {
                                                    // Sync completed, UI already updated optimistically
                                                    if (mounted) setState(() {});
                                                  }).catchError((e) {
                                                    // Revert on error
                                                    if (mounted) setState(() {});
                                                  });
                                                },
                                                child: Padding(
                                                  padding: const EdgeInsets.all(8.0),
                                                  child: Icon(
                                                    isWished
                                                        ? Icons.favorite
                                                        : Icons.favorite_border,
                                                    color: isWished ? Colors.red : Colors.grey,
                                                    size: 20,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                            // Load more indicator
                            if (_isLoadingMore)
                              const Padding(
                                padding: EdgeInsets.all(16.0),
                                child: CircularProgressIndicator(),
                              )
                            else if (_hasMore && products.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: TextButton(
                                  onPressed: _loadMoreProducts,
                                  child: const Text('Load More'),
                                ),
                              ),
                          ],
                        ),
                          ),
            ],
          ),
        ),
      ),
    );
  }
}

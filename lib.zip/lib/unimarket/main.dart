// main.dart

import 'package:flutter/material.dart';
import 'home_page.dart';
import '../MarketSelection.dart'; // Or your correct path

// Import the new pages you just created
import 'postitem/post_page.dart';
// import 'messages/chats_page.dart';
import 'profile/profile_page.dart';
import '../services/wishlist_service.dart' as cloud;
import '../core/widgets/network_guard.dart';

// ... (Your UniMarketApp class remains the same)

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  // ✅ Pages without Wishlist (moved to top icon)
  // Wrapped with NetworkGuard for offline handling
  List<Widget> get _pages => [
    NetworkGuard(child: const HomePage()),
    NetworkGuard(child: const PostPage()),
    NetworkGuard(child: const ProfilePage()),
  ];

  @override
  void initState() {
    super.initState();
    // Initialize wishlist sync in background when app starts (non-blocking)
    _initializeWishlist();
  }

  Future<void> _initializeWishlist() async {
    // Delay wishlist sync to avoid blocking app startup
    await Future.delayed(const Duration(milliseconds: 1000));
    try {
      // Sync wishlist from server in background
      await cloud.WishlistService.instance.syncFromServer();
    } catch (e) {
      // Silently fail - wishlist will work offline
      print('Wishlist sync error: $e');
    }
  }

  void _onNavBarTap(int index) {
    // Map navigation bar indices to page indices
    // Nav bar: 0=Home, 1=UniHub(navigates away), 2=Post, 3=Chats, 4=Profile
    // Pages: 0=Home, 1=Post, 2=Chats, 3=Profile
    int mappedIndex = index;
    if (index > 1) {
      mappedIndex = index - 1; // Shift indices after UniHub (2->1, 3->2, 4->3)
    }
    setState(() {
      _selectedIndex = mappedIndex;
    });
  }

  // Map page index to navigation bar index for highlighting
  int _getNavBarIndex(int pageIndex) {
    // Pages: 0=Home, 1=Post, 2=Chats, 3=Profile
    // Nav bar: 0=Home, 1=UniHub, 2=Post, 3=Chats, 4=Profile
    if (pageIndex >= 1) {
      return pageIndex + 1; // Post(1)->2, Chats(2)->3, Profile(3)->4
    }
    return pageIndex; // Home(0)->0
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _getNavBarIndex(_selectedIndex),
        onTap: (index) {
          // If UniHub icon (index 1) is tapped, navigate to MarketSelectionPage
          if (index == 1) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => const MarketSelectionPage(),
              ),
            );
          } else {
            // Otherwise, call the normal onTap handler
            _onNavBarTap(index);
          }
        },
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.indigo,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(Icons.apps_rounded), label: 'UniHub'),
          BottomNavigationBarItem(icon: Icon(Icons.add_box), label: 'Post'),
          BottomNavigationBarItem(
              icon: Icon(Icons.person_outline), label: 'Profile'),

        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:unihub/MarketSelection.dart';

// import 'package:home/client/client_dashboard.dart';
// import 'package:home/freelancer/freelancer_dashboard.dart';
// import 'package:home/client/managejobs.dart';
// import 'package:home/freelancer/FindJobs.dart';
// import 'package:home/notification/notifications_page.dart';

// Colors
const kPrimaryGradient = [Color(0xFF8A47FF), Color(0xFFC587FF)];
const kPrimaryColor = Color(0xFF8A47FF);
const kBackgroundOuterColor = Color(0xFF392C4E);
const kBackgroundInnerColor = Color(0xFFF8F6FF);

// Toggle Bar
Widget buildToggleBar({
  required bool isClient,
  required VoidCallback onClient,
  required VoidCallback onFreelancer,
}) {
  return Container(
    decoration: BoxDecoration(
      color: const Color(0xFFF5EFFD),
      borderRadius: BorderRadius.circular(50),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: onClient,
          child: _buildToggleItem(
            icon: Icons.badge,
            label: "Client",
            isActive: isClient,
          ),
        ),
        GestureDetector(
          onTap: onFreelancer,
          child: _buildToggleItem(
            icon: Icons.groups,
            label: "Freelancer",
            isActive: !isClient,
          ),
        ),
      ],
    ),
  );
}

Widget _buildToggleItem({
  required IconData icon,
  required String label,
  required bool isActive,
}) {
  return Container(
    decoration: BoxDecoration(
      color: isActive ? kPrimaryColor : Colors.transparent,
      borderRadius: BorderRadius.circular(50),
    ),
    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
    child: Row(
      children: [
        Icon(icon, color: isActive ? Colors.white : Colors.black, size: 20),
        const SizedBox(width: 7),
        Text(
          label,
          style: TextStyle(
            color: isActive ? Colors.white : Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 15,
          ),
        ),
      ],
    ),
  );
}

// Stat Card
Widget buildStatCard(
    String title,
    String value,
    IconData icon, {
      String? currency,
      double fontSize = 26,
    }) {
  return Container(
    padding: const EdgeInsets.symmetric(vertical: 20),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.012),
          blurRadius: 5,
          offset: const Offset(0, 2),
        ),
      ],
      border: Border.all(color: const Color(0xFFE0E0E0)),
    ),
    child: Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: kPrimaryColor, size: 22),
            const SizedBox(width: 9),
            if (currency != null)
              Flexible(
                child: Text(
                  currency,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: fontSize - 3,
                    color: kPrimaryColor,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            Flexible(
              child: Text(
                value,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: fontSize,
                  color: Colors.black,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Text(title, style: const TextStyle(fontSize: 15, color: Colors.black54)),
      ],
    ),
  );
}

// Gradient Button
Widget buildGradientButton({
  required String label,
  required IconData icon,
  required VoidCallback onPressed,
}) {
  return SizedBox(
    width: double.infinity,
    height: 44,
    child: DecoratedBox(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: kPrimaryGradient,
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: ElevatedButton.icon(
        icon: Icon(icon, color: Colors.white, size: 21),
        label: Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          elevation: 0,
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          padding: EdgeInsets.zero,
        ),
      ),
    ),
  );
}

// Outlined Button
Widget buildOutlinedButton({
  required String label,
  required VoidCallback onPressed,
}) {
  return SizedBox(
    width: double.infinity,
    height: 44,
    child: OutlinedButton(
      child: Text(
        label,
        style: const TextStyle(
          color: kPrimaryColor,
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        side: const BorderSide(color: kPrimaryColor, width: 1.2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    ),
  );
}

// Project Card
Widget buildProjectCard({
  required String title,
  required String author,
  required String price,
  required String status,
  required List<String> tags,
  required String days,
}) {
  Color statusColor;
  switch (status) {
    case "Completed":
      statusColor = Colors.green;
      break;
    case "In Progress":
    case "Applied":
      statusColor = kPrimaryColor;
      break;
    case "Review":
      statusColor = Colors.orange;
      break;
    case "Shortlisted":
      statusColor = Colors.blue;
      break;
    case "Available":
      statusColor = Colors.green;
      break;
    default:
      statusColor = Colors.grey;
      break;
  }

  return Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(13),
      border: Border.all(color: const Color(0xFFE0E0E0)),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.014),
          blurRadius: 4,
          offset: const Offset(0, 2),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.14),
                borderRadius: BorderRadius.circular(13),
              ),
              child: Text(
                status,
                style: TextStyle(
                  color: statusColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 5),
        Text(author, style: const TextStyle(color: Colors.black45, fontSize: 13)),
        const SizedBox(height: 7),
        Row(
          children: [
            Text(
              price,
              style: const TextStyle(
                color: Colors.grey,
                fontWeight: FontWeight.bold,
                fontSize: 13,
              ),
            ),
            const Spacer(),
            const Icon(Icons.access_time, size: 13, color: Colors.grey),
            const SizedBox(width: 3),
            Text(
              days,
              style: const TextStyle(color: Colors.black54, fontSize: 12),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Wrap(
          spacing: 5,
          runSpacing: 3,
          children: tags
              .map(
                (tag) => Chip(
              label: Text(
                tag,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              backgroundColor: kPrimaryColor.withOpacity(0.079),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(7),
              ),
              visualDensity: VisualDensity.compact,
            ),
          )
              .toList(),
        ),
      ],
    ),
  );
}

// Bottom Navigation Bar
Widget buildBottomNav({
  required bool isClient,
  required int currentIndex,
  required Function(int) onTap,
  required BuildContext context,
}) {
  return BottomNavigationBar(
    type: BottomNavigationBarType.fixed,
    currentIndex: currentIndex,
    onTap: (index) {
      // If UniHub icon (index 2) is tapped, navigate to MarketSelectionPage
      if (index == 2) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const MarketSelectionPage(),
          ),
        );
      } else {
        // Otherwise, call the normal onTap handler
        onTap(index);
      }
    },
    selectedItemColor: kPrimaryColor,
    unselectedItemColor: Colors.grey,
    backgroundColor: kBackgroundInnerColor,
    showUnselectedLabels: true,
    items: [
      const BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
      BottomNavigationBarItem(
        icon: const Icon(Icons.work),
        label: isClient ? "My Jobs" : "Find Jobs",
      ),
      const BottomNavigationBarItem(
        icon: Icon(Icons.apps),
        label: "UniHub",
      ),
      const BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
    ],
  );
}
import 'package:flutter/material.dart';
import '../auth/signin_screen.dart';

class OnboardingScreen extends StatefulWidget {
  static const route = '/onboarding';
  const OnboardingScreen({super.key, this.onFinishedRoute});
  final String? onFinishedRoute;

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _controller = PageController();
  int _index = 0;

  final _pages = const [
    _ObPage(
      title: 'Dual Role System',
      subtitle:
      'Be both a client and freelancer. Switch between hiring others and offering your own services seamlessly.',
      icon: Icons.groups_rounded,
      gradA: Color(0xFF8A47FF),
      gradB: Color(0xFF6B3BFF),
    ),
    _ObPage(
      title: 'Smart Job Matching',
      subtitle:
      'Post projects or browse opportunities tailored to your skills. Find the perfect match for your academic projects.',
      icon: Icons.work_rounded,
      gradA: Color(0xFF8A47FF),
      gradB: Color(0xFF6B3BFF),
    ),
    _ObPage(
      title: 'Real-time Communication',
      subtitle:
      'Chat instantly with clients and freelancers. Negotiate terms, share updates, and build lasting professional relationships.',
      icon: Icons.chat_bubble_rounded,
      gradA: Color(0xFF6B3BFF),
      gradB: Color(0xFF6B3BFF),
    ),
  ];

  void _next() {
    if (_index < _pages.length - 1) {
      _controller.nextPage(
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOutCubic,
      );
    } else {
      _finish();
    }
  }

  void _prev() {
    if (_index > 0) {
      _controller.previousPage(
        duration: const Duration(milliseconds: 240),
        curve: Curves.easeOutCubic,
      );
    }
  }

  void _skip() => _finish();

  void _finish() {
    final route = widget.onFinishedRoute;
    if (route != null && mounted) {
      Navigator.of(context).pushReplacementNamed(route);
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const SigninPage()),
      );


    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dots = List.generate(
      _pages.length,
          (i) => _Dot(active: i == _index, big: i == _index),
    );

    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFFF8F6FF),
        body: Column(
          children: [
            const SizedBox(height: 8),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: dots),
            const SizedBox(height: 8),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: _pages.length,
                onPageChanged: (i) => setState(() => _index = i),
                itemBuilder: (_, i) => _pages[i],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12),
              child: Row(
                children: [
                  // Always show "Skip"
                  TextButton(
                    onPressed: _skip,
                    child: const Text(
                      'Skip',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  const Spacer(),
                  // Show back arrow starting from second page
                  // Show back arrow only on middle screens (not first or last)
                  if (_index > 0 && _index < _pages.length - 1) ...[
                    _ArrowButton(
                      icon: Icons.arrow_back_rounded,
                      onTap: _prev,
                    ),
                    const SizedBox(width: 12),
                  ],

                  // Forward arrow or Get Started
                  if (_index < _pages.length - 1) ...[
                    _ArrowButton(
                      icon: Icons.arrow_forward_rounded,
                      onTap: _next,
                    ),
                  ] else ...[
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                        backgroundColor: const Color(0xFF8A47FF),
                      ),
                      onPressed: _finish,
                      child: const Text(
                        'Get Started',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }
}

/// Single onboarding page with vertical centering and smaller icon
class _ObPage extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color gradA;
  final Color gradB;

  const _ObPage({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.gradA,
    required this.gradB,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return LayoutBuilder(
      builder: (_, c) => SingleChildScrollView(
        physics: const NeverScrollableScrollPhysics(),
        child: ConstrainedBox(
          constraints: BoxConstraints(minHeight: c.maxHeight),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [gradA, gradB],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      blurRadius: 40,
                      spreadRadius: 2,
                      offset: const Offset(0, 16),
                      color: gradA.withOpacity(0.30),
                    ),
                  ],
                ),
                child: Icon(icon, color: Colors.white, size: 72),
              ),
              const SizedBox(height: 36),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFF191A21),
                    letterSpacing: 0.2,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28.0),
                child: Text(
                  subtitle,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.titleMedium?.copyWith(
                    height: 1.45,
                    color: const Color(0xFF6A6C76),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ArrowButton extends StatelessWidget {
  final IconData icon;
  final bool enabled;
  final VoidCallback? onTap;

  const _ArrowButton({
    required this.icon,
    this.enabled = true,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final base = AnimatedOpacity(
      duration: const Duration(milliseconds: 120),
      opacity: enabled ? 1 : 0.5,
      child: Container(
        width: 58,
        height: 48,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: enabled
              ? const LinearGradient(
            colors: [Color(0xFF8A47FF), Color(0xFF6B3BFF)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          )
              : null,
          color: enabled ? null : Colors.transparent,
          border: enabled
              ? null
              : Border.all(color: const Color(0xFFBEBED6), width: 1.2),
          boxShadow: enabled
              ? [
            BoxShadow(
              color: const Color(0xFF8A47FF).withOpacity(0.35),
              blurRadius: 18,
              offset: const Offset(0, 8),
            )
          ]
              : null,
        ),
        child: Icon(
          icon,
          color: enabled ? Colors.white : const Color(0xFF8A47FF),
          size: 24,
        ),
      ),
    );

    return GestureDetector(
      onTap: enabled
          ? () {
        Feedback.forTap(context);
        onTap?.call();
      }
          : null,
      child: base,
    );
  }
}

class _Dot extends StatelessWidget {
  final bool active;
  final bool big;
  const _Dot({required this.active, required this.big});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 8),
      width: big ? 36 : 8,
      height: 8,
      decoration: BoxDecoration(
        color: active ? const Color(0xFF8A47FF) : const Color(0xFFE8E3FF),
        borderRadius: BorderRadius.circular(8),
      ),
    );
  }
}


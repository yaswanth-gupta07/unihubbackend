import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/network/network_monitor.dart';

/// Premium "No Internet" screen that blocks all interaction
/// 
/// Features:
/// - Clean, modern UI design
/// - Auto-retry when connection returns
/// - Manual retry button
/// - Blocks all page interaction
class NoInternetScreen extends StatefulWidget {
  final VoidCallback? onRetry;
  final Widget? child; // Original screen to show when online

  const NoInternetScreen({
    super.key,
    this.onRetry,
    this.child,
  });

  @override
  State<NoInternetScreen> createState() => _NoInternetScreenState();
}

class _NoInternetScreenState extends State<NoInternetScreen> {
  final NetworkMonitor _networkMonitor = NetworkMonitor();
  StreamSubscription<bool>? _connectivitySubscription;
  bool _isRetrying = false;

  @override
  void initState() {
    super.initState();
    // Listen for connectivity changes
    _connectivitySubscription = _networkMonitor.connectivityStream.listen(
      (isConnected) {
        if (isConnected && widget.onRetry != null) {
          // Auto-retry when connection returns
          widget.onRetry!();
        }
      },
    );
  }

  @override
  void dispose() {
    _connectivitySubscription?.cancel();
    super.dispose();
  }

  Future<void> _handleRetry() async {
    setState(() => _isRetrying = true);
    
    // Wait a bit for UI feedback
    await Future.delayed(const Duration(milliseconds: 300));
    
    // Check connectivity
    final isConnected = await _networkMonitor.checkNow();
    
    if (isConnected && widget.onRetry != null) {
      widget.onRetry!();
    }
    
    if (mounted) {
      setState(() => _isRetrying = false);
      
      if (!isConnected) {
        // Show feedback that still offline
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Still offline. Please check your connection.'),
            duration: Duration(seconds: 2),
            backgroundColor: Colors.orange,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // Block back button when offline
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: const Color(0xFFF8F6FF),
        body: SafeArea(
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // WiFi Off Icon
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.wifi_off,
                    size: 80,
                    color: Colors.grey.shade600,
                  ),
                ),
                
                const SizedBox(height: 32),
                
                // Title
                const Text(
                  'Oops — No Internet',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                  textAlign: TextAlign.center,
                ),
                
                const SizedBox(height: 16),
                
                // Subtitle
                Text(
                  'Please check your internet connection',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey.shade600,
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),
                
                const SizedBox(height: 48),
                
                // Retry Button
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton.icon(
                    onPressed: _isRetrying ? null : _handleRetry,
                    icon: _isRetrying
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                            ),
                          )
                        : const Icon(Icons.refresh, color: Colors.white),
                    label: Text(
                      _isRetrying ? 'Checking...' : 'Retry',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF8A47FF),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 2,
                    ),
                  ),
                ),
                
                const SizedBox(height: 24),
                
                // Helpful tip
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.blue.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.info_outline,
                        color: Colors.blue.shade700,
                        size: 20,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'We\'ll automatically restore your screen when connection returns',
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.blue.shade700,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'MarketSelection.dart';
import 'services/user_service.dart';

class ProfileSetupPage extends StatefulWidget {
  const ProfileSetupPage({super.key});

  @override
  State<ProfileSetupPage> createState() => _ProfileSetupPageState();
}

class _ProfileSetupPageState extends State<ProfileSetupPage> {
  final _formKey = GlobalKey<FormState>();

  final _name = TextEditingController();
  final _about = TextEditingController();
  final _skillField = TextEditingController();

  List<String> skills = [];
  File? _profileImage;
  String? _selectedUniversity;
  String? _selectedYearOfStudy;
  String? _selectedProfession;

  final List<String> universities = [
    'SRM AP',
    'VIT AP',
    'Amrita AP',
    'KLU',
  ];

  final List<String> yearOfStudyOptions = [
    '1st Year',
    '2nd Year',
    '3rd Year',
    '4th Year',
    'Graduate',
    'Post Graduate',
  ];

  final List<String> professionOptions = [
    'Student',
    'Professional',
    'Graduate',
    'Other',
  ];

  bool _loading = false;
  bool _submitted = false;

  @override
  void initState() {
    super.initState();
    _checkExistingProfile();
  }

  // Check if user already has a university set (profile already completed)
  Future<void> _checkExistingProfile() async {
    try {
      final userData = await UserService.getProfile();
      if (userData['university'] != null && userData['university'].toString().isNotEmpty) {
        // User already has university set - redirect to market selection
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const MarketSelectionPage()),
        );
      }
    } catch (e) {
      // If error, allow user to continue with profile setup
      // This handles cases where profile doesn't exist yet
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _about.dispose();
    _skillField.dispose();
    super.dispose();
  }


  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) setState(() => _profileImage = File(picked.path));
  }

  String? _validateName(String? v) {
    final value = v?.trim() ?? '';
    if (value.isEmpty) return 'Name is required';
    if (value.length < 3) return 'Too short';
    return null;
  }

  String? _validateUniversity(String? v) {
    if (v == null || v.isEmpty) return 'University is required';
    return null;
  }

  void _addSkill() {
    final text = _skillField.text.trim();
    if (text.isNotEmpty && !skills.contains(text)) {
      setState(() {
        skills.add(text);
        _skillField.clear();
      });
    }
  }

  void _removeSkill(String skill) {
    setState(() => skills.remove(skill));
  }

  // Save profile to backend
  Future<void> _saveProfile() async {
    setState(() => _submitted = true);
    if (!_formKey.currentState!.validate() || _selectedUniversity == null || _selectedUniversity!.isEmpty) return;
    
    setState(() => _loading = true);

    try {
      // Save to backend
      await UserService.updateProfile(
        name: _name.text.trim(),
        university: _selectedUniversity!,
        skills: skills,
        about: _about.text.trim(),
        yearOfStudy: _selectedYearOfStudy,
        profession: _selectedProfession,
      );

      if (!mounted) return;
      setState(() => _loading = false);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Profile completed successfully!"),
          backgroundColor: Colors.green,
        ),
      );
      
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const MarketSelectionPage()),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error saving profile: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLarge = MediaQuery.sizeOf(context).width > 750;
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF8A47FF), Color(0xFFAE72F4)],
            begin: Alignment.topCenter,
            end: Alignment.bottomRight,
          ),
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            vertical: isLarge ? 50 : 22,
            horizontal: 0,
          ),
          child: Center(
            child: Column(
              children: [
                const SizedBox(height: 16),
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.09),
                    shape: BoxShape.circle,
                  ),
                  child: const Center(
                    child: Icon(Icons.school_rounded,
                        color: Colors.white, size: 40),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  "Complete Your Profile",
                  style: TextStyle(
                    color: Color(0xFFF6F1FF),
                    fontWeight: FontWeight.bold,
                    fontSize: 30,
                  ),
                ),
                const SizedBox(height: 5),
                const Text(
                  "Tell us about yourself and set up your account",
                  style: TextStyle(color: Colors.white70, fontSize: 16),
                ),
                const SizedBox(height: 24),

                // White card
                Container(
                  width: isLarge ? 600 : double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  padding: EdgeInsets.symmetric(
                      horizontal: isLarge ? 40 : 10, vertical: 26),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 25,
                        offset: const Offset(0, 14),
                      ),
                    ],
                  ),
                  child: Form(
                    key: _formKey,
                    autovalidateMode: _submitted
                        ? AutovalidateMode.onUserInteraction
                        : AutovalidateMode.disabled,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 19),

                        // Center the avatar upload widget
                        Center(
                          child: GestureDetector(
                            onTap: _pickImage,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                (_profileImage != null)
                                    ? CircleAvatar(
                                  radius: 44,
                                  backgroundImage: FileImage(_profileImage!),
                                )
                                    : CircleAvatar(
                                  radius: 44,
                                  backgroundColor: const Color(0xFFB488F5),
                                  child: Text(
                                    (_name.text.isNotEmpty ? _name.text[0] : "U").toUpperCase(),
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 39,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                Positioned(
                                  bottom: 3,
                                  right: 3,
                                  child: Container(
                                    width: 27,
                                    height: 27,
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF8A47FF),
                                      shape: BoxShape.circle,
                                      border: Border.all(color: Colors.white, width: 2),
                                    ),
                                    child: const Icon(Icons.add_a_photo, color: Colors.white, size: 16),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),

                        const SizedBox(height: 8),
                        const Center(
                          child: Text(
                            "Click to upload profile picture (optional)",
                            style: TextStyle(color: Colors.black45, fontSize: 13),
                            textAlign: TextAlign.center,
                          ),
                        ),

                        const SizedBox(height: 22),

                        // Sections
                        _sectionLabel("Basic Information"),
                        const SizedBox(height: 9),
                        TextFormField(
                          controller: _name,
                          decoration: const InputDecoration(
                            labelText: 'Full Name *',
                            border: OutlineInputBorder(),
                          ),
                          validator: _validateName,
                        ),

                        const SizedBox(height: 22),
                        _sectionLabel("University *"),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.blue.shade50,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.blue.shade200),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.info_outline, size: 16, color: Colors.blue.shade700),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  "Jobs and products will be filtered by your university",
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.blue.shade700,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 9),
                        DropdownButtonFormField<String>(
                          value: _selectedUniversity,
                          decoration: const InputDecoration(
                            labelText: 'Select University',
                            border: OutlineInputBorder(),
                          ),
                          validator: _validateUniversity,
                          items: universities.map((String university) {
                            return DropdownMenuItem<String>(
                              value: university,
                              child: Text(university),
                            );
                          }).toList(),
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedUniversity = newValue;
                            });
                          },
                        ),

                        const SizedBox(height: 18),
                        _sectionLabel("Year of Study"),
                        const SizedBox(height: 4),
                        DropdownButtonFormField<String>(
                          value: _selectedYearOfStudy,
                          decoration: const InputDecoration(
                            labelText: 'Select Year of Study',
                            border: OutlineInputBorder(),
                          ),
                          items: yearOfStudyOptions.map((String year) {
                            return DropdownMenuItem<String>(
                              value: year,
                              child: Text(year),
                            );
                          }).toList(),
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedYearOfStudy = newValue;
                            });
                          },
                        ),

                        const SizedBox(height: 18),
                        _sectionLabel("Profession"),
                        const SizedBox(height: 4),
                        DropdownButtonFormField<String>(
                          value: _selectedProfession,
                          decoration: const InputDecoration(
                            labelText: 'Select Profession',
                            border: OutlineInputBorder(),
                          ),
                          items: professionOptions.map((String profession) {
                            return DropdownMenuItem<String>(
                              value: profession,
                              child: Text(profession),
                            );
                          }).toList(),
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedProfession = newValue;
                            });
                          },
                        ),

                        const SizedBox(height: 18),
                        _sectionLabel("About You"),
                        const SizedBox(height: 3),
                        TextFormField(
                          controller: _about,
                          maxLines: 3,
                          decoration: const InputDecoration(
                            hintText: "Tell us about yourself, your interests, goals, and what makes you unique…",
                            border: OutlineInputBorder(),
                          ),
                        ),

                        const SizedBox(height: 17),
                        _sectionLabel("Your Skills"),
                        const SizedBox(height: 3),

                        // Input row before skill chips
                        Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: _skillField,
                                decoration: const InputDecoration(
                                  hintText: "Add a skill (e.g. Web Design, Programming)",
                                  border: OutlineInputBorder(),
                                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                                ),
                                onSubmitted: (_) => _addSkill(),
                              ),
                            ),
                            const SizedBox(width: 8),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                shape: const CircleBorder(),
                                backgroundColor: const Color(0xFF8A47FF),
                                minimumSize: const Size(42, 42),
                                padding: EdgeInsets.zero,
                                elevation: 0,
                              ),
                              onPressed: _addSkill,
                              child: const Icon(Icons.add, color: Colors.white, size: 22),
                            )
                          ],
                        ),
                        const SizedBox(height: 8),

                        // Skills chips wrap left-aligned
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: skills
                              .map((skill) => Chip(
                            label: Text(skill),
                            backgroundColor: const Color(0xFFEDE9FB),
                            onDeleted: () => _removeSkill(skill),
                          ))
                              .toList(),
                        ),

                        const SizedBox(height: 23),
                        SizedBox(
                          width: double.infinity,
                          height: 46,
                          child: ElevatedButton.icon(
                            icon: _loading
                                ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                            )
                                : const Icon(Icons.check_circle_outline_outlined, color: Colors.white),
                            label: const Text(
                              "Save & Continue to UniHub",
                              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                            ),
                            onPressed: _loading ? null : _saveProfile,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF8A47FF),
                              disabledBackgroundColor: Colors.purple.withOpacity(0.34),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(13),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 5),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sectionLabel(String label) => Align(
    alignment: Alignment.centerLeft,
    child: Text(
      label,
      style: const TextStyle(
        fontWeight: FontWeight.bold,
        color: Color(0xFF8A47FF),
        fontSize: 15,
      ),
    ),
  );
}

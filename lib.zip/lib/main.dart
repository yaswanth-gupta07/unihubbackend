import 'package:flutter/material.dart';
import 'splash/splash_screen.dart';
import 'onboarding/onboarding_screen.dart';
import 'auth/signin_screen.dart';
import 'unilancer/client/client_dashboard.dart';
import 'unilancer/client/managejobs.dart';
import 'unilancer/freelancer/freelancer_dashboard.dart';
import 'unilancer/freelancer/FindJobs.dart';
import 'unilancer/profile/profile_page.dart';
import 'shared/shared_widgets.dart';
import 'MarketSelection.dart';
import 'unimarket/main.dart' as unimarket;
import 'core/network/network_monitor.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize network monitor
  await NetworkMonitor().initialize();
  
  runApp(UniLancerApp());
}

class UniLancerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'UniLancer',
      // Start at splash screen
      initialRoute: SplashScreen.route,
      routes: {
        SplashScreen.route: (context) => const SplashScreen(),
        OnboardingScreen.route: (context) => const OnboardingScreen(),
        '/signin': (context) => const SigninPage(),
        '/home': (context) => const MyApp(), // Dashboard
        '/unilancer': (context) => const MyApp(),
        '/unimarket': (context) => const unimarket.MainScreen(), // FIXED: Typo corrected from .M() to .MainScreen()

      },
    );
  }
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool isClient = true;
  int currentIndex = 0;

  // Global key for freelancer dashboard to allow refreshing from outside
  final GlobalKey freelancerDashboardKey = GlobalKey();
  
  // Cache pages to avoid recreating them, but initialize lazily
  List<Widget>? _clientPages;
  List<Widget>? _freelancerPages;

  @override
  void initState() {
    super.initState();
    // Don't create pages in initState - they'll be created on first access
  }

  // Lazy getter for client pages (cached after first creation)
  List<Widget> get clientPages {
    _clientPages ??= [
      ClientDashboardPage(onToggle: toggleView, onTabChange: onTabTapped),
      ManageJobDetailsPage(onBack: () => setState(() => currentIndex = 0)),
      ProfilePage(),
    ];
    return _clientPages!;
  }

  // Lazy getter for freelancer pages (cached after first creation)
  List<Widget> get freelancerPages {
    _freelancerPages ??= [
      FreelancerDashboardPage(key: freelancerDashboardKey, onToggle: toggleView, onTabChange: onTabTapped),
      FindJobsPage(onBack: () {
        setState(() => currentIndex = 0);
        // Refresh dashboard when returning from FindJobs
        final dashboardState = freelancerDashboardKey.currentState;
        if (dashboardState != null) {
          // Call refreshStats using dynamic invocation
          try {
            (dashboardState as dynamic).refreshStats();
          } catch (e) {
            // Ignore if method doesn't exist
          }
        }
      }),
      ProfilePage(),
    ];
    return _freelancerPages!;
  }

  void toggleView() {
    setState(() {
      isClient = !isClient;
      currentIndex = 0;
    });
  }
  void onTabTapped(int index) {
    // Map navigation bar indices to page indices
    // Nav bar: 0=Home, 1=Jobs, 2=UniHub(navigates away), 3=Messages, 4=Profile
    // Pages: 0=Home, 1=Jobs, 2=Messages, 3=Profile
    int mappedIndex = index;
    if (index > 2) {
      mappedIndex = index - 1; // Shift indices after UniHub (3->2, 4->3)
    }
    setState(() {
      currentIndex = mappedIndex;
    });
  }

  // Map page index to navigation bar index for highlighting
  int _getNavBarIndex(int pageIndex) {
    // Pages: 0=Home, 1=Jobs, 2=Messages, 3=Profile
    // Nav bar: 0=Home, 1=Jobs, 2=UniHub, 3=Messages, 4=Profile
    if (pageIndex >= 2) {
      return pageIndex + 1; // Messages(2)->3, Profile(3)->4
    }
    return pageIndex; // Home(0)->0, Jobs(1)->1
  }
  Future<bool> _onWillPop() async {
    if (currentIndex != 0) {
      setState(() {
        currentIndex = 0;
      });
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final pages = isClient ? clientPages : freelancerPages;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kBackgroundInnerColor,
        elevation: 0,
        titleSpacing: 16,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                'UniLancer',
                style: TextStyle(
                  color: kPrimaryColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 22,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            buildToggleBar(
              isClient: isClient,
              onClient: () { if (!isClient) toggleView(); },
              onFreelancer: () { if (isClient) toggleView(); },
            ),
          ],
        ),
        automaticallyImplyLeading: false,
      ),
      body: WillPopScope(
        onWillPop: _onWillPop,
        child: IndexedStack(index: currentIndex, children: pages),
      ),
      bottomNavigationBar: buildBottomNav(
        isClient: isClient,
        currentIndex: _getNavBarIndex(currentIndex),
        onTap: onTabTapped,
        context: context,
      ),
    );
  }
}

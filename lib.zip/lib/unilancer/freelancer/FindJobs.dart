import 'dart:async';
import 'package:flutter/material.dart';
import 'package:unihub/shared/shared_widgets.dart';
import 'JobDetails.dart';
import '../../services/job_service.dart';
import '../../services/user_service.dart';
import '../../services/cache_service.dart';
import '../../../core/widgets/network_guard.dart';

class FindJobsPage extends StatefulWidget {
  final VoidCallback? onBack;
  const FindJobsPage({super.key, this.onBack});

  @override
  State<FindJobsPage> createState() => _FindJobsPageState();
}

class _FindJobsPageState extends State<FindJobsPage> {
  List<dynamic> jobs = [];
  List<dynamic> allJobs = []; // Store all jobs for filter reference
  bool _isLoading = true;
  String? _error;
  String? _userUniversity;
  
  // Search and filter controllers
  final TextEditingController _searchController = TextEditingController();
  Timer? _searchDebounce;
  
  // Pagination
  Future<void>? _jobsFuture;
  int _currentPage = 1;
  bool _hasMore = true;
  bool _isLoadingMore = false;
  
  // Real-time update timer
  Timer? _refreshTimer;
  
  // Filter states
  String? _selectedCategory;
  String? _selectedExperience;
  double? _minBudget;
  double? _maxBudget;
  final TextEditingController _minBudgetController = TextEditingController();
  final TextEditingController _maxBudgetController = TextEditingController();
  
  // Predefined categories from PostNewJob
  static const List<String> _predefinedCategories = [
    'Web Development',
    'Mobile App Development',
    'UI/UX Design',
    'Graphic Design',
    'Content Writing',
    'Data Science',
    'Machine Learning',
    'Digital Marketing',
    'Video Editing',
    'Photography',
    'Translation',
    'Tutoring',
    'Research',
    'Business Consulting',
    'Accounting',
    'Legal Services',
  ];
  
  // Get unique categories from all jobs + predefined categories
  List<String> get _availableCategories {
    final Set<String> categories = Set<String>.from(_predefinedCategories);
    
    // Add categories from existing jobs (including custom "Others" categories)
    for (var job in allJobs) {
      final category = job['category'] as String?;
      if (category != null && category.isNotEmpty) {
        categories.add(category);
      }
    }
    
    final sortedCategories = categories.toList()..sort();
    return sortedCategories;
  }

  @override
  void initState() {
    super.initState();
    // Load cached jobs instantly
    _loadCachedJobs();
    // Load jobs immediately, university can load in background
    _loadJobs(isInitialLoad: true);
    _loadUserUniversity(); // Non-blocking
    
    // Setup real-time search with debouncing
    _searchController.addListener(_onSearchChanged);
    
    // Setup periodic refresh for real-time updates (every 30 seconds)
    _refreshTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      if (mounted && !_isLoading && !_isLoadingMore) {
        _refreshProposalsAndTime();
      }
    });
  }
  
  // Refresh only proposal counts and time without full reload
  Future<void> _refreshProposalsAndTime() async {
    if (jobs.isEmpty) return;
    
    try {
      final result = await JobService.getJobs(
        search: _searchController.text.trim().isEmpty ? null : _searchController.text.trim(),
        category: _selectedCategory,
        experienceLevel: _selectedExperience,
        minBudget: _minBudget,
        maxBudget: _maxBudget,
        page: 1,
        limit: jobs.length > 20 ? jobs.length : 20,
      );
      
      final fetchedJobs = result['jobs'] as List<dynamic>;
      
      // Create a map of job IDs to new data for quick lookup
      final Map<String, dynamic> jobMap = {};
      for (var job in fetchedJobs) {
        jobMap[job['_id'].toString()] = job;
      }
      
      // Update existing jobs with new proposal counts and timestamps
      if (mounted) {
        setState(() {
          jobs = jobs.map((job) {
            final jobId = job['_id'].toString();
            if (jobMap.containsKey(jobId)) {
              final updatedJob = jobMap[jobId];
              return {
                ...job,
                'proposalCount': updatedJob['proposalCount'] ?? job['proposalCount'] ?? 0,
                'createdAt': updatedJob['createdAt'] ?? job['createdAt'],
              };
            }
            return job;
          }).toList();
        });
      }
    } catch (e) {
      // Silently fail - don't disrupt user experience
      print('Error refreshing proposals: $e');
    }
  }
  
  void _onSearchChanged() {
    if (_searchDebounce?.isActive ?? false) _searchDebounce!.cancel();
    _searchDebounce = Timer(const Duration(milliseconds: 500), () {
      _loadJobs(isRefresh: true);
    });
  }
  
  // Helper function to format time ago
  String _formatTimeAgo(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    
    if (difference.inSeconds < 60) {
      return "Just now";
    } else if (difference.inMinutes < 60) {
      return "${difference.inMinutes} min${difference.inMinutes == 1 ? '' : 's'} ago";
    } else if (difference.inHours < 24) {
      return "${difference.inHours} hour${difference.inHours == 1 ? '' : 's'} ago";
    } else if (difference.inDays < 7) {
      return "${difference.inDays} day${difference.inDays == 1 ? '' : 's'} ago";
    } else if (difference.inDays < 30) {
      final weeks = (difference.inDays / 7).floor();
      return "$weeks week${weeks == 1 ? '' : 's'} ago";
    } else if (difference.inDays < 365) {
      final months = (difference.inDays / 30).floor();
      return "$months month${months == 1 ? '' : 's'} ago";
    } else {
      final years = (difference.inDays / 365).floor();
      return "$years year${years == 1 ? '' : 's'} ago";
    }
  }

  Future<void> _loadUserUniversity() async {
    try {
      final userData = await UserService.getProfile();
      if (mounted) {
        setState(() {
          _userUniversity = userData['university'];
        });
      }
    } catch (e) {
      // Ignore error, university will be null
    }
  }

  Future<void> _loadCachedJobs() async {
    try {
      final cached = await CacheService.getCachedJobsFeed();
      if (cached != null && mounted) {
        setState(() {
          jobs = cached;
          allJobs = cached;
          _isLoading = false;
        });
        // Refresh in background
        _loadJobs(isInitialLoad: true);
      }
    } catch (e) {
      // Ignore cache errors
    }
  }

  Future<void> _loadJobs({bool isInitialLoad = false, bool isRefresh = false}) async {
    // Prevent duplicate calls
    if (_jobsFuture != null && !isRefresh) {
      return;
    }

    if (isRefresh || isInitialLoad) {
      _currentPage = 1;
      _hasMore = true;
      setState(() {
        _isLoading = true;
        _error = null;
      });
    } else {
      if (!_hasMore || _isLoadingMore) return;
      setState(() {
        _isLoadingMore = true;
      });
    }

    _jobsFuture = _fetchJobs(isInitialLoad: isInitialLoad, isRefresh: isRefresh);
    await _jobsFuture;
    _jobsFuture = null;
  }

  Future<void> _fetchJobs({bool isInitialLoad = false, bool isRefresh = false}) async {
    try {
      final result = await JobService.getJobs(
        search: _searchController.text.trim().isEmpty ? null : _searchController.text.trim(),
        category: _selectedCategory,
        experienceLevel: _selectedExperience,
        minBudget: _minBudget,
        maxBudget: _maxBudget,
        page: _currentPage,
        limit: 20,
      );
      
      final fetchedJobs = result['jobs'] as List<dynamic>;
      final totalPages = result['totalPages'] as int;
      
      // Cache first page for instant load next time
      if ((isRefresh || isInitialLoad || _currentPage == 1) && 
          _searchController.text.trim().isEmpty && 
          _selectedCategory == null && 
          _selectedExperience == null && 
          _minBudget == null && 
          _maxBudget == null) {
        await CacheService.cacheJobsFeed(fetchedJobs);
      }
      
      if (mounted) {
        setState(() {
          if (isRefresh || isInitialLoad || _currentPage == 1) {
            jobs = fetchedJobs;
            // Update allJobs on initial load or when all filters are cleared
            if (isInitialLoad || 
                (_searchController.text.trim().isEmpty && 
                _selectedCategory == null && 
                _selectedExperience == null && 
                _minBudget == null && 
                _maxBudget == null)) {
              allJobs = fetchedJobs;
            }
          } else {
            jobs.addAll(fetchedJobs);
          }
          _currentPage++;
          _hasMore = _currentPage <= totalPages;
          _isLoading = false;
          _isLoadingMore = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isLoading = false;
          _isLoadingMore = false;
        });
      }
    }
  }

  void _loadMoreJobs() {
    if (!_isLoadingMore && _hasMore) {
      _loadJobs();
    }
  }
  
  void _showFilterDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _FilterBottomSheet(
        selectedCategory: _selectedCategory,
        selectedExperience: _selectedExperience,
        minBudget: _minBudget,
        maxBudget: _maxBudget,
        availableCategories: _availableCategories,
        onApply: (category, experience, minBudget, maxBudget) {
          setState(() {
            _selectedCategory = category;
            _selectedExperience = experience;
            _minBudget = minBudget;
            _maxBudget = maxBudget;
          });
          _loadJobs(isRefresh: true);
          Navigator.pop(context);
        },
        onClear: () {
          setState(() {
            _selectedCategory = null;
            _selectedExperience = null;
            _minBudget = null;
            _maxBudget = null;
            _minBudgetController.clear();
            _maxBudgetController.clear();
          });
          _loadJobs(isRefresh: true);
          Navigator.pop(context);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return NetworkGuard(
      child: WillPopScope(
        onWillPop: () async {
          if (widget.onBack != null) widget.onBack!();
          return false;
        },
        child: Scaffold(
        backgroundColor: kBackgroundInnerColor,
        appBar: AppBar(
          backgroundColor: kBackgroundInnerColor,
          elevation: 0,
          automaticallyImplyLeading: false,
          toolbarHeight: 0,
        ),
        body: RefreshIndicator(
          onRefresh: () => _loadJobs(isRefresh: true),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16.0, 8.0, 16.0, 16.0),
            children: [
              const Text(
                "Find Jobs",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 28),
              ),
              if (_userUniversity != null) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.blue.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.school, size: 18, color: Colors.blue.shade700),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          "Showing jobs from $_userUniversity",
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.blue.shade700,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 16),
            ValueListenableBuilder<TextEditingValue>(
              valueListenable: _searchController,
              builder: (context, value, child) {
                return TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: "Search jobs, skills, or keywords...",
                    prefixIcon: const Icon(Icons.search, color: Colors.grey),
                    suffixIcon: value.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear, color: Colors.grey),
                            onPressed: () {
                              _searchController.clear();
                              _loadJobs(isRefresh: true);
                            },
                          )
                        : null,
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: Colors.grey.shade400, width: 2),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                OutlinedButton.icon(
                  onPressed: _showFilterDialog,
                  icon: Stack(
                    children: [
                      const Icon(Icons.filter_alt_outlined, size: 18),
                      if (_selectedCategory != null || 
                          _selectedExperience != null || 
                          _minBudget != null || 
                          _maxBudget != null)
                        Positioned(
                          right: 0,
                          top: 0,
                          child: Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                              color: Colors.red,
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                    ],
                  ),
                  label: const Text("Filters"),
                  style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.black,
                      side: BorderSide(color: Colors.grey.shade300),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8))),
                ),
                const SizedBox(width: 8),
                Chip(
                  label: Text("${jobs.length} jobs found", style: const TextStyle(color: Colors.grey)),
                  backgroundColor: kBackgroundInnerColor,
                  shape: const StadiumBorder(),
                ),
                if (_selectedCategory != null || 
                    _selectedExperience != null || 
                    _minBudget != null || 
                    _maxBudget != null)
                  const Spacer(),
                if (_selectedCategory != null || 
                    _selectedExperience != null || 
                    _minBudget != null || 
                    _maxBudget != null)
                  TextButton.icon(
                    onPressed: () {
                      setState(() {
                        _selectedCategory = null;
                        _selectedExperience = null;
                        _minBudget = null;
                        _maxBudget = null;
                        _minBudgetController.clear();
                        _maxBudgetController.clear();
                      });
                      _loadJobs();
                    },
                    icon: const Icon(Icons.clear, size: 16),
                    label: const Text("Clear filters"),
                    style: TextButton.styleFrom(foregroundColor: Colors.red),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _error != null
                    ? Column(
                        children: [
                          Text('Error: $_error', style: const TextStyle(color: Colors.red)),
                          ElevatedButton(
                            onPressed: () => _loadJobs(isRefresh: true),
                            child: const Text('Retry'),
                          ),
                        ],
                      )
                    : jobs.isEmpty
                        ? const Center(child: Text('No jobs available'))
                        : Column(
                            children: [
                              ...jobs.map((job) {
                              final postedBy = job['postedBy'] ?? {};
                              final deadline = job['deadline'] != null
                                  ? DateTime.parse(job['deadline'])
                                  : null;
                              final daysDiff = deadline != null
                                  ? deadline.difference(DateTime.now()).inDays
                                  : 0;
                              final createdAt = job['createdAt'] != null 
                                  ? DateTime.parse(job['createdAt'])
                                  : DateTime.now();
                              
                              return _JobCard(
                                jobId: job['_id'],
                                title: job['title'] ?? '',
                                category: job['category'] ?? '',
                                description: job['description'] ?? '',
                                price: "₹${job['budget']?.toString() ?? '0'}",
                                duration: daysDiff > 0 ? "$daysDiff days" : "Expired",
                                skills: List<String>.from(job['skillsRequired'] ?? []),
                                company: postedBy['name'] ?? 'Unknown',
                                companyInitial: postedBy['name'] != null && postedBy['name'].toString().isNotEmpty
                                    ? postedBy['name'][0].toUpperCase()
                                    : 'U',
                                proposals: "${job['proposalCount'] ?? 0} ${(job['proposalCount'] ?? 0) == 1 ? 'proposal' : 'proposals'}",
                                createdAt: createdAt,
                                level: job['experienceLevel'] ?? 'Beginner',
                                onTap: () async {
                                  final result = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => JobDetailsPage(jobId: job['_id'])));
                                  // If application was submitted, refresh jobs and notify parent
                                  if (result == true) {
                                    _loadJobs();
                                    // Return true to parent (dashboard) to trigger refresh
                                    if (mounted && widget.onBack != null) {
                                      // The dashboard will refresh when user navigates back
                                    }
                                  }
                                },
                              );
                            }),
                            // Load more indicator
                            if (_isLoadingMore)
                              const Padding(
                                padding: EdgeInsets.all(16.0),
                                child: CircularProgressIndicator(),
                              )
                            else if (_hasMore && jobs.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: TextButton(
                                  onPressed: _loadMoreJobs,
                                  child: const Text('Load More'),
                                ),
                              ),
                          ],
                        ),
            ],
          ),
        ),
        ),
      ),
    );
  }
  
  @override
  void dispose() {
    _searchController.dispose();
    _minBudgetController.dispose();
    _maxBudgetController.dispose();
    _searchDebounce?.cancel();
    _refreshTimer?.cancel();
    super.dispose();
  }
}

// Filter Bottom Sheet Widget
class _FilterBottomSheet extends StatefulWidget {
  final String? selectedCategory;
  final String? selectedExperience;
  final double? minBudget;
  final double? maxBudget;
  final List<String> availableCategories;
  final Function(String?, String?, double?, double?) onApply;
  final VoidCallback onClear;

  const _FilterBottomSheet({
    required this.selectedCategory,
    required this.selectedExperience,
    required this.minBudget,
    required this.maxBudget,
    required this.availableCategories,
    required this.onApply,
    required this.onClear,
  });

  @override
  State<_FilterBottomSheet> createState() => _FilterBottomSheetState();
}

class _FilterBottomSheetState extends State<_FilterBottomSheet> {
  late String? _tempCategory;
  late String? _tempExperience;
  late double? _tempMinBudget;
  late double? _tempMaxBudget;
  final TextEditingController _minBudgetController = TextEditingController();
  final TextEditingController _maxBudgetController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tempCategory = widget.selectedCategory;
    _tempExperience = widget.selectedExperience;
    _tempMinBudget = widget.minBudget;
    _tempMaxBudget = widget.maxBudget;
    if (_tempMinBudget != null) {
      _minBudgetController.text = _tempMinBudget!.toStringAsFixed(0);
    }
    if (_tempMaxBudget != null) {
      _maxBudgetController.text = _tempMaxBudget!.toStringAsFixed(0);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 16,
        right: 16,
        top: 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "Filter Jobs",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
          const SizedBox(height: 20),
          
          // Category Filter
          const Text("Category", style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _tempCategory,
            decoration: InputDecoration(
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            items: [
              const DropdownMenuItem<String>(value: null, child: Text("All Categories")),
              ...widget.availableCategories.map((cat) => DropdownMenuItem(
                value: cat,
                child: Text(cat),
              )),
            ],
            onChanged: (val) => setState(() => _tempCategory = val),
          ),
          const SizedBox(height: 20),
          
          // Experience Level Filter
          const Text("Experience Level", style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _tempExperience,
            decoration: InputDecoration(
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            items: const [
              DropdownMenuItem<String>(value: null, child: Text("All Levels")),
              DropdownMenuItem<String>(value: "Beginner", child: Text("Beginner")),
              DropdownMenuItem<String>(value: "Intermediate", child: Text("Intermediate")),
              DropdownMenuItem<String>(value: "Expert", child: Text("Expert")),
            ],
            onChanged: (val) => setState(() => _tempExperience = val),
          ),
          const SizedBox(height: 20),
          
          // Budget Range Filter
          const Text("Budget Range (₹)", style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _minBudgetController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: "Min",
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  onChanged: (val) {
                    _tempMinBudget = val.isEmpty ? null : double.tryParse(val);
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _maxBudgetController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: "Max",
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  onChanged: (val) {
                    _tempMaxBudget = val.isEmpty ? null : double.tryParse(val);
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          
          // Action Buttons
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: widget.onClear,
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    side: BorderSide(color: Colors.grey.shade300),
                  ),
                  child: const Text("Clear All"),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: () {
                    widget.onApply(_tempCategory, _tempExperience, _tempMinBudget, _tempMaxBudget);
                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    backgroundColor: const Color(0xFF8A47FF),
                  ),
                  child: const Text("Apply Filters", style: TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
  
  @override
  void dispose() {
    _minBudgetController.dispose();
    _maxBudgetController.dispose();
    super.dispose();
  }
}

class _JobCard extends StatefulWidget {
  final String? jobId;
  final String title,
      category,
      description,
      price,
      duration,
      company,
      companyInitial,
      proposals,
      level;
  final DateTime createdAt;
  final List<String> skills;
  final VoidCallback onTap;

  const _JobCard({
    this.jobId,
    required this.title,
    required this.category,
    required this.description,
    required this.price,
    required this.duration,
    required this.skills,
    required this.company,
    required this.companyInitial,
    required this.proposals,
    required this.createdAt,
    required this.level,
    required this.onTap,
  });

  @override
  State<_JobCard> createState() => _JobCardState();
}

class _JobCardState extends State<_JobCard> {
  late String _displayTime;
  Timer? _timeUpdateTimer;

  String _formatTimeAgo(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    
    if (difference.inSeconds < 60) {
      return "Just now";
    } else if (difference.inMinutes < 60) {
      return "${difference.inMinutes} min${difference.inMinutes == 1 ? '' : 's'} ago";
    } else if (difference.inHours < 24) {
      return "${difference.inHours} hour${difference.inHours == 1 ? '' : 's'} ago";
    } else if (difference.inDays < 7) {
      return "${difference.inDays} day${difference.inDays == 1 ? '' : 's'} ago";
    } else if (difference.inDays < 30) {
      final weeks = (difference.inDays / 7).floor();
      return "$weeks week${weeks == 1 ? '' : 's'} ago";
    } else if (difference.inDays < 365) {
      final months = (difference.inDays / 30).floor();
      return "$months month${months == 1 ? '' : 's'} ago";
    } else {
      final years = (difference.inDays / 365).floor();
      return "$years year${years == 1 ? '' : 's'} ago";
    }
  }

  void _updateTime() {
    if (mounted) {
      setState(() {
        _displayTime = _formatTimeAgo(widget.createdAt);
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _displayTime = _formatTimeAgo(widget.createdAt);
    // Update time every 30 seconds for more responsive updates
    _timeUpdateTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      _updateTime();
    });
  }

  @override
  void didUpdateWidget(_JobCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.createdAt != widget.createdAt) {
      _updateTime();
    }
  }

  @override
  void dispose() {
    _timeUpdateTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: Colors.white,
      elevation: 0.5,
      child: InkWell(
        onTap: widget.onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                      child: Text(widget.title,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16))),
                  Chip(
                    label: Text(widget.level, style: const TextStyle(fontSize: 12)),
                    backgroundColor: const Color(0xFFEDE7F6),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 0),
                  ),
                ],
              ),
              Text(widget.category, style: const TextStyle(color: Colors.grey)),
              const SizedBox(height: 8),
              Text(widget.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.black87)),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Icon(Icons.attach_money, color: Colors.black54, size: 18),
                  Text(widget.price, style: const TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(width: 16),
                  const Icon(Icons.schedule, color: Colors.black54, size: 18),
                  Text(widget.duration, style: const TextStyle(fontWeight: FontWeight.w500)),
                ],
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: widget.skills
                    .map((s) => Chip(
                          label: Text(s, style: const TextStyle(color: Colors.black87)),
                          backgroundColor: Colors.grey.shade200,
                        ))
                    .toList(),
              ),
              const Divider(height: 24),
              Row(
                children: [
                  CircleAvatar(
                      backgroundColor: Colors.red.shade100,
                      radius: 16,
                      child: Text(widget.companyInitial,
                          style: const TextStyle(
                              color: Colors.red, fontWeight: FontWeight.bold))),
                  const SizedBox(width: 8),
                  Expanded(
                      child: Text(
                    widget.company,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  )),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(widget.proposals, style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text(_displayTime, style: const TextStyle(color: Colors.grey)),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
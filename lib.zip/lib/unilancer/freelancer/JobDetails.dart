// lib/freelancer/JobDetails.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:unihub/shared/shared_widgets.dart';
import '../../services/job_service.dart';
import '../../services/user_service.dart';
import '../../services/application_service.dart';
import '../../services/review_service.dart';
import '../../services/share_service.dart';
import 'SubmitProposal.dart';
import '../profile/profile_page.dart';
import '../../../core/widgets/network_guard.dart';

class JobDetailsPage extends StatefulWidget {
  final String jobId;
  final bool showShareButton; // Show share button only when browsing jobs, not from MyWork/bids
  
  const JobDetailsPage({
    super.key, 
    required this.jobId,
    this.showShareButton = true, // Default to true for backward compatibility
  });

  @override
  State<JobDetailsPage> createState() => _JobDetailsPageState();
}

class _JobDetailsPageState extends State<JobDetailsPage> {
  int _currentIndex = 1;
  Map<String, dynamic>? jobData;
  bool _isLoading = true;
  String? _error;
  String? _currentUserId;
  bool _isAssignedToMe = false;
  bool _hasApplied = false;
  String? _applicationStatus;
  Map<String, dynamic>? _jobReview;
  Timer? _refreshTimer;
  Timer? _timeUpdateTimer;
  String _timeAgoText = "Just now";

  @override
  void initState() {
    super.initState();
    // Load current user first, then load job details to ensure userId is available
    _loadCurrentUser().then((_) => _loadJobDetails());
    
    // Setup periodic refresh for real-time updates (every 30 seconds)
    _refreshTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      if (mounted && !_isLoading) {
        _refreshJobDetails();
      }
    });
    
    // Setup timer to update time display every 30 seconds
    _timeUpdateTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      if (mounted && jobData != null) {
        _updateTimeDisplay();
      }
    });
  }
  
  void _updateTimeDisplay() {
    if (jobData != null && jobData!['createdAt'] != null) {
      final createdAt = DateTime.parse(jobData!['createdAt']);
      setState(() {
        _timeAgoText = _formatTimeAgo(createdAt);
      });
    }
  }
  
  // Refresh only proposal count without full reload
  Future<void> _refreshJobDetails() async {
    if (jobData == null) return;
    
    try {
      final job = await JobService.getJobById(widget.jobId);
      
      if (job != null && job.isNotEmpty && mounted) {
        setState(() {
          jobData = {
            ...jobData!,
            'proposalCount': job['proposalCount'] ?? jobData!['proposalCount'] ?? 0,
            'createdAt': job['createdAt'] ?? jobData!['createdAt'],
          };
        });
      }
    } catch (e) {
      // Silently fail - don't disrupt user experience
      print('Error refreshing job details: $e');
    }
  }

  Future<void> _loadCurrentUser() async {
    try {
      final userData = await UserService.getProfile();
      if (mounted) {
        setState(() {
          _currentUserId = userData['_id'];
        });
      }
    } catch (e) {
      print('Error loading current user: $e');
      // Ignore error but try to continue
    }
  }

  Future<void> _loadJobDetails() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      if (widget.jobId.isEmpty) {
        throw Exception('Invalid job ID');
      }
      
      final job = await JobService.getJobById(widget.jobId);
      
      if (job == null || job.isEmpty) {
        throw Exception('Job not found');
      }
      
      // Ensure we have currentUserId before checking assignment
      if (_currentUserId == null) {
        try {
          final userData = await UserService.getProfile();
          _currentUserId = userData['_id'];
        } catch (e) {
          print('Error loading user ID: $e');
        }
      }
      
      final assignedTo = job['assignedTo'];
      bool isAssigned = false;
      
      // Check assignment status with userId
      if (assignedTo != null && _currentUserId != null) {
        if (assignedTo is Map) {
          isAssigned = assignedTo['_id']?.toString() == _currentUserId;
        } else {
          isAssigned = assignedTo.toString() == _currentUserId;
        }
      }
      
      // Check if user has already applied and get application status
      bool hasApplied = false;
      String? applicationStatus;
      if (_currentUserId != null && job['status'] == 'OPEN') {
        try {
          final applications = await ApplicationService.getFreelancerApplications();
          // Use where().isNotEmpty instead of firstWhere to avoid exceptions
          final matchingApplications = applications.where((app) {
            final appJobId = app['jobId'];
            if (appJobId is Map) {
              return appJobId['_id']?.toString() == widget.jobId;
            }
            return appJobId?.toString() == widget.jobId;
          }).toList();
          
          if (matchingApplications.isNotEmpty) {
            final userApplication = matchingApplications.first;
            hasApplied = true;
            applicationStatus = userApplication['status']?.toString() ?? 'PENDING';
          }
        } catch (e) {
          print('Error checking applications: $e');
          // If there's an error, try to reload applications once more
          try {
            await Future.delayed(const Duration(milliseconds: 500));
            final applications = await ApplicationService.getFreelancerApplications();
            final matchingApplications = applications.where((app) {
              final appJobId = app['jobId'];
              if (appJobId is Map) {
                return appJobId['_id']?.toString() == widget.jobId;
              }
              return appJobId?.toString() == widget.jobId;
            }).toList();
            
            if (matchingApplications.isNotEmpty) {
              final userApplication = matchingApplications.first;
              hasApplied = true;
              applicationStatus = userApplication['status']?.toString() ?? 'PENDING';
            }
          } catch (retryError) {
            print('Retry error checking applications: $retryError');
          }
        }
      }
      
      // Check if review exists (for CLOSED jobs or COMPLETED jobs)
      Map<String, dynamic>? jobReview;
      if (job['status'] == 'CLOSED' || job['status'] == 'COMPLETED') {
        try {
          jobReview = await ReviewService.getJobReview(widget.jobId);
        } catch (e) {
          print('Error fetching review: $e');
        }
      }
      
      setState(() {
        jobData = job;
        _isAssignedToMe = isAssigned;
        _hasApplied = hasApplied;
        _applicationStatus = applicationStatus;
        _jobReview = jobReview;
        _isLoading = false;
      });
      
      // Update time display
      _updateTimeDisplay();
    } catch (e) {
      setState(() {
        _error = 'Failed to load job details. Please try again.';
        _isLoading = false;
      });
      print('Error loading job details: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        backgroundColor: kBackgroundInnerColor,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 1,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (_error != null || jobData == null) {
      return Scaffold(
        backgroundColor: kBackgroundInnerColor,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 1,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Error: $_error'),
              ElevatedButton(
                onPressed: _loadJobDetails,
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    final job = jobData!;
    final postedBy = job['postedBy'] ?? {};
    final deadline = job['deadline'] != null ? DateTime.parse(job['deadline']) : null;
    final daysDiff = deadline != null ? deadline.difference(DateTime.now()).inDays : 0;
    final skills = List<String>.from(job['skillsRequired'] ?? []);
    return Scaffold(
      backgroundColor: kBackgroundInnerColor,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        shadowColor: Colors.black.withOpacity(0.1),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              job['title'] ?? 'Job',
              style: const TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                  fontWeight: FontWeight.bold),
            ),
            Text(
              job['category'] ?? '',
              style: const TextStyle(color: Colors.grey, fontSize: 14),
            ),
          ],
        ),
        actions: widget.showShareButton ? [
          IconButton(
            icon: const Icon(Icons.share_outlined, color: Colors.black87),
            tooltip: 'Share Job',
            onPressed: () {
              ShareService.showShareOptions(
                context: context,
                jobTitle: job['title'] ?? 'Job',
                jobDescription: job['description'] ?? '',
                budget: job['budget']?.toString() ?? '0',
                category: job['category'] ?? '',
                jobId: widget.jobId,
              );
            },
          ),
        ] : null,
      ),

      bottomNavigationBar: buildBottomNav(
        isClient: false,
        currentIndex: _currentIndex,
        onTap: (index) {
          // Handle navigation based on the tapped index
          if (index == 0) {
            // Home - Navigate back to main app (UniLancer home)
            // Pop all routes until we reach the main app or navigate to it
            Navigator.of(context).popUntil((route) {
              // If we can pop, keep popping until we reach first route
              return route.isFirst;
            });
            // If we're not at /unilancer, navigate to it
            if (mounted && ModalRoute.of(context)?.settings.name != '/unilancer') {
              Navigator.of(context).pushNamedAndRemoveUntil(
                '/unilancer',
                (route) => false,
              );
            }
          } else if (index == 3) {
            // Profile - Navigate to Profile page
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => const ProfilePage(),
              ),
            );
          } else {
            // For other indices (Find Jobs, UniHub), just update state
            setState(() => _currentIndex = index);
          }
        },
        context: context,
      ),

      // Show different bottom sheet based on assignment status
      bottomSheet: _isAssignedToMe
          ? Container(
              padding: const EdgeInsets.all(16),
              color: Colors.white,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: job['status'] == 'CLOSED'
                          ? Colors.green.shade50
                          : job['status'] == 'COMPLETED'
                              ? Colors.orange.shade50
                              : Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: job['status'] == 'CLOSED'
                            ? Colors.green.shade200
                            : job['status'] == 'COMPLETED'
                                ? Colors.orange.shade200
                                : Colors.blue.shade200,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          job['status'] == 'CLOSED'
                              ? Icons.check_circle
                              : job['status'] == 'COMPLETED'
                                  ? Icons.hourglass_empty
                                  : Icons.check_circle,
                          color: job['status'] == 'CLOSED'
                              ? Colors.green.shade700
                              : job['status'] == 'COMPLETED'
                                  ? Colors.orange.shade700
                                  : Colors.blue.shade700,
                          size: 20,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            job['status'] == 'CLOSED'
                                ? "Project completed and reviewed"
                                : job['status'] == 'COMPLETED'
                                    ? "Work submitted! Waiting for client approval"
                                    : "You are working on this project",
                            style: TextStyle(
                              color: job['status'] == 'CLOSED'
                                  ? Colors.green.shade700
                                  : job['status'] == 'COMPLETED'
                                      ? Colors.orange.shade700
                                      : Colors.blue.shade700,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (job['status'] == 'IN_PROGRESS' && _isAssignedToMe)
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: Colors.grey.shade300),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                            icon: const Icon(Icons.work_outline),
                            label: const Text("View Project"),
                            onPressed: () {
                              // Can add project workspace here later
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Project workspace coming soon!'),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                            icon: const Icon(Icons.check, color: Colors.white),
                            label: const Text(
                              "Mark Complete",
                              style: TextStyle(color: Colors.white),
                            ),
                            onPressed: () async {
                              try {
                                await JobService.submitWork(widget.jobId);
                                if (!mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Work submitted! Waiting for client approval.'),
                                    backgroundColor: Colors.green,
                                  ),
                                );
                                // Reload job details to update status
                                await _loadJobDetails();
                              } catch (e) {
                                if (!mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Error: ${e.toString()}'),
                                    backgroundColor: Colors.red,
                                  ),
                                );
                              }
                            },
                          ),
                        ),
                      ],
                    )
                  else if (job['status'] == 'COMPLETED')
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(color: Colors.grey.shade300),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        icon: const Icon(Icons.info_outline),
                        label: const Text("Waiting for client to review"),
                        onPressed: null,
                      ),
                    )
                  else if ((job['status'] == 'CLOSED' || job['status'] == 'COMPLETED') && _jobReview != null)
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.green.shade200),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.star, color: Colors.green.shade700, size: 20),
                              const SizedBox(width: 8),
                              Text(
                                "Client Review",
                                style: TextStyle(
                                  color: Colors.green.shade700,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: List.generate(5, (index) {
                              final rating = _jobReview!['rating'] ?? 0;
                              return Icon(
                                index < rating
                                    ? Icons.star
                                    : Icons.star_border,
                                color: Colors.amber,
                                size: 20,
                              );
                            }),
                          ),
                          if (_jobReview!['comment'] != null && _jobReview!['comment'].toString().isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text(
                              _jobReview!['comment'].toString(),
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                ],
              ),
            )
              : job['status'] == 'OPEN'
              ? Container(
                  padding: const EdgeInsets.all(16),
                  color: Colors.white,
                  child: _hasApplied
                      ? Container(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          decoration: BoxDecoration(
                            color: _applicationStatus == 'DECLINED' 
                                ? Colors.red.shade50 
                                : _applicationStatus == 'ACCEPTED'
                                    ? Colors.green.shade50
                                    : Colors.blue.shade50,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: _applicationStatus == 'DECLINED'
                                  ? Colors.red.shade200
                                  : _applicationStatus == 'ACCEPTED'
                                      ? Colors.green.shade200
                                      : Colors.blue.shade200,
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                _applicationStatus == 'DECLINED'
                                    ? Icons.cancel
                                    : _applicationStatus == 'ACCEPTED'
                                        ? Icons.check_circle
                                        : Icons.pending,
                                color: _applicationStatus == 'DECLINED'
                                    ? Colors.red.shade700
                                    : _applicationStatus == 'ACCEPTED'
                                        ? Colors.green.shade700
                                        : Colors.blue.shade700,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                _applicationStatus == 'DECLINED'
                                    ? "Application Declined"
                                    : _applicationStatus == 'ACCEPTED'
                                        ? "Application Accepted"
                                        : "Already Applied",
                                style: TextStyle(
                                  color: _applicationStatus == 'DECLINED'
                                      ? Colors.red.shade700
                                      : _applicationStatus == 'ACCEPTED'
                                          ? Colors.green.shade700
                                          : Colors.blue.shade700,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        )
                      : buildGradientButton(
                          label: "Apply Now",
                          icon: Icons.send,
                          onPressed: () async {
                            final result = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => SubmitProposalPage(jobId: widget.jobId),
                              ),
                            );
                            // Always refresh job details when returning from proposal page
                            // Wait a bit to ensure backend has processed the application
                            if (mounted) {
                              await Future.delayed(const Duration(milliseconds: 300));
                              await _loadJobDetails();
                            }
                          },
                        ),
                )
              : null,

      body: ListView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, _isAssignedToMe ? 200 : 100), // More padding if bottomSheet is shown
        children: [
          _buildInfoCard(
            "₹${job['budget']?.toString() ?? '0'}",
            daysDiff > 0 ? "$daysDiff days" : "Expired",
            job['experienceLevel'] ?? 'Beginner',
            "${job['proposalCount'] ?? 0} ${(job['proposalCount'] ?? 0) == 1 ? 'proposal' : 'proposals'}",
            _timeAgoText,
          ),
          const SizedBox(height: 16),
          _buildSectionCard(
            "Project Description",
            Text(
              job['description'] ?? '',
              style: const TextStyle(fontSize: 15, height: 1.5, color: Colors.black87),
            ),
          ),
          if (skills.isNotEmpty)
            _buildSectionCard(
              "Skills Required",
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: skills
                    .map((skill) => Chip(
                  label: Text(skill),
                  backgroundColor: Colors.grey.shade200,
                  side: BorderSide.none,
                ))
                    .toList(),
              ),
            ),
          _buildSectionCard(
            "About the Client",
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(
                  backgroundColor: Colors.red,
                  child: Text(
                      postedBy['name'] != null && postedBy['name'].toString().isNotEmpty
                          ? postedBy['name'][0].toUpperCase()
                          : 'U',
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold))),
              title: Text(
                  postedBy['name'] ?? 'Unknown',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(postedBy['university'] ?? 'Unknown University'),
            ),
          ),
        ],
      ),
    );
  }

  // --- Helper Widgets ---
  Widget _buildInfoCard(String budget, String duration, String level,
      String proposals, String posted) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade200)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _InfoItem(Icons.attach_money, budget),
              const SizedBox(width: 20),
              _InfoItem(Icons.schedule, duration),
              const Spacer(),
              Chip(
                label: Text(level,
                    style: const TextStyle(fontSize: 12, color: kPrimaryColor)),
                backgroundColor: kPrimaryColor.withOpacity(0.1),
                padding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 0),
                side: BorderSide.none,
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Text(proposals, style: const TextStyle(color: Colors.black87)),
              const Spacer(),
              Text(posted, style: const TextStyle(color: Colors.grey)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSectionCard(String title, Widget content) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade200)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 12),
        content,
      ]),
    );
  }
  
  // Helper function to format time ago
  String _formatTimeAgo(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    
    if (difference.inSeconds < 60) {
      return "Just now";
    } else if (difference.inMinutes < 60) {
      return "${difference.inMinutes} min${difference.inMinutes == 1 ? '' : 's'} ago";
    } else if (difference.inHours < 24) {
      return "${difference.inHours} hour${difference.inHours == 1 ? '' : 's'} ago";
    } else if (difference.inDays < 7) {
      return "${difference.inDays} day${difference.inDays == 1 ? '' : 's'} ago";
    } else if (difference.inDays < 30) {
      final weeks = (difference.inDays / 7).floor();
      return "$weeks week${weeks == 1 ? '' : 's'} ago";
    } else if (difference.inDays < 365) {
      final months = (difference.inDays / 30).floor();
      return "$months month${months == 1 ? '' : 's'} ago";
    } else {
      final years = (difference.inDays / 365).floor();
      return "$years year${years == 1 ? '' : 's'} ago";
    }
  }
  
  @override
  void dispose() {
    _refreshTimer?.cancel();
    _timeUpdateTimer?.cancel();
    super.dispose();
  }
}

class _InfoItem extends StatelessWidget {
  final IconData icon;
  final String text;
  const _InfoItem(this.icon, this.text);

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Icon(icon, color: kPrimaryColor, size: 20),
      const SizedBox(width: 6),
      Text(text, style: const TextStyle(fontWeight: FontWeight.w500)),
    ]);
  }
}

class _ProposalTile extends StatelessWidget {
  final String name, price, snippet, duration, timeAgo, avatarInitial;
  final double rating;

  const _ProposalTile({
    required this.name,
    required this.rating,
    required this.price,
    required this.snippet,
    required this.duration,
    required this.timeAgo,
    required this.avatarInitial,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            CircleAvatar(
                backgroundColor: Colors.red.shade100,
                radius: 18,
                child: Text(avatarInitial,
                    style: const TextStyle(
                        color: Colors.red, fontWeight: FontWeight.bold))),
            const SizedBox(width: 10),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text("⭐ $rating", style: const TextStyle(color: Colors.black54)),
            ]),
            const Spacer(),
            Chip(
              label: Text("₹$price",
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, color: Colors.green)),
              backgroundColor: Colors.green.withOpacity(0.1),
              side: BorderSide.none,
            ),
          ]),
          const SizedBox(height: 8),
          Text(snippet, style: const TextStyle(color: Colors.black87)),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.schedule, size: 14, color: Colors.grey),
              const SizedBox(width: 4),
              Text(duration, style: const TextStyle(color: Colors.grey)),
              const Spacer(),
              Text(timeAgo, style: const TextStyle(color: Colors.grey)),
            ],
          ),
        ],
      ),
    );
  }
}

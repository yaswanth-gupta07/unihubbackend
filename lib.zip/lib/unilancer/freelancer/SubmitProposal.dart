import 'package:flutter/material.dart';
import 'package:unihub/shared/shared_widgets.dart';
import '../../services/application_service.dart';
import '../../services/job_service.dart';

class SubmitProposalPage extends StatefulWidget {
  final String jobId;
  
  const SubmitProposalPage({super.key, required this.jobId});

  @override
  State<SubmitProposalPage> createState() => _SubmitProposalPageState();
}

class _SubmitProposalPageState extends State<SubmitProposalPage> {
  int _currentIndex = 1;
  final _formKey = GlobalKey<FormState>();
  final _coverLetterController = TextEditingController();
  final _phoneController = TextEditingController();
  final _budgetController = TextEditingController();
  final _deliveryDaysController = TextEditingController();
  final _portfolioLinkController = TextEditingController();
  final _skillController = TextEditingController();
  
  String? _selectedPricingType;
  List<String> _selectedSkills = [];
  bool _agreementAccepted = false;
  bool _isSubmitting = false;
  Map<String, dynamic>? _jobData;
  bool _isLoadingJob = true;

  final List<String> _pricingTypes = ['Fixed', 'Hourly', 'Per Task'];

  @override
  void initState() {
    super.initState();
    _loadJobDetails();
  }

  Future<void> _loadJobDetails() async {
    try {
      final job = await JobService.getJobById(widget.jobId);
      setState(() {
        _jobData = job;
        _isLoadingJob = false;
      });
    } catch (e) {
      setState(() {
        _isLoadingJob = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundInnerColor,
      appBar: AppBar(
        title: const Text("Submit Proposal",
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 1,
        shadowColor: Colors.black.withOpacity(0.1),
        leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () => Navigator.of(context).pop()),
      ),
      bottomNavigationBar: buildBottomNav(
        isClient: false,
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() => _currentIndex = index);
        },
        context: context,
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade200)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Submit Proposal",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                  const SizedBox(height: 4),
                  const Text("Write a compelling proposal to win this project",
                      style: TextStyle(color: Colors.grey)),
                  const SizedBox(height: 24),
                  
                  // Client Budget and Deadline Info
                  if (_jobData != null) ...[
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.blue.shade200),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.info_outline, size: 20, color: Colors.blue.shade700),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  "Client Budget: ₹${_jobData!['budget']?.toString() ?? '0'}",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.blue.shade700,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          if (_jobData!['deadline'] != null) ...[
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Icon(Icons.calendar_today, size: 18, color: Colors.blue.shade700),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    _formatDeadline(_jobData!['deadline']),
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: Colors.blue.shade700,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                  
                  // Cover Letter
                  _buildTextField(
                      label: "Cover Letter *",
                      hint: "Explain why you're the perfect fit for this project...",
                      maxLines: 5,
                      controller: _coverLetterController,
                      validator: (value) => value?.isEmpty ?? true ? "Cover letter is required" : null),
                  
                  // Budget & Pricing Type Row
                  Row(
                    children: [
                      Expanded(
                        child: _buildTextField(
                            label: "Budget (₹) *",
                            hint: "e.g., 5000",
                            controller: _budgetController,
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value?.isEmpty ?? true) return "Budget is required";
                              if (double.tryParse(value!) == null) return "Enter valid amount";
                              return null;
                            }),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildDropdown(
                          label: "Pricing Type *",
                          value: _selectedPricingType,
                          items: _pricingTypes,
                          onChanged: (val) => setState(() => _selectedPricingType = val),
                          validator: (value) => value == null ? "Select pricing type" : null,
                        ),
                      ),
                    ],
                  ),
                  
                  // Delivery Days
                  _buildTextField(
                      label: "Delivery Time (Days) *",
                      hint: "e.g., 7",
                      controller: _deliveryDaysController,
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value?.isEmpty ?? true) return "Delivery time is required";
                        if (int.tryParse(value!) == null || int.parse(value) < 1) {
                          return "Enter valid number of days";
                        }
                        return null;
                      }),
                  
                  // Skills
                  _buildSkillsField(),
                  
                  // Portfolio Link
                  _buildTextField(
                      label: "Portfolio Link (Optional)",
                      hint: "https://yourportfolio.com",
                      controller: _portfolioLinkController,
                      keyboardType: TextInputType.url),
                  
                  // Phone
                  _buildTextField(
                      label: "Phone *",
                      hint: "Your contact number",
                      controller: _phoneController,
                      keyboardType: TextInputType.phone,
                      validator: (value) {
                        if (value?.isEmpty ?? true) return "Phone number is required";
                        // Remove any non-digit characters for validation
                        final digitsOnly = value!.replaceAll(RegExp(r'[^0-9]'), '');
                        if (digitsOnly.length != 10) return "Phone number must be exactly 10 digits";
                        return null;
                      }),
                  
                  // Agreement Checkbox
                  Row(
                    children: [
                      Checkbox(
                        value: _agreementAccepted,
                        onChanged: (val) => setState(() => _agreementAccepted = val ?? false),
                        activeColor: kPrimaryColor,
                      ),
                      Expanded(
                        child: GestureDetector(
                          onTap: () => setState(() => _agreementAccepted = !_agreementAccepted),
                          child: const Text(
                            "I confirm this work will be original and not plagiarized. *",
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: kPrimaryGradient,
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: _isSubmitting ? null : _submitProposal,
                        child: _isSubmitting
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                              )
                            : const Text("Submit Proposal",
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSkillsField() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("Skills *", style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: _skillController,
                  decoration: InputDecoration(
                    hintText: "Add a skill",
                    fillColor: kBackgroundInnerColor,
                    filled: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                  ),
                  onFieldSubmitted: (value) {
                    if (value.trim().isNotEmpty && !_selectedSkills.contains(value.trim())) {
                      setState(() {
                        _selectedSkills.add(value.trim());
                        _skillController.clear();
                      });
                    }
                  },
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: kPrimaryColor,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(8)),
                  ),
                  minimumSize: const Size(48, 48),
                ),
                onPressed: () {
                  if (_skillController.text.trim().isNotEmpty && 
                      !_selectedSkills.contains(_skillController.text.trim())) {
                    setState(() {
                      _selectedSkills.add(_skillController.text.trim());
                      _skillController.clear();
                    });
                  }
                },
                child: const Icon(Icons.add, color: Colors.white),
              ),
            ],
          ),
          if (_selectedSkills.isEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4.0),
              child: Text(
                "Please add at least one skill",
                style: TextStyle(color: Colors.red.shade700, fontSize: 12),
              ),
            ),
          if (_selectedSkills.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _selectedSkills.map((skill) => Chip(
                label: Text(skill),
                onDeleted: () => setState(() => _selectedSkills.remove(skill)),
                deleteIcon: const Icon(Icons.close, size: 18),
              )).toList(),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTextField({
    required String label,
    required String hint,
    int maxLines = 1,
    TextEditingController? controller,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextFormField(
            controller: controller,
            maxLines: maxLines,
            keyboardType: keyboardType,
            validator: validator,
            decoration: InputDecoration(
              hintText: hint,
              fillColor: kBackgroundInnerColor,
              filled: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDropdown({
    required String label,
    required String? value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: value,
            items: items.map((item) => DropdownMenuItem(
              value: item,
              child: Text(item),
            )).toList(),
            onChanged: onChanged,
            validator: validator,
            decoration: InputDecoration(
              fillColor: kBackgroundInnerColor,
              filled: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _submitProposal() async {
    if (!_formKey.currentState!.validate()) return;
    
    if (_selectedSkills.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please add at least one skill"),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }
    
    if (!_agreementAccepted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please accept the agreement"),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      await ApplicationService.createApplication(
        jobId: widget.jobId,
        message: _coverLetterController.text.trim(),
        coverLetter: _coverLetterController.text.trim(),
        phone: _phoneController.text.trim(),
        budget: double.tryParse(_budgetController.text.trim()),
        pricingType: _selectedPricingType,
        deliveryDays: int.tryParse(_deliveryDaysController.text.trim()),
        skills: _selectedSkills,
        portfolioLink: _portfolioLinkController.text.trim().isNotEmpty 
            ? _portfolioLinkController.text.trim() 
            : null,
        agreementAccepted: _agreementAccepted,
      );

      if (!mounted) return;
      
      setState(() => _isSubmitting = false);
      
      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Row(
            children: [
              Icon(Icons.check_circle, color: Colors.white),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  "Proposal submitted successfully!",
                  style: TextStyle(fontWeight: FontWeight.w500),
                ),
              ),
            ],
          ),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 3),
        ),
      );
      
      // Wait a bit before navigating to show success message
      await Future.delayed(const Duration(milliseconds: 500));
      
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _isSubmitting = false);
      
      // Extract user-friendly error message
      String errorMessage = e.toString();
      if (errorMessage.startsWith('Exception: ')) {
        errorMessage = errorMessage.substring(11);
      }
      
      // Show error with better formatting
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.error_outline, color: Colors.white),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  errorMessage,
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
              ),
            ],
          ),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 4),
          action: SnackBarAction(
            label: 'Retry',
            textColor: Colors.white,
            onPressed: () => _submitProposal(),
          ),
        ),
      );
    }
  }

  String _formatDeadline(dynamic deadline) {
    if (deadline == null) return 'No deadline';
    try {
      final deadlineStr = deadline.toString();
      final deadlineDate = DateTime.parse(deadlineStr);
      final now = DateTime.now();
      final difference = deadlineDate.difference(now);
      
      if (difference.inDays > 0) {
        return "Deadline: ${difference.inDays} days remaining";
      } else if (difference.inDays == 0) {
        return "Deadline: Due today";
      } else {
        return "Deadline: Expired (${difference.inDays.abs()} days ago)";
      }
    } catch (e) {
      return 'Deadline: ${deadline.toString()}';
    }
  }

  @override
  void dispose() {
    _coverLetterController.dispose();
    _phoneController.dispose();
    _budgetController.dispose();
    _deliveryDaysController.dispose();
    _portfolioLinkController.dispose();
    _skillController.dispose();
    super.dispose();
  }
}

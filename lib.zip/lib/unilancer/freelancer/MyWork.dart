import 'package:flutter/material.dart';
import 'package:unihub/shared/shared_widgets.dart';
import '../../services/job_service.dart';
import '../../services/review_service.dart';
import 'JobDetails.dart';

class MyWorkPage extends StatefulWidget {
  final VoidCallback? onBack;
  const MyWorkPage({super.key, this.onBack});

  @override
  State<MyWorkPage> createState() => _MyWorkPageState();
}

class _MyWorkPageState extends State<MyWorkPage> {
  List<dynamic> assignedJobs = [];
  Map<String, Map<String, dynamic>> _jobReviews = {}; // jobId -> review data
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadAssignedJobs();
  }

  Future<void> _loadAssignedJobs() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final jobs = await JobService.getAssignedJobs();
      // Filter out any jobs with invalid IDs
      final validJobs = jobs.where((job) {
        final jobId = job['_id'];
        return jobId != null && jobId.toString().isNotEmpty;
      }).toList();
      
      // Load reviews for CLOSED and COMPLETED jobs
      final Map<String, Map<String, dynamic>> reviews = {};
      for (var job in validJobs) {
        final jobId = job['_id']?.toString();
        final status = job['status']?.toString() ?? 'OPEN';
        if (jobId != null && (status == 'CLOSED' || status == 'COMPLETED')) {
          try {
            final review = await ReviewService.getJobReview(jobId);
            if (review != null) {
              reviews[jobId] = review;
            }
          } catch (e) {
            // Review doesn't exist yet or error fetching
            print('Error fetching review for job $jobId: $e');
          }
        }
      }
      
      setState(() {
        assignedJobs = validJobs;
        _jobReviews = reviews;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load assigned jobs. Please check your connection and try again.';
        _isLoading = false;
      });
      print('Error loading assigned jobs: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (widget.onBack != null) widget.onBack!();
        return false;
      },
      child: Scaffold(
        backgroundColor: kBackgroundInnerColor,
        appBar: AppBar(
          backgroundColor: kBackgroundInnerColor,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
              if (widget.onBack != null) widget.onBack!();
            },
          ),
          title: const Text(
            "My Work",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: Colors.black,
            ),
          ),
        ),
        body: RefreshIndicator(
          onRefresh: _loadAssignedJobs,
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('Error: $_error', style: const TextStyle(color: Colors.red)),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: _loadAssignedJobs,
                            child: const Text('Retry'),
                          ),
                        ],
                      ),
                    )
                  : assignedJobs.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.work_outline, size: 64, color: Colors.grey.shade400),
                              const SizedBox(height: 16),
                              Text(
                                'No assigned jobs yet',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.grey.shade700,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Apply to jobs and wait for clients to accept your proposals',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey.shade600,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: assignedJobs.length,
                          itemBuilder: (context, index) {
                            final job = assignedJobs[index];
                            final jobId = job['_id']?.toString() ?? '';
                            final postedBy = job['postedBy'] ?? {};
                            final status = job['status'] ?? 'OPEN';
                            
                            String deadlineStr = '';
                            int daysDiff = 0;
                            try {
                              if (job['deadline'] != null) {
                                final deadline = DateTime.parse(job['deadline'].toString());
                                daysDiff = deadline.difference(DateTime.now()).inDays;
                                deadlineStr = daysDiff > 0 ? "$daysDiff days left" : "Expired";
                              }
                            } catch (e) {
                              deadlineStr = "N/A";
                            }

                            return Card(
                              margin: const EdgeInsets.only(bottom: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              color: Colors.white,
                              elevation: 0.5,
                              child: InkWell(
                                onTap: jobId.isNotEmpty ? () async {
                                  await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => JobDetailsPage(
                                        jobId: jobId,
                                        showShareButton: false, // Hide share in details when from MyWork
                                      ),
                                    ),
                                  );
                                  // Reload to get updated job status and reviews
                                  if (mounted) {
                                    await _loadAssignedJobs();
                                  }
                                } : null,
                                borderRadius: BorderRadius.circular(12),
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              job['title'] ?? 'Untitled Job',
                                              style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 16,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 10,
                                              vertical: 4,
                                            ),
                                            decoration: BoxDecoration(
                                              color: status == 'CLOSED'
                                                  ? Colors.green.shade50
                                                  : status == 'IN_PROGRESS'
                                                      ? Colors.blue.shade50
                                                      : status == 'COMPLETED'
                                                          ? Colors.orange.shade50
                                                          : Colors.grey.shade50,
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            child: Text(
                                              status == 'CLOSED'
                                                  ? 'Completed & Reviewed'
                                                  : status == 'IN_PROGRESS'
                                                      ? 'In Progress'
                                                      : status == 'COMPLETED'
                                                          ? 'Waiting for Review'
                                                          : status,
                                              style: TextStyle(
                                                color: status == 'CLOSED'
                                                    ? Colors.green.shade700
                                                    : status == 'IN_PROGRESS'
                                                        ? Colors.blue.shade700
                                                        : status == 'COMPLETED'
                                                            ? Colors.orange.shade700
                                                            : Colors.grey.shade700,
                                                fontSize: 12,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        job['category'] ?? '',
                                        style: const TextStyle(color: Colors.grey),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        job['description'] ?? '',
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(color: Colors.black87),
                                      ),
                                      const SizedBox(height: 12),
                                      Row(
                                        children: [
                                          const Icon(Icons.attach_money,
                                              color: Colors.black54, size: 18),
                                          Text(
                                            "₹${job['budget']?.toString() ?? '0'}",
                                            style: const TextStyle(fontWeight: FontWeight.w500),
                                          ),
                                          const SizedBox(width: 16),
                                          const Icon(Icons.schedule,
                                              color: Colors.black54, size: 18),
                                          Text(
                                            deadlineStr.isNotEmpty ? deadlineStr : "N/A",
                                            style: const TextStyle(fontWeight: FontWeight.w500),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 12),
                                      Wrap(
                                        spacing: 6,
                                        runSpacing: 6,
                                        children: (job['skillsRequired'] as List?)
                                                ?.map((s) => Chip(
                                                      label: Text(s.toString(),
                                                          style: const TextStyle(
                                                              color: Colors.black87)),
                                                      backgroundColor: Colors.grey.shade200,
                                                    ))
                                                .toList() ??
                                            [],
                                      ),
                                      const Divider(height: 24),
                                      // Show review/rating if job is CLOSED or COMPLETED
                                      if ((status == 'CLOSED' || status == 'COMPLETED') && _jobReviews[jobId] != null) ...[
                                        Container(
                                          padding: const EdgeInsets.all(12),
                                          margin: const EdgeInsets.only(bottom: 12),
                                          decoration: BoxDecoration(
                                            color: Colors.amber.shade50,
                                            borderRadius: BorderRadius.circular(10),
                                            border: Border.all(color: Colors.amber.shade200),
                                          ),
                                          child: Row(
                                            children: [
                                              Icon(Icons.star, color: Colors.amber.shade700, size: 20),
                                              const SizedBox(width: 8),
                                              Text(
                                                "Client Rating: ",
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w600,
                                                  color: Colors.amber.shade900,
                                                  fontSize: 13,
                                                ),
                                              ),
                                              ...List.generate(5, (index) {
                                                final rating = _jobReviews[jobId]!['rating'] ?? 0;
                                                return Icon(
                                                  index < rating ? Icons.star : Icons.star_border,
                                                  color: Colors.amber,
                                                  size: 18,
                                                );
                                              }),
                                              if (_jobReviews[jobId]!['comment'] != null && 
                                                  _jobReviews[jobId]!['comment'].toString().isNotEmpty) ...[
                                                const SizedBox(width: 8),
                                                Expanded(
                                                  child: Text(
                                                    _jobReviews[jobId]!['comment'].toString(),
                                                    style: TextStyle(
                                                      color: Colors.grey.shade700,
                                                      fontSize: 12,
                                                    ),
                                                    maxLines: 1,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                ),
                                              ],
                                            ],
                                          ),
                                        ),
                                      ],
                                      Row(
                                        children: [
                                          CircleAvatar(
                                            backgroundColor: Colors.red.shade100,
                                            radius: 16,
                                            child: Text(
                                              postedBy['name'] != null &&
                                                      postedBy['name'].toString().isNotEmpty
                                                  ? postedBy['name'][0].toUpperCase()
                                                  : 'U',
                                              style: const TextStyle(
                                                color: Colors.red,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          Expanded(
                                            child: Text(
                                              postedBy['name'] ?? 'Unknown Client',
                                              style: const TextStyle(fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                          IconButton(
                                            icon: const Icon(Icons.arrow_forward_ios,
                                                size: 16, color: Colors.grey),
                                            onPressed: jobId.isNotEmpty ? () async {
                                              await Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder: (context) =>
                                                      JobDetailsPage(
                                                        jobId: jobId,
                                                        showShareButton: false, // Hide share in details when from MyWork
                                                      ),
                                                ),
                                              );
                                              // Reload to get updated reviews
                                              if (mounted) {
                                                _loadAssignedJobs();
                                              }
                                            } : null,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
        ),
      ),
    );
  }
}


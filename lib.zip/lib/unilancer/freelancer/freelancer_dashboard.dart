import 'package:flutter/material.dart';

import 'package:unihub/shared/shared_widgets.dart';
import 'FindJobs.dart';
import 'MyWork.dart';
import '../../services/job_service.dart';
import '../../services/application_service.dart';
import '../../services/review_service.dart';
import '../../services/user_service.dart';

class FreelancerDashboardPage extends StatefulWidget {
  final VoidCallback onToggle;
  final ValueChanged<int> onTabChange;

  const FreelancerDashboardPage({
    super.key,
    required this.onToggle,
    required this.onTabChange,
  });

  @override
  State<FreelancerDashboardPage> createState() => _FreelancerDashboardPageState();
}

class _FreelancerDashboardPageState extends State<FreelancerDashboardPage> {
  double _totalEarned = 0.0;
  double _avgRating = 0.0;
  bool _isLoading = true;
  List<dynamic> _recentApplications = [];
  int _assignedJobsCount = 0;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  // Public method to refresh stats (can be called from outside)
  Future<void> refreshStats() => _loadStats();

  Future<void> _loadStats() async {
    setState(() => _isLoading = true);
    try {
      // Load all data in parallel for better performance
      final results = await Future.wait([
        JobService.getAssignedJobs(),
        ApplicationService.getFreelancerApplications(),
        UserService.getProfile(),
      ]);

      final assignedJobs = results[0] as List<dynamic>;
      final applications = results[1] as List<dynamic>;
      final userData = results[2] as Map<String, dynamic>;
      
      double totalEarned = 0.0;
      
      // Calculate total earned from completed assigned jobs
      for (var job in assignedJobs) {
        if (job['status'] == 'COMPLETED' || job['status'] == 'CLOSED') {
          totalEarned += (job['budget']?.toDouble() ?? 0.0);
        }
      }
      
      // Get real average rating from reviews (non-blocking, can fail silently)
      double avgRating = 0.0;
      final userId = userData['_id']?.toString();
      if (userId != null) {
        try {
          final reviewData = await ReviewService.getFreelancerReviews(userId);
          avgRating = reviewData['averageRating']?.toDouble() ?? 0.0;
        } catch (e) {
          // If no reviews exist, rating stays 0.0
          print('Error loading reviews: $e');
        }
      }

      // Get recent applications (limit to 3 most recent)
      final recentApplications = applications.take(3).toList();

      setState(() {
        _totalEarned = totalEarned;
        _avgRating = avgRating;
        _recentApplications = recentApplications;
        _assignedJobsCount = assignedJobs.length;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    double h(double ratio) => screenHeight * ratio;
    double w(double ratio) => screenWidth * ratio;
    double sp(double ratio) => screenWidth * ratio;

    return Scaffold(
      backgroundColor: const Color(0xFFF8F6FF),
      body: SafeArea(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 480),
          width: double.infinity,
          color: const Color(0xFFF8F6FF),
          child: RefreshIndicator(
            onRefresh: _loadStats,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(height: h(0.02)),
                  Padding(
                    padding: EdgeInsets.only(
                      top: h(0.02),
                      bottom: h(0.022),
                      left: w(0.05),
                      right: w(0.05),
                    ),
                    child: Column(
                      children: [
                        Text(
                          "Welcome Back, Freelancer!",
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: sp(0.058)),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: h(0.01)),
                        Text(
                          "Discover new opportunities and grow your skills",
                          style:
                          TextStyle(color: Colors.black54, fontSize: sp(0.043)),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: w(0.032), vertical: h(0.014)),
                    child: Row(
                      children: [
                        Expanded(
                          child: buildStatCard(
                            "Total Earned",
                            _isLoading ? "..." : "${_totalEarned.toStringAsFixed(0)}",
                            Icons.currency_rupee,
                            fontSize: sp(0.07),
                          ),
                        ),
                        SizedBox(width: w(0.045)),
                        Expanded(
                          child: buildStatCard(
                            "Avg Rating",
                            _isLoading ? "..." : _avgRating.toStringAsFixed(1),
                            Icons.grade,
                            fontSize: sp(0.07),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: h(0.025)),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: w(0.032)),
                    child: Column(
                      children: [
                        buildGradientButton(
                          label: "Apply to Jobs",
                          icon: Icons.add,
                          onPressed: () {
                            widget.onTabChange(1);
                          },
                        ),
                        SizedBox(height: h(0.015)),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: kPrimaryColor, width: 2),
                              padding: EdgeInsets.symmetric(vertical: h(0.015)),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            icon: Icon(Icons.work_outline, color: kPrimaryColor),
                            label: Text(
                              "My Work",
                              style: TextStyle(
                                color: kPrimaryColor,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => MyWorkPage(
                                    onBack: () => Navigator.pop(context),
                                  ),
                                ),
                              ).then((_) => _loadStats());
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: h(0.013)),

                  SizedBox(height: h(0.022)),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: w(0.047)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Recent Opportunities",
                                  style: TextStyle(
                                      fontSize: sp(0.047), fontWeight: FontWeight.bold),
                                ),
                                SizedBox(height: h(0.003)),
                                Text(
                                  "Stay updated with your latest activity",
                                  style:
                                  TextStyle(color: Colors.black54, fontSize: sp(0.037)),
                                ),
                              ],
                            ),
                            if (_assignedJobsCount > 0)
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: w(0.03), vertical: h(0.005)),
                                decoration: BoxDecoration(
                                  color: kPrimaryColor.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  "$_assignedJobsCount Active",
                                  style: TextStyle(
                                    color: kPrimaryColor,
                                    fontWeight: FontWeight.bold,
                                    fontSize: sp(0.035),
                                  ),
                                ),
                              ),
                          ],
                        ),
                        SizedBox(height: h(0.018)),
                        if (_isLoading)
                          const Center(child: Padding(
                            padding: EdgeInsets.all(20.0),
                            child: CircularProgressIndicator(),
                          ))
                        else if (_recentApplications.isEmpty)
                          Container(
                            padding: EdgeInsets.symmetric(vertical: h(0.04), horizontal: w(0.04)),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  const Color(0xFF8A47FF).withOpacity(0.05),
                                  const Color(0xFFC587FF).withOpacity(0.08),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: const Color(0xFF8A47FF).withOpacity(0.2),
                                width: 1.5,
                              ),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  padding: EdgeInsets.all(w(0.06)),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF8A47FF).withOpacity(0.1),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    Icons.search_outlined,
                                    size: 56,
                                    color: const Color(0xFF8A47FF),
                                  ),
                                ),
                                SizedBox(height: h(0.02)),
                                Text(
                                  "No applications yet",
                                  style: TextStyle(
                                    fontSize: sp(0.045),
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black87,
                                  ),
                                ),
                                SizedBox(height: h(0.008)),
                                Padding(
                                  padding: EdgeInsets.symmetric(horizontal: w(0.05)),
                                  child: Text(
                                    "Browse available jobs from your campus and apply to opportunities that match your skills",
                                    style: TextStyle(
                                      fontSize: sp(0.037),
                                      color: Colors.black54,
                                      height: 1.4,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                SizedBox(height: h(0.025)),
                                Container(
                                  padding: EdgeInsets.symmetric(horizontal: w(0.04), vertical: h(0.01)),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(12),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.05),
                                        blurRadius: 8,
                                        offset: const Offset(0, 2),
                                      ),
                                    ],
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.trending_up,
                                        size: 20,
                                        color: const Color(0xFF8A47FF),
                                      ),
                                      SizedBox(width: w(0.02)),
                                      Text(
                                        "Tip: Customize your proposal",
                                        style: TextStyle(
                                          fontSize: sp(0.033),
                                          color: const Color(0xFF8A47FF),
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: h(0.02)),
                                SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton.icon(
                                    onPressed: () {
                                      widget.onTabChange(1);
                                    },
                                    icon: const Icon(Icons.explore, color: Colors.white),
                                    label: const Text(
                                      "Browse Available Jobs",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF8A47FF),
                                      padding: EdgeInsets.symmetric(vertical: h(0.016)),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      elevation: 2,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        else
                          ..._recentApplications.map((app) {
                            final job = app['jobId'] ?? {};
                            final postedBy = job['postedBy'];
                            String authorName = 'Unknown Client';
                            
                            // Safely extract name from postedBy
                            if (postedBy != null) {
                              if (postedBy is Map) {
                                authorName = postedBy['name']?.toString() ?? 'Unknown Client';
                              } else if (postedBy is String) {
                                authorName = postedBy;
                              }
                            }
                            
                            // Check application status first
                            final appStatus = app['status']?.toString() ?? 'PENDING';
                            String statusText = 'Applied';
                            Color statusColor = Colors.blue;
                            
                            if (appStatus == 'DECLINED') {
                              statusText = 'Declined';
                              statusColor = Colors.red;
                            } else if (appStatus == 'ACCEPTED') {
                              statusText = 'Accepted';
                              statusColor = Colors.green;
                              // Check job status for more details
                              final jobStatus = job['status']?.toString() ?? 'OPEN';
                              if (jobStatus == 'IN_PROGRESS') statusText = 'Accepted - In Progress';
                              if (jobStatus == 'COMPLETED') statusText = 'Accepted - Completed';
                            } else {
                              final status = job['status']?.toString() ?? 'OPEN';
                              if (status == 'IN_PROGRESS') {
                                statusText = 'In Progress';
                                statusColor = Colors.orange;
                              } else if (status == 'COMPLETED') {
                                statusText = 'Completed';
                                statusColor = Colors.green;
                              } else if (status == 'OPEN') {
                                statusText = 'Applied';
                                statusColor = Colors.blue;
                              }
                            }
                            
                            // Safely parse deadline
                            String daysText = "N/A";
                            try {
                              if (job['deadline'] != null) {
                                final deadline = job['deadline'].toString();
                                final deadlineDate = DateTime.parse(deadline);
                                final daysDiff = deadlineDate.difference(DateTime.now()).inDays;
                                daysText = daysDiff > 0 ? "$daysDiff days" : "Expired";
                              }
                            } catch (e) {
                              daysText = "N/A";
                            }
                            
                            return buildProjectCard(
                              title: job['title']?.toString() ?? 'Untitled Job',
                              author: authorName,
                              price: "₹${(job['budget'] ?? 0).toString()}",
                              status: statusText,
                              tags: (job['skillsRequired'] is List) 
                                  ? List<String>.from((job['skillsRequired'] as List).map((e) => e.toString()))
                                  : <String>[],
                              days: daysText,
                            );
                          }).toList(),
                        SizedBox(height: h(0.025)),
                      ],
                    ),
                  ),
                  ],
                ),
              ),
            ),
          ),
        ),
    );
  }
}

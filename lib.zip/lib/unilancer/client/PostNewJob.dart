import 'package:flutter/material.dart';
import '../../core/widgets/network_guard.dart';
import 'package:unihub/shared/shared_widgets.dart';
import '../../services/job_service.dart';

class PostNewJobPage extends StatefulWidget {
  const PostNewJobPage({super.key});

  @override
  State<PostNewJobPage> createState() => _PostNewJobPageState();
}

class _PostNewJobPageState extends State<PostNewJobPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _budgetController = TextEditingController();
  final TextEditingController _skillController = TextEditingController();
  DateTime? _deadline;

  String? _selectedCategory;
  String? _selectedExperience;
  List<String> skills = [];
  bool _isSubmitting = false;
  bool _isCustomCategory = false;
  final TextEditingController _customCategoryController = TextEditingController();

  // Expanded category list
  final List<String> _categories = [
    'Web Development',
    'Mobile App Development',
    'UI/UX Design',
    'Graphic Design',
    'Content Writing',
    'Data Science',
    'Machine Learning',
    'Digital Marketing',
    'Video Editing',
    'Photography',
    'Translation',
    'Tutoring',
    'Research',
    'Business Consulting',
    'Accounting',
    'Legal Services',
    'Others',
  ];

  int _currentIndex = 0; // ✅ for bottom navigation

  // Colors
  final Color primaryColor = const Color(0xFF8A47FF);
  final Color secondaryColor = const Color(0xFFC587FF);
  final Color backgroundColor = const Color(0xFFF8F6FF);

  @override
  Widget build(BuildContext context) {
    return NetworkGuard(
        child: Scaffold(
          backgroundColor: backgroundColor,
          appBar: AppBar(
            backgroundColor: backgroundColor,
            elevation: 0,
            title: const Text(
              "Post a New Job",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Colors.black,
              ),
            ),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () => Navigator.pop(context),
            ),
          ),

          // ✅ Form Body
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Job Details",
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      "Provide clear details to attract the right freelancers",
                      style: TextStyle(color: Colors.grey),
                    ),
                    const SizedBox(height: 24),

                    // Job Title
                    _buildTextField(
                      controller: _titleController,
                      label: "Job Title",
                      hint: "e.g., React Website Development",
                    ),
                    const SizedBox(height: 20),

                    // Category
                    _buildCategoryDropdown(),
                    const SizedBox(height: 20),

                    // Custom Category Input (shown when "Others" is selected)
                    if (_isCustomCategory) ...[
                      _buildTextField(
                        controller: _customCategoryController,
                        label: "Custom Category",
                        hint: "Enter your category name",
                      ),
                      const SizedBox(height: 20),
                    ],

                    // Project Description
                    _buildTextField(
                      controller: _descriptionController,
                      label: "Project Description",
                      hint:
                      "Describe your project requirements, goals, and any specific details...",
                      maxLines: 3,
                    ),
                    const SizedBox(height: 20),

                    // Budget & Deadline
                    Row(
                      children: [
                        Expanded(
                          child: _buildTextField(
                            controller: _budgetController,
                            label: "Budget (₹)",
                            hint: "e.g., 200-500",
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: InkWell(
                            onTap: () async {
                              DateTime? picked = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime.now(),
                                lastDate: DateTime(2100),
                              );
                              if (picked != null) {
                                setState(() => _deadline = picked);
                              }
                            },
                            child: InputDecorator(
                              decoration: _inputDecoration("Deadline"),
                              child: Text(
                                _deadline == null
                                    ? "dd-mm-yyyy"
                                    : "${_deadline!.day}-${_deadline!.month}-${_deadline!.year}",
                                style: const TextStyle(color: Colors.black87),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Experience Level
                    _buildDropdown(
                      label: "Experience Level",
                      value: _selectedExperience,
                      items: ["Beginner", "Intermediate", "Expert"],
                      onChanged: (val) =>
                          setState(() => _selectedExperience = val),
                    ),
                    const SizedBox(height: 20),

                    // Skills Required Section
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Skills Required",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          "Add the skills needed for this job",
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: TextFormField(
                                controller: _skillController,
                                decoration: _inputDecoration("Add a skill").copyWith(
                                  hintText: "e.g., React, Flutter, Python",
                                  suffixIcon: skills.isNotEmpty
                                      ? Icon(Icons.check_circle, color: Colors.green, size: 20)
                                      : null,
                                ),
                                onFieldSubmitted: (value) {
                                  if (value.trim().isNotEmpty) {
                                    setState(() {
                                      skills.add(value.trim());
                                      _skillController.clear();
                                    });
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 8),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: primaryColor,
                                shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(8)),
                                ),
                                minimumSize: const Size(48, 48),
                              ),
                              onPressed: () {
                                if (_skillController.text.trim().isNotEmpty) {
                                  setState(() {
                                    skills.add(_skillController.text.trim());
                                    _skillController.clear();
                                  });
                                }
                              },
                              child: const Icon(Icons.add, color: Colors.white),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        // Display added skills
                        if (skills.isEmpty)
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.grey.shade100,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.grey.shade300),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.info_outline, size: 16, color: Colors.grey.shade600),
                                const SizedBox(width: 8),
                                Text(
                                  "No skills added yet. Add at least one skill.",
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Colors.grey.shade600,
                                    fontStyle: FontStyle.italic,
                                  ),
                                ),
                              ],
                            ),
                          )
                        else
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.grey.shade300),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(Icons.label, size: 16, color: primaryColor),
                                    const SizedBox(width: 6),
                                    Text(
                                      "Added Skills (${skills.length})",
                                      style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.black87,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: skills
                                      .map((skill) => Chip(
                                    label: Text(
                                      skill,
                                      style: const TextStyle(fontSize: 13),
                                    ),
                                    backgroundColor: primaryColor.withOpacity(0.1),
                                    deleteIcon: Icon(
                                      Icons.close,
                                      size: 18,
                                      color: primaryColor,
                                    ),
                                    onDeleted: () =>
                                        setState(() => skills.remove(skill)),
                                  ))
                                      .toList(),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 28),

                    // Post Job Button
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.zero,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ).copyWith(
                          backgroundColor: MaterialStateProperty.resolveWith(
                                (states) => null,
                          ),
                        ),
                        onPressed: _isSubmitting ? null : _postJob,
                        child: Ink(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [primaryColor, secondaryColor],
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Container(
                            alignment: Alignment.center,
                            child: _isSubmitting
                                ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                            )
                                : const Text(
                              "Post Job",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          //
        )
    );
  }

  Future<void> _postJob() async {
    if (!_formKey.currentState!.validate()) return;

    if (_deadline == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select a deadline"), backgroundColor: Colors.red),
      );
      return;
    }

    if (skills.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please add at least one skill"), backgroundColor: Colors.red),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      // Use custom category if "Others" is selected, otherwise use selected category
      final category = _isCustomCategory && _customCategoryController.text.trim().isNotEmpty
          ? _customCategoryController.text.trim()
          : _selectedCategory!;

      await JobService.createJob(
        title: _titleController.text.trim(),
        category: category,
        description: _descriptionController.text.trim(),
        budget: double.tryParse(_budgetController.text) ?? 0.0,
        deadline: _deadline!,
        experienceLevel: _selectedExperience!,
        skillsRequired: skills,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Job Posted Successfully!"), backgroundColor: Colors.green),
      );
      Navigator.pop(context, true); // Return true to indicate job was posted
    } catch (e) {
      if (!mounted) return;
      setState(() => _isSubmitting = false);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Error: ${e.toString()}"),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _budgetController.dispose();
    _skillController.dispose();
    _customCategoryController.dispose();
    super.dispose();
  }

  // --- Reusable Widgets ---
  InputDecoration _inputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    String? hint,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      decoration: _inputDecoration(label).copyWith(hintText: hint),
      validator: (value) =>
      value!.isEmpty ? "Please enter $label" : null,
    );
  }

  Widget _buildCategoryDropdown() {
    return DropdownButtonFormField<String>(
      value: _selectedCategory,
      items: _categories
          .map((item) =>
          DropdownMenuItem(value: item, child: Text(item)))
          .toList(),
      onChanged: (val) {
        setState(() {
          _selectedCategory = val;
          _isCustomCategory = (val == 'Others');
          if (!_isCustomCategory) {
            _customCategoryController.clear();
          }
        });
      },
      decoration: _inputDecoration("Category"),
      validator: (value) {
        if (value == null) {
          return "Please select Category";
        }
        if (value == 'Others' && _customCategoryController.text.trim().isEmpty) {
          return "Please enter a custom category";
        }
        return null;
      },
    );
  }

  Widget _buildDropdown({
    required String label,
    required String? value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      items: items
          .map((item) =>
          DropdownMenuItem(value: item, child: Text(item)))
          .toList(),
      onChanged: onChanged,
      decoration: _inputDecoration(label),
      validator: (value) =>
      value == null ? "Please select $label" : null,
    );
  }
}
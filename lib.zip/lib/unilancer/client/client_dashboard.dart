import 'dart:async';
import 'package:flutter/material.dart';
import 'package:unihub/shared/shared_widgets.dart';

import 'PostNewJob.dart';
import 'managejobs.dart';
import '../../services/job_service.dart';

class ClientDashboardPage extends StatefulWidget {
  final VoidCallback onToggle;
  final ValueChanged<int> onTabChange;

  const ClientDashboardPage({
    super.key,
    required this.onToggle,
    required this.onTabChange,
  });

  @override
  State<ClientDashboardPage> createState() => _ClientDashboardPageState();
}

class _ClientDashboardPageState extends State<ClientDashboardPage> {
  int _activeJobs = 0;
  double _totalSpent = 0.0;
  bool _isLoading = true;
  List<dynamic> _recentJobs = [];
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _loadStats();
    
    // Setup periodic refresh for real-time updates (every 30 seconds)
    _refreshTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      if (mounted && !_isLoading) {
        _loadStats();
      }
    });
  }

  Future<void> _loadStats() async {
    if (!mounted) return;
    setState(() => _isLoading = true);
    try {
      final result = await JobService.getMyJobs(page: 1, limit: 100); // Get more for stats
      final jobs = result['jobs'] as List<dynamic>;
      final activeJobs = jobs.where((job) => 
        job['status'] == 'OPEN' || job['status'] == 'IN_PROGRESS'
      ).length;
      
      // Calculate total spent from COMPLETED and CLOSED jobs
      final completedJobs = jobs.where((job) => 
        job['status'] == 'COMPLETED' || job['status'] == 'CLOSED'
      );
      final totalSpent = completedJobs.fold<double>(
        0.0,
        (sum, job) => sum + (job['budget']?.toDouble() ?? 0.0),
      );

      // Get recent jobs (limit to 3 most recent)
      final recentJobs = jobs.take(3).toList();

      if (mounted) {
        setState(() {
          _activeJobs = activeJobs;
          _totalSpent = totalSpent;
          _recentJobs = recentJobs;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }
  
  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    double h(double ratio) => screenHeight * ratio;
    double w(double ratio) => screenWidth * ratio;
    double sp(double ratio) => screenWidth * ratio;

    return Scaffold(
      backgroundColor: const Color(0xFFF8F6FF),
      body: SafeArea(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 480),
          width: double.infinity,
          color: const Color(0xFFF8F6FF),
          child: RefreshIndicator(
            onRefresh: _loadStats,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(height: h(0.02)),

                  Padding(
                    padding: EdgeInsets.only(
                      top: h(0.02),
                      bottom: h(0.022),
                      left: w(0.05),
                      right: w(0.05),
                    ),
                    child: Column(
                      children: [
                        Text(
                          "Welcome Back, Client!",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: sp(0.058),
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: h(0.01)),
                        Text(
                          "Manage your projects and find talented freelancers",
                          style: TextStyle(color: Colors.black54, fontSize: sp(0.043)),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: w(0.032), vertical: h(0.014)),
                    child: Row(
                      children: [
                        Expanded(
                          child: buildStatCard(
                            "Active Jobs",
                            _isLoading ? "..." : _activeJobs.toString(),
                            Icons.business_center,
                            fontSize: sp(0.07),
                          ),
                        ),
                        SizedBox(width: w(0.045)),
                        Expanded(
                          child: buildStatCard(
                            "Total Spent",
                            _isLoading ? "..." : "${_totalSpent.toStringAsFixed(0)}",
                            Icons.currency_rupee,
                            fontSize: sp(0.07),
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: h(0.025)),

                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: w(0.032)),
                    child: buildGradientButton(
                      label: "Post New Job",
                      icon: Icons.add,
                      onPressed: () async {
                        final result = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const PostNewJobPage(),
                          ),
                        );
                        // Refresh stats if job was posted
                        if (result == true) {
                          _loadStats();
                        }
                      },
                    ),
                  ),

                  SizedBox(height: h(0.013)),

                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: w(0.032)),
                    child: buildOutlinedButton(
                      label: "Manage Jobs",
                      onPressed: () {
                        widget.onTabChange(1);
                      },
                    ),
                  ),
                  SizedBox(height: h(0.013)),

                  SizedBox(height: h(0.022)),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: w(0.047)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Recent Projects",
                          style: TextStyle(fontSize: sp(0.047), fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: h(0.003)),
                        Text(
                          "Stay updated with your latest activity",
                          style: TextStyle(color: Colors.black54, fontSize: sp(0.037)),
                        ),
                        SizedBox(height: h(0.018)),
                        if (_isLoading)
                          const Center(child: Padding(
                            padding: EdgeInsets.all(20.0),
                            child: CircularProgressIndicator(),
                          ))
                        else if (_recentJobs.isEmpty)
                          Container(
                            padding: EdgeInsets.symmetric(vertical: h(0.04), horizontal: w(0.04)),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  const Color(0xFF8A47FF).withOpacity(0.05),
                                  const Color(0xFFC587FF).withOpacity(0.08),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: const Color(0xFF8A47FF).withOpacity(0.2),
                                width: 1.5,
                              ),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  padding: EdgeInsets.all(w(0.06)),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF8A47FF).withOpacity(0.1),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    Icons.work_outline,
                                    size: 56,
                                    color: const Color(0xFF8A47FF),
                                  ),
                                ),
                                SizedBox(height: h(0.02)),
                                Text(
                                  "No jobs posted yet",
                                  style: TextStyle(
                                    fontSize: sp(0.045),
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black87,
                                  ),
                                ),
                                SizedBox(height: h(0.008)),
                                Padding(
                                  padding: EdgeInsets.symmetric(horizontal: w(0.05)),
                                  child: Text(
                                    "Start by posting your first job and connect with talented freelancers from your campus",
                                    style: TextStyle(
                                      fontSize: sp(0.037),
                                      color: Colors.black54,
                                      height: 1.4,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                SizedBox(height: h(0.025)),
                                Container(
                                  padding: EdgeInsets.symmetric(horizontal: w(0.04), vertical: h(0.01)),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(12),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.05),
                                        blurRadius: 8,
                                        offset: const Offset(0, 2),
                                      ),
                                    ],
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.lightbulb_outline,
                                        size: 20,
                                        color: const Color(0xFF8A47FF),
                                      ),
                                      SizedBox(width: w(0.02)),
                                      Text(
                                        "Tip: Be specific about requirements",
                                        style: TextStyle(
                                          fontSize: sp(0.033),
                                          color: const Color(0xFF8A47FF),
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: h(0.02)),
                                SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton.icon(
                                    onPressed: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => const PostNewJobPage(),
                                        ),
                                      );
                                    },
                                    icon: const Icon(Icons.add_circle_outline, color: Colors.white),
                                    label: const Text(
                                      "Post Your First Job",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF8A47FF),
                                      padding: EdgeInsets.symmetric(vertical: h(0.016)),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      elevation: 2,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        else
                          ..._recentJobs.map((job) {
                            final assignedTo = job['assignedTo'];
                            final status = job['status'] ?? 'OPEN';
                            String statusText = status;
                            if (status == 'IN_PROGRESS') statusText = 'In Progress';
                            if (status == 'COMPLETED') statusText = 'Completed';
                            if (status == 'OPEN') statusText = 'Open';
                            
                            return buildProjectCard(
                              title: job['title'] ?? 'Untitled Job',
                              author: assignedTo != null && assignedTo['name'] != null 
                                  ? assignedTo['name'] 
                                  : 'No freelancer assigned',
                              price: "₹${job['budget']?.toString() ?? '0'}",
                              status: statusText,
                              tags: List<String>.from(job['skillsRequired'] ?? []),
                              days: job['deadline'] != null 
                                  ? "${DateTime.parse(job['deadline']).difference(DateTime.now()).inDays} days"
                                  : "N/A",
                            );
                          }).toList(),
                        SizedBox(height: h(0.025)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:unihub/shared/shared_widgets.dart';
import '../../services/job_service.dart';
import '../../core/widgets/network_guard.dart';
import '../../services/application_service.dart';
import '../../services/review_service.dart';
import '../../services/api_service.dart';

class ManageJobDetailsPage extends StatefulWidget {
  final VoidCallback? onBack;
  final String? jobId;

  const ManageJobDetailsPage({super.key, this.onBack, this.jobId});

  @override
  State<ManageJobDetailsPage> createState() => _ManageJobDetailsPageState();
}

class _ManageJobDetailsPageState extends State<ManageJobDetailsPage> {

  static const Color primaryColor = Color(0xFF8A47FF);
  static const Color secondaryColor = Color(0xFFC587FF);
  static const Color backgroundColor = Color(0xFFF8F6FF);
  static const Color softPurple = Color(0xFFF3EFFF);

  List<dynamic> jobs = [];
  Map<String, dynamic>? selectedJob;
  List<dynamic> applications = [];
  bool _isLoading = true;
  String? _error;
  Map<String, dynamic>? _jobReview;

  @override
  void initState() {
    super.initState();
    _loadJobs();
  }

  Future<void> _loadJobs() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final result = await JobService.getMyJobs(page: 1, limit: 100); // Get all jobs for management
      final fetchedJobs = result['jobs'] as List<dynamic>;
      setState(() {
        jobs = fetchedJobs;
        // Update selectedJob if it exists to get latest data
        if (selectedJob != null) {
          final updatedJob = fetchedJobs.firstWhere(
                (j) => j['_id'] == selectedJob!['_id'],
            orElse: () => selectedJob!,
          );
          selectedJob = updatedJob;
        } else if (widget.jobId != null) {
          selectedJob = jobs.firstWhere((j) => j['_id'] == widget.jobId, orElse: () => null);
          if (selectedJob != null) {
            _loadApplications(selectedJob!['_id']);
            return;
          }
        }
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  Future<void> _loadApplications(String jobId) async {
    try {
      setState(() {
        _isLoading = true;
      });
      final fetchedApplications = await ApplicationService.getClientApplications();
      final applicationsForJob = fetchedApplications.where((app) {
        final appJobId = app['jobId'] is Map ? app['jobId']['_id'] : app['jobId'];
        return appJobId == jobId;
      }).toList();

      // Fetch freelancer stats (rating and completed jobs) for each application
      final applicationsWithStats = await Future.wait(
        applicationsForJob.map((app) async {
          final freelancer = app['freelancerId'] ?? {};
          final freelancerId = freelancer['_id']?.toString();

          if (freelancerId == null) {
            return {
              ...app,
              'freelancerRating': 0.0,
              'completedJobs': 0,
            };
          }

          try {
            // Get freelancer reviews to calculate rating
            final reviewsData = await ReviewService.getFreelancerReviews(freelancerId);
            final rating = reviewsData['averageRating'] ?? 0.0;

            // Get completed jobs count
            final completedJobsResponse = await ApiService.get('/jobs/freelancer/$freelancerId/completed');
            final completedJobs = completedJobsResponse['data']['count'] ?? 0;

            return {
              ...app,
              'freelancerRating': rating,
              'completedJobs': completedJobs,
            };
          } catch (e) {
            // If error, use defaults
            return {
              ...app,
              'freelancerRating': 0.0,
              'completedJobs': 0,
            };
          }
        }),
      );

      setState(() {
        applications = applicationsWithStats;
        _isLoading = false;
      });

      // Load review if job is completed or closed (reviewed)
      if (selectedJob != null && (selectedJob!['status'] == 'COMPLETED' || selectedJob!['status'] == 'CLOSED')) {
        _loadReview(jobId);
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  Future<void> _showProposalDetail({
    required String name,
    required String email,
    required String phone,
    required String coverLetter,
    dynamic budget,
    String? pricingType,
    dynamic deliveryDays,
    required List skills,
    String? portfolioLink,
    bool agreementAccepted = false,
  }) async {
    await showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Container(
          constraints: const BoxConstraints(maxWidth: 500, maxHeight: 600),
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Proposal Details",
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const Divider(),
                const SizedBox(height: 16),

                // Proposal Summary
                const Text(
                  "Proposal Summary",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    coverLetter,
                    style: const TextStyle(fontSize: 14, height: 1.5),
                  ),
                ),
                const SizedBox(height: 20),

                // Budget & Timeline
                if (budget != null || pricingType != null || deliveryDays != null) ...[
                  const Text(
                    "Budget & Timeline",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade50,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      children: [
                        if (budget != null)
                          _detailRow("Proposed Budget", "₹${budget is num ? (budget as num).toStringAsFixed(0) : budget.toString()}"),
                        if (pricingType != null)
                          _detailRow("Pricing Type", pricingType),
                        if (deliveryDays != null)
                          _detailRow("Estimated Delivery Time", "$deliveryDays days"),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                ],

                // Skills
                if (skills.isNotEmpty) ...[
                  const Text(
                    "Skills",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: skills.map((s) => Chip(
                      label: Text(s.toString()),
                      backgroundColor: Colors.grey.shade200,
                    )).toList(),
                  ),
                  const SizedBox(height: 20),
                ],

                // Contact
                if (phone.isNotEmpty && phone != 'Not provided') ...[
                  const Text(
                    "Contact",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  _detailRow("Phone", phone),
                  const SizedBox(height: 20),
                ],

                // Portfolio
                if (portfolioLink != null && portfolioLink.isNotEmpty) ...[
                  const Text(
                    "Portfolio",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () {
                        // Open portfolio link - can use url_launcher package
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("Opening: $portfolioLink")),
                        );
                      },
                      icon: const Icon(Icons.open_in_new),
                      label: const Text("Open Portfolio"),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],

                // Integrity Notice
                if (agreementAccepted)
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.green.shade200),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.verified, color: Colors.green.shade700, size: 20),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            "Freelancer confirmed this work will be original and not plagiarized.",
                            style: TextStyle(
                              color: Colors.green.shade700,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(color: Colors.grey.shade700, fontSize: 14),
          ),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
          ),
        ],
      ),
    );
  }

  Future<void> _loadReview(String jobId) async {
    try {
      final review = await ReviewService.getJobReview(jobId);
      setState(() {
        _jobReview = review;
      });
    } catch (e) {
      // Review doesn't exist yet
      setState(() {
        _jobReview = null;
      });
    }
  }

  Future<void> _showReviewDialog(String jobId, String freelancerId, String freelancerName) async {
    int selectedRating = 5;
    final commentController = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Review Freelancer'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Rate $freelancerName',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (index) {
                    return IconButton(
                      icon: Icon(
                        index < selectedRating ? Icons.star : Icons.star_border,
                        color: Colors.amber,
                        size: 40,
                      ),
                      onPressed: () {
                        setDialogState(() {
                          selectedRating = index + 1;
                        });
                      },
                    );
                  }),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Comment (Optional)',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: commentController,
                  maxLines: 4,
                  decoration: InputDecoration(
                    hintText: 'Share your experience...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryColor,
              ),
              onPressed: () async {
                // Show loading indicator
                setDialogState(() {
                  // Disable button during submission
                });

                try {
                  await ReviewService.createReview(
                    jobId: jobId,
                    rating: selectedRating,
                    comment: commentController.text.trim(),
                  );

                  if (!mounted) return;

                  // Close dialog first
                  Navigator.pop(context);

                  // Show success message
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Review submitted successfully!'),
                      backgroundColor: Colors.green,
                      duration: Duration(seconds: 3),
                    ),
                  );

                  // Reload review and refresh job data
                  await _loadReview(jobId);
                  await _loadJobs(); // Reload jobs to get updated status

                  // Reload applications if job is selected to refresh review display
                  if (selectedJob != null && selectedJob!['_id'] == jobId) {
                    await _loadApplications(jobId);
                    // Force a rebuild to show the review
                    if (mounted) {
                      setState(() {
                        // Trigger rebuild to show review
                      });
                    }
                  }
                } catch (e) {
                  if (!mounted) return;

                  // Close dialog
                  Navigator.pop(context);

                  // Show error message with better formatting
                  String errorMessage = 'Failed to submit review';
                  if (e.toString().contains('message')) {
                    // Try to extract the error message
                    final match = RegExp(r'message[:\s]+([^\n]+)').firstMatch(e.toString());
                    if (match != null) {
                      errorMessage = match.group(1) ?? errorMessage;
                    } else {
                      errorMessage = e.toString().replaceAll('Exception: ', '');
                    }
                  } else {
                    errorMessage = e.toString().replaceAll('Exception: ', '');
                  }

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(errorMessage),
                      backgroundColor: Colors.red,
                      duration: const Duration(seconds: 4),
                    ),
                  );
                }
              },
              child: const Text('Submit Review', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;

    double h(double ratio) => screenHeight * ratio;
    double w(double ratio) => screenWidth * ratio;

    return NetworkGuard(
      child: _buildContent(context, h, w),
    );
  }

  Widget _buildContent(BuildContext context, double Function(double) h, double Function(double) w) {
    if (_isLoading) {
      return Scaffold(
        backgroundColor: backgroundColor,
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (_error != null) {
      return Scaffold(
        backgroundColor: backgroundColor,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Error: $_error'),
              ElevatedButton(
                onPressed: _loadJobs,
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    // Show job list if no job is selected
    if (selectedJob == null && jobs.isNotEmpty) {
      return WillPopScope(
        onWillPop: () async {
          if (widget.onBack != null) widget.onBack!();
          return false;
        },
        child: Scaffold(
          backgroundColor: backgroundColor,
          appBar: AppBar(
            backgroundColor: backgroundColor,
            elevation: 0,
            automaticallyImplyLeading: false,
            title: const Text(
              "Manage Jobs",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.black87),
            ),
          ),
          body: RefreshIndicator(
            onRefresh: _loadJobs,
            child: jobs.isEmpty
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.work_outline,
                    size: 80,
                    color: Colors.grey.shade300,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No jobs posted yet',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey.shade600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Post your first job to get started',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey.shade500,
                    ),
                  ),
                ],
              ),
            )
                : ListView.builder(
              padding: EdgeInsets.all(w(0.04)),
              itemCount: jobs.length,
              itemBuilder: (context, index) {
                final job = jobs[index];
                return _buildJobCard(job, w, h);
              },
            ),
          ),
        ),
      );
    }

    // Show job details and applications
    if (selectedJob == null) {
      return WillPopScope(
        onWillPop: () async {
          if (widget.onBack != null) widget.onBack!();
          return false;
        },
        child: Scaffold(
          backgroundColor: backgroundColor,
          body: const Center(child: Text('No jobs found')),
        ),
      );
    }

    final job = selectedJob!;
    return WillPopScope(
      onWillPop: () async {
        if (applications.isNotEmpty || selectedJob != null) {
          setState(() {
            selectedJob = null;
            applications = [];
          });
          // Reload jobs list when going back to ensure all jobs are shown
          await _loadJobs();
          return false;
        }
        if (widget.onBack != null) widget.onBack!();
        return false;
      },
      child: Scaffold(
        backgroundColor: backgroundColor,
        body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: w(0.04)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: h(0.01)),
                Text(
                  job['title'] ?? 'Job',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Colors.black87,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.zero,
                  child: Text(
                    "${applications.length} bids received",
                    style: const TextStyle(color: Colors.black54, fontSize: 13),
                  ),
                ),
                SizedBox(height: h(0.02)),
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(w(0.04)),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFE9E6F7)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          _pill(
                            child: Text(
                              "Budget: ₹${job['budget'] ?? 0}",
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.black87,
                                fontSize: 13,
                              ),
                            ),
                            bg: const Color(0xFFF4F1FF),
                          ),
                          const Spacer(),
                          _pill(
                            child: Text(
                              job['status'] ?? 'OPEN',
                              style: const TextStyle(
                                color: Colors.black87,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            bg: const Color(0xFFF0EFF6),
                            radius: 20,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 4,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: h(0.015)),
                      Text(
                        job['description'] ?? '',
                        style: const TextStyle(color: Colors.black87),
                      ),
                      // Skills Required
                      if (job['skillsRequired'] != null && (job['skillsRequired'] as List).isNotEmpty) ...[
                        SizedBox(height: h(0.015)),
                        const Text(
                          "Skills Required:",
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Colors.black87,
                          ),
                        ),
                        SizedBox(height: h(0.008)),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: (job['skillsRequired'] as List)
                              .map((skill) => Chip(
                            label: Text(
                              skill.toString(),
                              style: const TextStyle(fontSize: 12),
                            ),
                            backgroundColor: primaryColor.withOpacity(0.1),
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ))
                              .toList(),
                        ),
                      ],
                    ],
                  ),
                ),
                SizedBox(height: h(0.04)),
                const Text(
                  "Received Bids",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                ),
                SizedBox(height: h(0.02)),
                if (applications.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Text('No applications yet'),
                  )
                else
                  Column(
                    children: applications.asMap().entries.map((entry) {
                      final index = entry.key;
                      final app = entry.value;
                      final freelancer = app['freelancerId'] ?? {};
                      final assignedTo = job['assignedTo'];
                      final freelancerId = freelancer['_id']?.toString();
                      final appStatus = app['status']?.toString() ?? 'PENDING';
                      bool isAccepted = false;
                      bool isDeclined = appStatus == 'DECLINED';

                      // Check if this freelancer is assigned (for both IN_PROGRESS and COMPLETED status)
                      if ((job['status'] == 'IN_PROGRESS' || job['status'] == 'COMPLETED') && assignedTo != null) {
                        if (assignedTo is Map) {
                          isAccepted = assignedTo['_id']?.toString() == freelancerId;
                        } else {
                          isAccepted = assignedTo.toString() == freelancerId;
                        }
                      }

                      // Extract application data
                      final coverLetter = app['coverLetter'] ?? app['message'] ?? '';
                      final budget = app['budget'];
                      final pricingType = app['pricingType'] ?? '';
                      final deliveryDays = app['deliveryDays'];
                      final proposalSkills = List<String>.from(app['skills'] ?? []);
                      final portfolioLink = app['portfolioLink'] ?? '';
                      final agreementAccepted = app['agreementAccepted'] ?? false;

                      return _bidCard(
                        avatarBg: Colors.blue.shade100,
                        name: freelancer['name'] ?? 'Unknown',
                        email: freelancer['email'] ?? 'Not provided',
                        timeAgo: "Recently",
                        rating: (app['freelancerRating'] ?? 0.0).toDouble(),
                        jobs: app['completedJobs'] ?? 0,
                        description: coverLetter,
                        skills: proposalSkills.isNotEmpty ? proposalSkills : List<String>.from(freelancer['skills'] ?? []),
                        phone: app['phone'] ?? 'Not provided',
                        budget: budget,
                        pricingType: pricingType,
                        deliveryDays: deliveryDays,
                        portfolioLink: portfolioLink,
                        agreementAccepted: agreementAccepted,
                        freelancerId: freelancer['_id'],
                        applicationId: app['_id'],
                        jobId: job['_id'],
                        isAccepted: isAccepted,
                        isDeclined: isDeclined,
                        job: job,
                      );
                    }).toList(),
                  ),
                SizedBox(height: h(0.03)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildJobCard(Map<String, dynamic> job, double Function(double) w, double Function(double) h) {
    final status = job['status'] ?? 'OPEN';
    final statusColor = _getStatusColor(status);
    final statusBg = _getStatusBgColor(status);

    return GestureDetector(
      onTap: () async {
        await _loadApplications(job['_id']);
        setState(() {
          selectedJob = job;
        });
      },
      child: Container(
        margin: EdgeInsets.only(bottom: h(0.02)),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          job['title'] ?? 'Untitled Job',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Icon(
                              Icons.currency_rupee,
                              size: 16,
                              color: primaryColor,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '${job['budget'] ?? 0}',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: primaryColor,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: statusBg,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      status,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: statusColor,
                      ),
                    ),
                  ),
                ],
              ),
              if (job['description'] != null && job['description'].toString().isNotEmpty) ...[
                const SizedBox(height: 12),
                Text(
                  job['description'],
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey.shade600,
                    height: 1.4,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
              // Skills Required
              if (job['skillsRequired'] != null && (job['skillsRequired'] as List).isNotEmpty) ...[
                const SizedBox(height: 12),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: (job['skillsRequired'] as List)
                      .map((skill) => Chip(
                    label: Text(
                      skill.toString(),
                      style: const TextStyle(fontSize: 11),
                    ),
                    backgroundColor: primaryColor.withOpacity(0.1),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 0),
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    visualDensity: VisualDensity.compact,
                  ))
                      .toList(),
                ),
              ],
              const SizedBox(height: 12),
              Row(
                children: [
                  Icon(
                    Icons.access_time,
                    size: 16,
                    color: Colors.grey.shade500,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _formatDate(job['deadline']),
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade600,
                    ),
                  ),
                  const Spacer(),
                  Icon(
                    Icons.arrow_forward_ios,
                    size: 14,
                    color: primaryColor,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toUpperCase()) {
      case 'OPEN':
        return const Color(0xFF2196F3);
      case 'IN_PROGRESS':
        return const Color(0xFFFF9800);
      case 'COMPLETED':
        return const Color(0xFF4CAF50);
      case 'CLOSED':
        return Colors.grey;
      default:
        return Colors.grey;
    }
  }

  Color _getStatusBgColor(String status) {
    switch (status.toUpperCase()) {
      case 'OPEN':
        return const Color(0xFFE3F2FD);
      case 'IN_PROGRESS':
        return const Color(0xFFFFF3E0);
      case 'COMPLETED':
        return const Color(0xFFE8F5E9);
      case 'CLOSED':
        return Colors.grey.shade100;
      default:
        return Colors.grey.shade100;
    }
  }

  String _formatDate(dynamic date) {
    if (date == null) return 'No deadline';
    try {
      final dateStr = date.toString();
      if (dateStr.contains('T')) {
        final dateTime = DateTime.parse(dateStr);
        final now = DateTime.now();
        final difference = dateTime.difference(now);
        if (difference.inDays > 0) {
          return '${difference.inDays} days left';
        } else if (difference.inDays == 0) {
          return 'Due today';
        } else {
          return 'Overdue';
        }
      }
      return 'Deadline: $dateStr';
    } catch (e) {
      return 'Deadline: $date';
    }
  }

  Widget _pill({
    required Widget child,
    required Color bg,
    double radius = 12,
    EdgeInsetsGeometry padding = const EdgeInsets.symmetric(
      horizontal: 10,
      vertical: 6,
    ),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
      ),
      child: child,
    );
  }

  Widget _skillChip(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF2F2F5),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Text(text, style: const TextStyle(fontSize: 12)),
    );
  }

  Future<void> _acceptBid(String jobId, String freelancerId) async {
    try {
      setState(() {
        _isLoading = true;
      });
      await JobService.startJob(jobId, freelancerId);
      if (!mounted) return;

      // Reload jobs first to get updated job data with new status and assignedTo
      final result = await JobService.getMyJobs(page: 1, limit: 100);
      final fetchedJobs = result['jobs'] as List<dynamic>;
      final updatedJob = fetchedJobs.firstWhere(
            (j) => j['_id'] == jobId,
        orElse: () => selectedJob!,
      );

      setState(() {
        jobs = fetchedJobs;
        selectedJob = updatedJob;
      });

      // Then reload applications for the updated job
      await _loadApplications(jobId);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Bid accepted! Job started successfully.'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _declineBid(String applicationId) async {
    try {
      setState(() {
        _isLoading = true;
      });
      await ApplicationService.deleteApplication(applicationId);
      if (!mounted) return;

      // Reload applications to refresh UI immediately
      if (selectedJob != null) {
        await _loadApplications(selectedJob!['_id']);
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Application declined'),
          backgroundColor: Colors.orange,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Widget _bidCard({
    required Color avatarBg,
    required String name,
    required String email,
    required String timeAgo,
    required double rating,
    required int jobs,
    required String description,
    required List skills,
    required String phone,
    dynamic budget,
    String? pricingType,
    dynamic deliveryDays,
    String? portfolioLink,
    bool agreementAccepted = false,
    String? freelancerId,
    String? applicationId,
    String? jobId,
    bool isAccepted = false,
    bool isDeclined = false,
    required Map<String, dynamic> job,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16), // Add gap between bids
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE9E6F7)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: avatarBg,
                child: const Icon(Icons.person, color: Colors.white),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                    Row(
                      children: [
                        const Icon(
                          Icons.star,
                          size: 16,
                          color: Color(0xFFFFC107),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          rating > 0
                              ? "${rating.toStringAsFixed(1)} • $jobs ${jobs == 1 ? 'job' : 'jobs'}"
                              : "No rating • $jobs ${jobs == 1 ? 'job' : 'jobs'}",
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.black54,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          Icons.phone,
                          size: 14,
                          color: Colors.grey.shade600,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          phone,
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          Icons.email,
                          size: 14,
                          color: Colors.grey.shade600,
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            email,
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey.shade600,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Text(
                timeAgo,
                style: const TextStyle(fontSize: 12, color: Colors.black45),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Budget & Pricing Type Row - ALWAYS SHOW if any field exists
          if (budget != null || (pricingType != null && pricingType.isNotEmpty) || deliveryDays != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: softPurple,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  if (budget != null) ...[
                    const Icon(Icons.currency_rupee, color: primaryColor, size: 18),
                    const SizedBox(width: 4),
                    Text(
                      "₹${budget is num ? (budget as num).toStringAsFixed(0) : budget.toString()}",
                      style: const TextStyle(
                        color: primaryColor,
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                      ),
                    ),
                    if ((pricingType != null && pricingType.isNotEmpty) || deliveryDays != null) const SizedBox(width: 16),
                  ],
                  if (pricingType != null && pricingType.isNotEmpty) ...[
                    Icon(Icons.work_outline, size: 16, color: Colors.grey.shade700),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        pricingType,
                        style: TextStyle(
                          color: Colors.grey.shade700,
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (deliveryDays != null) const SizedBox(width: 16),
                  ],
                  if (deliveryDays != null) ...[
                    const Icon(Icons.access_time, size: 16, color: primaryColor),
                    const SizedBox(width: 4),
                    Text(
                      "$deliveryDays days",
                      style: const TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ],
              ),
            ),

          const SizedBox(height: 12),

          // Cover Letter Preview (2 lines max)
          if (description.isNotEmpty)
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  description,
                  style: const TextStyle(color: Colors.black87, fontSize: 13),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                if (description.length > 100)
                  TextButton(
                    onPressed: () => _showProposalDetail(
                      name: name,
                      email: email,
                      phone: phone,
                      coverLetter: description,
                      budget: budget,
                      pricingType: pricingType,
                      deliveryDays: deliveryDays,
                      skills: skills,
                      portfolioLink: portfolioLink,
                      agreementAccepted: agreementAccepted,
                    ),
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                      minimumSize: const Size(0, 30),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    child: const Text(
                      "View Full Proposal",
                      style: TextStyle(
                        color: primaryColor,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
              ],
            ),

          const SizedBox(height: 10),

          // Skills (up to 3 chips + more)
          if (skills.isNotEmpty)
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                ...skills.take(3).map<Widget>((s) => _skillChip(s.toString())),
                if (skills.length > 3)
                  _skillChip("+${skills.length - 3} more"),
              ],
            ),

          // Portfolio Link indicator
          if (portfolioLink != null && portfolioLink.isNotEmpty) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                Icon(Icons.link, size: 16, color: Colors.blue.shade700),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    "Portfolio: ${portfolioLink.length > 40 ? portfolioLink.substring(0, 40) + '...' : portfolioLink}",
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.blue.shade700,
                      fontWeight: FontWeight.w500,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ],

          // Agreement Accepted indicator
          if (agreementAccepted) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.verified, size: 16, color: Colors.green.shade700),
                const SizedBox(width: 6),
                Text(
                  "Work will be original and not plagiarized",
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.green.shade700,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],

          const SizedBox(height: 12),
          const Divider(height: 1),
          const SizedBox(height: 12),
          // Show review section when job is COMPLETED (freelancer submitted work) or CLOSED (reviewed)
          if ((job['status'] == 'COMPLETED' || job['status'] == 'CLOSED') && isAccepted)
            Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.green.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.check_circle, color: Colors.green.shade700, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          job['status'] == 'CLOSED'
                              ? "Job Completed & Reviewed"
                              : "Job Completed - Work Submitted",
                          style: TextStyle(
                            color: Colors.green.shade700,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                _jobReview != null
                    ? Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.green.shade200),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.star, color: Colors.amber, size: 20),
                          const SizedBox(width: 8),
                          Text(
                            "Review Submitted",
                            style: TextStyle(
                              color: Colors.green.shade700,
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: List.generate(5, (index) {
                          final rating = _jobReview!['rating'] ?? 0;
                          return Icon(
                            index < rating ? Icons.star : Icons.star_border,
                            color: Colors.amber,
                            size: 20,
                          );
                        }),
                      ),
                      if (_jobReview!['comment'] != null && 
                          _jobReview!['comment'].toString().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text(
                          _jobReview!['comment'].toString(),
                          style: TextStyle(
                            color: Colors.black87,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ],
                  ),
                )
                    : SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primaryColor,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    icon: const Icon(Icons.star, color: Colors.white, size: 24),
                    label: const Text(
                      "Review Freelancer",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    onPressed: () {
                      _showReviewDialog(
                        job['_id'],
                        freelancerId ?? '',
                        name,
                      );
                    },
                  ),
                ),
              ],
            )
          // Show "Bid Accepted" message when job is IN_PROGRESS
          else if (job['status'] == 'IN_PROGRESS' && isAccepted)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.green.shade200),
              ),
              child: Row(
                children: [
                  Icon(Icons.check_circle, color: Colors.green.shade700, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      "Bid Accepted - Job in Progress",
                      style: TextStyle(
                        color: Colors.green.shade700,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            )
          // Show "Declined" status if application is declined
          else if (isDeclined)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.red.shade200),
                ),
                child: Row(
                  children: [
                    Icon(Icons.cancel, color: Colors.red.shade700, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        "Application Declined",
                        style: TextStyle(
                          color: Colors.red.shade700,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              )
            // Show Accept/Decline buttons when job is OPEN and not declined
            else if (job['status'] == 'OPEN')
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF27AE60),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        onPressed: (freelancerId != null && jobId != null)
                            ? () => _acceptBid(jobId, freelancerId)
                            : null,
                        icon: const Icon(Icons.check, color: Colors.white),
                        label: const Text(
                          "Accept",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      height: 44,
                      width: 44,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(color: Colors.grey.shade300),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: EdgeInsets.zero,
                        ),
                        onPressed: (applicationId != null) ? () => _declineBid(applicationId) : null,
                        child: const Icon(Icons.close, color: Colors.red),
                      ),
                    ),
                  ],
                ),
        ],
      ),
    );
  }
}
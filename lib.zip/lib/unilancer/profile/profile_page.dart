import 'dart:io';

import 'package:flutter/material.dart';
import '../../core/widgets/network_guard.dart';
import 'package:image_picker/image_picker.dart';
import '../../auth/signin_screen.dart';
import '../../services/user_service.dart';
import '../../services/auth_service.dart';
import '../../services/api_service.dart';

class WorkItem {
  final String title, company, workplace, price, date;
  final double rating;
  WorkItem(this.title, this.company, this.workplace, this.price, this.date, this.rating);
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool editing = false;
  int selectedTab = 0;
  bool _isLoading = true;

  // Profile fields - matching profile fill page
  String name = "";
  String email = "";
  String about = "";
  String? university;
  String? yearOfStudy;
  String? profession;
  String? profileImageUrl;
  List<String> skills = [];

  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  late TextEditingController nameController;
  late TextEditingController aboutController;
  late TextEditingController yearOfStudyController;
  late TextEditingController professionController;
  late List<TextEditingController> skillControllers;
  final TextEditingController newSkillController = TextEditingController();
  
  final List<String> yearOfStudyOptions = [
    '1st Year',
    '2nd Year',
    '3rd Year',
    '4th Year',
    'Graduate',
    'Post Graduate',
  ];

  final List<String> professionOptions = [
    'Student',
    'Professional',
    'Graduate',
    'Other',
  ];

  final List<String> universities = [
    'SRM AP',
    'VIT AP',
    'Amrita AP',
    'KLU',
  ];

  List<WorkItem> workItems = [];

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController();
    aboutController = TextEditingController();
    yearOfStudyController = TextEditingController();
    professionController = TextEditingController();
    skillControllers = [];
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    setState(() => _isLoading = true);
    try {
      final userData = await UserService.getProfile();
      setState(() {
        name = userData['name'] ?? '';
        email = userData['email'] ?? '';
        about = userData['about'] ?? '';
        university = userData['university'];
        yearOfStudy = userData['yearOfStudy'];
        profession = userData['profession'];
        profileImageUrl = userData['profileImage'];
        skills = List<String>.from(userData['skills'] ?? []);
        nameController.text = name;
        aboutController.text = about;
        yearOfStudyController.text = yearOfStudy ?? '';
        professionController.text = profession ?? '';
        skillControllers = skills.map((skill) => TextEditingController(text: skill)).toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading profile: ${e.toString()}')),
      );
    }
  }

  @override
  void dispose() {
    nameController.dispose();
    aboutController.dispose();
    yearOfStudyController.dispose();
    professionController.dispose();
    for (var controller in skillControllers) {
      controller.dispose();
    }
    newSkillController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _profileImage = File(pickedFile.path);
        _isLoading = true;
      });
      
      try {
        // Upload image
        final imageUrls = await ApiService.uploadImages([pickedFile.path]);
        if (imageUrls.isNotEmpty) {
          setState(() {
            profileImageUrl = imageUrls.first;
          });
          // Auto-save profile with new image URL
          await saveProfile();
        }
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error uploading image: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  Future<void> saveProfile() async {
    // CAMPUS-ONLY RULE: University is not required for updates (it's locked after initial setup)
    if (nameController.text.trim().isEmpty ||
        aboutController.text.trim().isEmpty ||
        skillControllers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill all required fields'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      // CAMPUS-ONLY RULE: Don't send university if it's already set (backend will reject changes anyway)
      final updatedUser = await UserService.updateProfile(
        name: nameController.text.trim(),
        about: aboutController.text.trim(),
        university: null, // Don't send university - it's locked after initial setup
        skills: skillControllers.map((c) => c.text.trim()).where((s) => s.isNotEmpty).toList(),
        yearOfStudy: yearOfStudyController.text.trim().isNotEmpty ? yearOfStudyController.text.trim() : null,
        profession: professionController.text.trim().isNotEmpty ? professionController.text.trim() : null,
        profileImage: profileImageUrl,
      );

      setState(() {
        name = updatedUser['name'] ?? '';
        email = updatedUser['email'] ?? '';
        about = updatedUser['about'] ?? '';
        university = updatedUser['university'];
        yearOfStudy = updatedUser['yearOfStudy'];
        profession = updatedUser['profession'];
        profileImageUrl = updatedUser['profileImage'];
        skills = List<String>.from(updatedUser['skills'] ?? []);
        nameController.text = name;
        aboutController.text = about;
        yearOfStudyController.text = yearOfStudy ?? '';
        professionController.text = profession ?? '';
        skillControllers = skills.map((skill) => TextEditingController(text: skill)).toList();
        editing = false;
        _isLoading = false;
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Profile updated successfully'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      setState(() => _isLoading = false);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error updating profile: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void editProfile() {
    setState(() {
      editing = true;
    });
  }

  Future<void> _signOut(BuildContext context) async {
    if (!mounted) return;
    
    // Show loading indicator
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(child: CircularProgressIndicator()),
    );
    
    try {
      // Clear all data with timeout to prevent hanging
      await AuthService.logout().timeout(
        const Duration(seconds: 3),
        onTimeout: () {
          // If logout times out, continue anyway - local data will be cleared
          print('Logout timeout - continuing with local cleanup');
        },
      );
    } catch (e) {
      // Continue even if logout fails - we'll clear local data anyway
      print('Logout error: $e');
    }
    
    if (!mounted) return;
    
    // Close loading dialog immediately
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }
    
    // Small delay to ensure dialog is dismissed before navigation
    await Future.delayed(const Duration(milliseconds: 100));
    
    if (!mounted) return;
    
    // Navigate to sign in page
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const SigninPage()),
      (route) => false,
    );
  }

  void _showSignOutConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Sign Out'),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
            child: const Text('No'),
            onPressed: () => Navigator.of(context).pop(),
          ),
          TextButton(
            child: const Text('Yes'),
            onPressed: () {
              Navigator.of(context).pop();
              _signOut(context);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTab(String label, bool selected, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 45,
          decoration: BoxDecoration(
            color: selected ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              color: selected ? const Color(0xFF8A47FF) : Colors.black26,
              fontWeight: FontWeight.w600,
              fontSize: 16,
            ),
          ),
        ),
      ),
    );
  }

  Widget _profileCard() {
    return Container(
      margin: const EdgeInsets.only(bottom: 21),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE9E6F7)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Profile Image with edit option
          Stack(
            children: [
              GestureDetector(
                onTap: _pickImage,
                child: CircleAvatar(
                  radius: 50,
                  backgroundColor: const Color(0xFF8A47FF).withOpacity(0.1),
                  backgroundImage: _profileImage != null 
                      ? FileImage(_profileImage!) 
                      : (profileImageUrl != null && profileImageUrl!.isNotEmpty
                          ? NetworkImage(profileImageUrl!) as ImageProvider
                          : null),
                  child: _profileImage == null && (profileImageUrl == null || profileImageUrl!.isEmpty)
                      ? Text(
                          name.isNotEmpty ? name[0].toUpperCase() : 'U',
                          style: const TextStyle(
                            fontSize: 36,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF8A47FF),
                          ),
                        )
                      : null,
                ),
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: GestureDetector(
                  onTap: _pickImage,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF8A47FF),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    child: const Icon(Icons.camera_alt, color: Colors.white, size: 18),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          // Name with verified badge
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              editing
                  ? Expanded(
                      child: TextField(
                        controller: nameController,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 22,
                        ),
                        decoration: _inputDecoration(),
                      ),
                    )
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          name,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 22,
                            color: Colors.black87,
                          ),
                        ),
                        if (university != null && university!.isNotEmpty) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: Colors.green.shade50,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.verified,
                              color: Colors.green,
                              size: 20,
                            ),
                          ),
                        ],
                      ],
                    ),
            ],
          ),
          
          // Email
          if (email.isNotEmpty) ...[
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.email, size: 16, color: Colors.grey.shade600),
                const SizedBox(width: 6),
                Text(
                  email,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ],
          
          // Year of Study and Profession
          if (yearOfStudy != null || profession != null) ...[
            const SizedBox(height: 12),
            Wrap(
              spacing: 12,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: [
                if (yearOfStudy != null && yearOfStudy!.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF8A47FF).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.school, size: 14, color: const Color(0xFF8A47FF)),
                        const SizedBox(width: 6),
                        Text(
                          yearOfStudy!,
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF8A47FF),
                          ),
                        ),
                      ],
                    ),
                  ),
                if (profession != null && profession!.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF8A47FF).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.work_outline, size: 14, color: const Color(0xFF8A47FF)),
                        const SizedBox(width: 6),
                        Text(
                          profession!,
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF8A47FF),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _editableSection({
    required String title,
    required Widget viewChild,
    required Widget editChild,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 17),
      padding: const EdgeInsets.symmetric(vertical: 17, horizontal: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE9E6F7)),
      ),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 11),
            editing ? editChild : viewChild,
          ]),
    );
  }

  InputDecoration _inputDecoration({String? hintText}) => InputDecoration(
    hintText: hintText,
    filled: true,
    fillColor: const Color(0xFFF7F7FB),
    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: BorderSide.none,
    ),
  );

  Widget _buildSkillEditor() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: List.generate(skillControllers.length, (i) {
            return SizedBox(
              width: 130,
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: skillControllers[i],
                      decoration: _inputDecoration(),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        skillControllers.removeAt(i);
                      });
                    },
                    child: const Padding(
                      padding: EdgeInsets.only(left: 6),
                      child: Icon(Icons.close, color: Colors.red, size: 20),
                    ),
                  )
                ],
              ),
            );
          }),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: newSkillController,
                decoration: _inputDecoration(hintText: 'Add new skill'),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.add_circle, color: Color(0xFF8A47FF)),
              onPressed: () {
                final newSkill = newSkillController.text.trim();
                if (newSkill.isNotEmpty) {
                  setState(() {
                    skillControllers.add(TextEditingController(text: newSkill));
                    newSkillController.clear();
                  });
                }
              },
            ),
          ],
        )
      ],
    );
  }

  Widget _buildSkillChips() {
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: skills
          .map(
            (skill) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          decoration: BoxDecoration(
            color: const Color(0xFFEDECF7),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(skill, style: const TextStyle(fontSize: 14)),
        ),
      )
          .toList(),
    );
  }

  Widget _buildWorkTab() {
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Recent Work',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
          ),
          const SizedBox(height: 6),
          const Text(
            "Projects you've posted",
            style: TextStyle(fontSize: 14, color: Colors.black54),
          ),
          const SizedBox(height: 16),
          ...workItems.map((item) => Container(
            margin: const EdgeInsets.only(bottom: 15),
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 18),
            decoration: BoxDecoration(
              color: const Color(0xFFF9F9FF),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE1E1F2)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item.title,
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16)),
                        const SizedBox(height: 6),
                        Text(item.company,
                            style: const TextStyle(
                                fontSize: 14, color: Color(0xFF8E8ED5))),
                        const SizedBox(height: 10),
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFFD7F1EB),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.location_city,
                                  size: 15, color: Color(0xFF6EBFB2)),
                              const SizedBox(width: 3),
                              Text(item.workplace,
                                  style: const TextStyle(
                                      fontSize: 12,
                                      color: Color(0xFF3A9689),
                                      fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: List.generate(5, (i) => Icon(
                            i < item.rating ? Icons.star : Icons.star_border,
                            size: 18,
                            color: Colors.amber,
                          )),
                        ),
                      ],
                    )),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(item.price,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 10),
                    Text(item.date,
                        style: const TextStyle(
                            fontSize: 14, color: Colors.black54)),
                  ],
                )
              ],
            ),
          )),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return NetworkGuard(
      child: Scaffold(
        backgroundColor: const Color(0xFFF8F6FF),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF8F6FF),
        elevation: 0,
        title: const Text(
          "Profile",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 22,
            color: Colors.black,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0, top: 6, bottom: 6),
            child: OutlinedButton.icon(
              icon: Icon(
                editing ? Icons.save : Icons.edit,
                size: 18,
                color: const Color(0xFF8A47FF),
              ),
              label: Text(
                editing ? "Save" : "Edit",
                style: const TextStyle(color: Color(0xFF8A47FF)),
              ),
              style: OutlinedButton.styleFrom(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(9)),
                side: const BorderSide(color: Color(0xFF8A47FF)),
                backgroundColor: Colors.white,
                minimumSize: const Size(74, 41),
                padding: const EdgeInsets.symmetric(horizontal: 14),
              ),
              onPressed: editing ? saveProfile : editProfile,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
      
              ],
            ),
            const SizedBox(height: 10),
            if (selectedTab == 0) ...[
              _profileCard(),
              _editableSection(
                title: "About",
                viewChild: Text(about, style: const TextStyle(fontSize: 15)),
                editChild: TextField(
                  controller: aboutController,
                  maxLines: 4,
                  decoration: _inputDecoration(),
                ),
              ),
              // CAMPUS-ONLY RULE: University is read-only after initial setup
              _editableSection(
                title: "University",
                viewChild: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      Icon(Icons.school, size: 18, color: const Color(0xFF8A47FF)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          university ?? 'Not selected',
                          style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 15),
                        ),
                      ),
                      if (university != null && university!.isNotEmpty)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.green.shade50,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.verified,
                                color: Colors.green,
                                size: 14,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                'Verified',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.green.shade700,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
                // University is read-only - show same view in edit mode
                editChild: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      Icon(Icons.school, size: 18, color: const Color(0xFF8A47FF)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          university ?? 'Not selected',
                          style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 15),
                        ),
                      ),
                      if (university != null && university!.isNotEmpty)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.lock, size: 12, color: Colors.grey.shade600),
                              const SizedBox(width: 4),
                              Text(
                                'Locked',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.grey.shade600,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              // Year of Study Section
              _editableSection(
                title: "Year of Study",
                viewChild: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      Icon(Icons.calendar_today, size: 18, color: const Color(0xFF8A47FF)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          yearOfStudy ?? 'Not set',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 15,
                            color: yearOfStudy == null ? Colors.grey.shade600 : Colors.black87,
                            fontStyle: yearOfStudy == null ? FontStyle.italic : FontStyle.normal,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                editChild: DropdownButtonFormField<String>(
                  value: yearOfStudyController.text.isNotEmpty ? yearOfStudyController.text : null,
                  decoration: _inputDecoration(),
                  items: [
                    const DropdownMenuItem<String>(value: null, child: Text("Select Year of Study")),
                    ...yearOfStudyOptions.map((String year) {
                      return DropdownMenuItem<String>(
                        value: year,
                        child: Text(year),
                      );
                    }),
                  ],
                  onChanged: (String? newValue) {
                    setState(() {
                      yearOfStudyController.text = newValue ?? '';
                    });
                  },
                ),
              ),
              // Profession Section
              _editableSection(
                title: "Profession",
                viewChild: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      Icon(Icons.work_outline, size: 18, color: const Color(0xFF8A47FF)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          profession ?? 'Not set',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 15,
                            color: profession == null ? Colors.grey.shade600 : Colors.black87,
                            fontStyle: profession == null ? FontStyle.italic : FontStyle.normal,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                editChild: DropdownButtonFormField<String>(
                  value: professionController.text.isNotEmpty ? professionController.text : null,
                  decoration: _inputDecoration(),
                  items: [
                    const DropdownMenuItem<String>(value: null, child: Text("Select Profession")),
                    ...professionOptions.map((String prof) {
                      return DropdownMenuItem<String>(
                        value: prof,
                        child: Text(prof),
                      );
                    }),
                  ],
                  onChanged: (String? newValue) {
                    setState(() {
                      professionController.text = newValue ?? '';
                    });
                  },
                ),
              ),
              _editableSection(
                title: "Skills",
                viewChild: Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: skills
                      .map((skill) => Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEDECF7),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(skill, style: const TextStyle(fontSize: 14)),
                  ))
                      .toList(),
                ),
                editChild: _buildSkillEditor(),
              ),
            ] else if (selectedTab == 1) ...[
            ] else if (selectedTab == 2) ...[
              _buildWorkTab(),
            ],
            // Add sign out button at bottom with confirmation
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF8A47FF),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),

                onPressed: () => _showSignOutConfirmation(context),
                child: const Text(
                  'Sign Out',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,  // <-- white text color
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      ),
    );
  }
}
